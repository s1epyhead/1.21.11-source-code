package com.blocks.test;

import com.blocks.BlocksClient;
import com.blocks.compat.Compat;
import com.blocks.gui.BlocksScreen;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.module.client.ClickGui;
import com.blocks.module.combat.AutoCrystal;
import com.blocks.module.world.AutoBuilder;
import com.blocks.module.world.AutoMine;
import com.blocks.util.CombatUtil;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.fabric.api.client.gametest.v1.context.TestSingleplayerContext;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.IntTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.presets.WorldPresets;
import net.minecraft.world.phys.Vec3;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Boots a superflat world, runs functional checks for the combat/world modules
 * (verified against the server's world state), then screenshots the HUD, hub,
 * menu panels and visuals. Results are written to the log as BLOCKS-TEST lines.
 */
public class BlocksScreenshots implements FabricClientGameTest {
    private final List<String> results = new ArrayList<>();

    @Override
    public void runTest(ClientGameTestContext ctx) {
        ctx.runOnClient(mc -> {
            mc.options.renderDistance().set(3);
            mc.options.simulationDistance().set(5);
            mc.options.framerateLimit().set(10);
            mc.options.menuBackgroundBlurriness().set(0);
            mc.options.cloudStatus().set(net.minecraft.client.CloudStatus.OFF);
        });
        TestSingleplayerContext sp = ctx.worldBuilder().adjustSettings(s -> {
            for (var entry : s.getNormalPresetList()) {
                if (entry.preset() != null && entry.preset().is(WorldPresets.FLAT)) s.setWorldType(entry);
            }
        }).create();
        try (sp) {
            ctx.waitTicks(40);
            ctx.runOnClient(mc -> {
                mc.options.framerateLimit().set(60);
                mc.options.menuBackgroundBlurriness().set(5);
            });
            cmd(sp, "time set 12600", "gamerule doDaylightCycle false", "gamerule doMobSpawning false", "weather clear",
                    "gamerule sendCommandFeedback false", "effect give @p resistance 600 4 true", "effect give @p saturation 600 1 true");

            String only = System.getenv("BLOCKS_ONLY");
            if (only == null || only.contains("finders")) testFinders(ctx, sp);
            if (only == null || only.contains("crystal")) testAutoCrystal(ctx, sp);
            if (only == null || only.contains("anchors")) testAnchors(ctx, sp);
            if (only == null || only.contains("mine")) testAutoMine(ctx, sp);
            if (only == null || only.contains("builder")) testBuilder(ctx, sp);
            if (only == null || only.contains("shapes")) testBuilderShapes(ctx, sp);
            if (only == null || only.contains("travel")) testTravel(ctx, sp);
            if (only == null || only.contains("freecam")) testFreecam(ctx, sp);
            if (only == null || only.contains("totem")) testTotemHit(ctx, sp);
            if (only == null || only.contains("aura")) testCrystalAura(ctx, sp);
            if (only != null && !only.contains("screens")) {
                for (String r : results) BlocksClient.LOG.info("BLOCKS-TEST {}", r);
                return;
            }

            for (String r : results) BlocksClient.LOG.info("BLOCKS-TEST {}", r);
            screenshots(ctx, sp);
            for (String r : results) BlocksClient.LOG.info("BLOCKS-TEST {}", r);
        }
    }

    // ------------------------------------------------------------------ helpers

    private static void cmd(TestSingleplayerContext sp, String... commands) {
        for (String c : commands) sp.getServer().runCommand(c);
    }

    private static Block block(TestSingleplayerContext sp, BlockPos pos) {
        return sp.getServer().computeOnServer(s -> s.overworld().getBlockState(pos).getBlock());
    }

    private static void reset(ClientGameTestContext ctx, TestSingleplayerContext sp) {
        ctx.runOnClient(mc -> {
            for (Module m : BlocksClient.modules.all()) if (m.isEnabled() && m.getCategory() != Category.CLIENT && !(m instanceof com.blocks.module.visuals.Hud) && !(m instanceof com.blocks.module.visuals.TargetHud)) m.setEnabledSilently(false);
        });
        cmd(sp, "clear @p", "fill -6 -60 -6 12 -50 12 air", "fill -6 -61 -6 12 -61 12 grass_block",
                "kill @e[type=minecraft:end_crystal]", "tp @p 0.5 -60 0.5 0 0", "effect give @p instant_health 1 5 true");
        ctx.waitTicks(10);
    }

    private static void lookAt(ClientGameTestContext ctx, Vec3 point) {
        ctx.runOnClient(mc -> {
            float[] r = CombatUtil.rotationsTo(point);
            mc.player.setYRot(r[0]);
            mc.player.setXRot(r[1]);
            mc.player.getInventory().setSelectedSlot(0);
        });
        ctx.waitTicks(2);
    }

    private static void enable(ClientGameTestContext ctx, Class<? extends Module> type) {
        ctx.runOnClient(mc -> {
            Module m = BlocksClient.modules.get(type);
            if (!m.isEnabled()) m.toggle();
        });
    }

    private void check(String name, boolean ok, String detail) {
        results.add((ok ? "PASS " : "FAIL ") + name + " - " + detail);
    }

    // ------------------------------------------------------------------ functional tests

    private void testFinders(ClientGameTestContext ctx, TestSingleplayerContext sp) {
        reset(ctx, sp);
        com.blocks.module.world.BlockEsp esp = ctx.computeOnClient(mc -> BlocksClient.modules.get(com.blocks.module.world.BlockEsp.class));
        enable(ctx, com.blocks.module.world.BlockEsp.class);
        ctx.waitTicks(5);
        // Placed after the module is on and buried under the floor: needs the block-change hook.
        cmd(sp, "setblock 3 -63 3 ancient_debris", "setblock -3 -63 3 spawner");
        ctx.waitTicks(10);
        String hits = ctx.computeOnClient(mc -> esp.getSuffix());
        java.util.Set<net.minecraft.world.item.Item> icons = ctx.computeOnClient(mc -> {
            java.util.Set<net.minecraft.world.item.Item> set = new java.util.HashSet<>();
            for (var f : com.blocks.world.Finds.all()) set.add(f.icon().getItem());
            return set;
        });
        check("Block ESP finds", "2".equals(hits), hits + " blocks highlighted (debris + spawner, buried)");
        check("Block ESP names", icons.contains(Items.SPAWNER) && icons.contains(Items.ANCIENT_DEBRIS),
                "find icons: " + icons);
        cmd(sp, "setblock 3 -63 3 air");
        ctx.waitTicks(8);
        String after = ctx.computeOnClient(mc -> esp.getSuffix());
        boolean debrisFind = ctx.computeOnClient(mc -> {
            for (var f : com.blocks.world.Finds.all()) if (f.icon().is(Items.ANCIENT_DEBRIS)) return true;
            return false;
        });
        check("Block ESP clears mined", "1".equals(after) && !debrisFind, after + " left after mining the debris");
        ctx.runOnClient(mc -> esp.setEnabled(false));
        enable(ctx, com.blocks.module.world.NetheriteFinder.class);
        cmd(sp, "setblock 3 -63 3 ancient_debris");
        ctx.waitTicks(10);
        String nf = ctx.computeOnClient(mc -> BlocksClient.modules.get(com.blocks.module.world.NetheriteFinder.class).getSuffix());
        check("Netherite Finder", "1".equals(nf), nf + " debris found (spawner ignored)");
        ctx.runOnClient(mc -> BlocksClient.modules.get(com.blocks.module.world.NetheriteFinder.class).setEnabled(false));
    }

    private void testAutoCrystal(ClientGameTestContext ctx, TestSingleplayerContext sp) {
        reset(ctx, sp);
        cmd(sp, "setblock 0 -61 2 obsidian", "fill -1 -60 -1 1 -58 -1 obsidian", "item replace entity @p hotbar.0 with end_crystal 64");
        ctx.waitTicks(5);
        lookAt(ctx, new Vec3(0.5, -60.0, 2.5));
        enable(ctx, AutoCrystal.class);
        ctx.getInput().holdKey(o -> o.keyUse);
        ctx.waitTicks(80);
        ctx.getInput().releaseKey(o -> o.keyUse);
        ctx.waitTicks(5);
        int left = ctx.computeOnClient(mc -> mc.player.getInventory().getItem(0).getCount());
        int used = 64 - left;
        double moved = ctx.computeOnClient(mc -> mc.player.position().distanceTo(new Vec3(0.5, -60, 0.5)));
        check("Auto Crystal", used >= 4, used + " crystals placed and broken in 4s while holding right click (moved " + String.format("%.2f", moved) + ")");
    }

    private void testAnchors(ClientGameTestContext ctx, TestSingleplayerContext sp) {
        reset(ctx, sp);
        BlockPos anchor = new BlockPos(0, -60, 3);
        cmd(sp, "setblock 0 -60 3 respawn_anchor", "item replace entity @p hotbar.0 with totem_of_undying",
                "item replace entity @p hotbar.1 with glowstone 16");
        ctx.waitTicks(5);
        lookAt(ctx, new Vec3(0.5, -59.0, 3.5));
        enable(ctx, com.blocks.module.combat.AnchorMacro.class);
        enable(ctx, com.blocks.module.combat.SafeAnchor.class);
        ctx.getInput().holdKey(o -> o.keyUse);
        ctx.waitTicks(40);
        ctx.getInput().releaseKey(o -> o.keyUse);
        ctx.waitTicks(5);
        boolean exploded = block(sp, anchor) != Blocks.RESPAWN_ANCHOR;
        int glow = ctx.computeOnClient(mc -> {
            int n = 0;
            for (int i = 0; i < 36; i++) if (mc.player.getInventory().getItem(i).is(Items.GLOWSTONE)) n += mc.player.getInventory().getItem(i).getCount();
            return n;
        });
        boolean shieldStill = block(sp, new BlockPos(0, -60, 2)) == Blocks.GLOWSTONE;
        check("Anchor Macro", exploded, exploded ? "anchor charged and detonated" : "anchor still there");
        check("Safe Anchor", 16 - glow >= 2 || shieldStill, (16 - glow) + " glowstone used (1 charge + 1 shield expected)");
    }

    private void testDoubleAnchor(ClientGameTestContext ctx, TestSingleplayerContext sp) {
        reset(ctx, sp);
        cmd(sp, "setblock 0 -61 3 obsidian", "item replace entity @p hotbar.0 with totem_of_undying",
                "item replace entity @p hotbar.1 with glowstone 16", "item replace entity @p hotbar.2 with respawn_anchor 8");
        ctx.waitTicks(5);
        lookAt(ctx, new Vec3(0.5, -60.0, 3.5));
        enable(ctx, com.blocks.module.combat.DoubleAnchor.class);
        ctx.waitTicks(60);
        int left = ctx.computeOnClient(mc -> mc.player.getInventory().getItem(2).getCount());
        boolean gone = block(sp, new BlockPos(0, -60, 3)) != Blocks.RESPAWN_ANCHOR;
        check("Double Anchor", 8 - left == 2 && gone, (8 - left) + " anchors placed and blown in one press");
    }

    private void testAutoMine(ClientGameTestContext ctx, TestSingleplayerContext sp) {
        reset(ctx, sp);
        // A 3 x 5 strip, two blocks high, starting where you stand (rows go to your right: facing south, that's west).
        cmd(sp, "fill -2 -60 0 0 -59 4 stone", "fill 0 -60 0 0 -59 0 air", "item replace entity @p hotbar.0 with netherite_pickaxe",
                "effect give @p haste 60 2 true", "tp @p 0.5 -60 0.5 0 0");
        ctx.runOnClient(mc -> {
            AutoMine m = BlocksClient.modules.get(AutoMine.class);
            for (var st : m.getSettings()) {
                if (st instanceof com.blocks.setting.ModeSetting mo && mo.getName().equals("Mode")) mo.set("Strip");
                if (st instanceof com.blocks.setting.NumSetting n && n.getName().equals("Row Length")) n.set(5);
                if (st instanceof com.blocks.setting.NumSetting n && n.getName().equals("Rows")) n.set(3);
                if (st instanceof com.blocks.setting.NumSetting n && n.getName().equals("Row Spacing")) n.set(1);
                if (st instanceof com.blocks.setting.NumSetting n && n.getName().equals("Step Delay")) n.set(1);
            }
            mc.player.setYRot(0);
            mc.player.setXRot(20);
        });
        ctx.waitTicks(3);
        enable(ctx, AutoMine.class);
        ctx.waitTicks(700);
        int stone = sp.getServer().computeOnServer(s -> {
            int n = 0;
            for (BlockPos p : BlockPos.betweenClosed(-2, -60, 0, 0, -59, 4)) if (s.overworld().getBlockState(p).is(Blocks.STONE)) n++;
            return n;
        });
        boolean stillOn = ctx.computeOnClient(mc -> BlocksClient.modules.get(AutoMine.class).isEnabled());
        check("Auto Mine (strip 3x5x2)", stone == 0, (28 - stone) + "/28 stone mined" + (stillOn ? " (still running)" : ", finished"));
        ctx.runOnClient(mc -> BlocksClient.modules.get(AutoMine.class).setEnabled(false));
    }

    private void testBuilder(ClientGameTestContext ctx, TestSingleplayerContext sp) {
        reset(ctx, sp);
        // A little 3x2x3 stone-and-planks hut, written as a vanilla structure file.
        Path file = ctx.computeOnClient(mc -> {
            Path f = AutoBuilder.folder().resolve("blocks_test_hut.nbt");
            CompoundTag root = new CompoundTag();
            ListTag size = new ListTag();
            size.add(IntTag.valueOf(3));
            size.add(IntTag.valueOf(2));
            size.add(IntTag.valueOf(3));
            root.put("size", size);
            ListTag palette = new ListTag();
            CompoundTag stone = new CompoundTag();
            stone.putString("Name", "minecraft:stone");
            CompoundTag planks = new CompoundTag();
            planks.putString("Name", "minecraft:oak_planks");
            palette.add(stone);
            palette.add(planks);
            root.put("palette", palette);
            ListTag blocks = new ListTag();
            for (int x = 0; x < 3; x++) for (int y = 0; y < 2; y++) for (int z = 0; z < 3; z++) {
                if (y == 1 && x == 1 && z == 1) continue;
                CompoundTag b = new CompoundTag();
                ListTag pos = new ListTag();
                pos.add(IntTag.valueOf(x));
                pos.add(IntTag.valueOf(y));
                pos.add(IntTag.valueOf(z));
                b.put("pos", pos);
                b.putInt("state", y == 0 ? 0 : 1);
                blocks.add(b);
            }
            root.put("blocks", blocks);
            try {
                NbtIo.writeCompressed(root, f);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            return f;
        });
        cmd(sp, "give @p stone 32", "give @p oak_planks 32");
        ctx.waitTicks(5);
        ctx.runOnClient(mc -> {
            AutoBuilder b = BlocksClient.modules.get(AutoBuilder.class);
            b.load(file);
            b.origin = new BlockPos(1, -60, 1);
            b.toggleBuilding();
        });
        ctx.waitTicks(100);
        ctx.runOnClient(mc -> {
            AutoBuilder b = BlocksClient.modules.get(AutoBuilder.class);
            b.setEnabled(false);
        });
        int placed = sp.getServer().computeOnServer(s -> {
            int n = 0;
            for (BlockPos p : BlockPos.betweenClosed(1, -60, 1, 3, -59, 3)) {
                var st = s.overworld().getBlockState(p);
                if (st.is(Blocks.STONE) || st.is(Blocks.OAK_PLANKS)) n++;
            }
            return n;
        });
        check("Auto Builder (.nbt)", placed == 17, placed + "/17 blocks built from the schematic");
    }

    private static Path writeStructure(ClientGameTestContext ctx, String name, int sx, int sy, int sz, String[] palette, int[][] blocks) {
        return ctx.computeOnClient(mc -> {
            Path f = AutoBuilder.folder().resolve(name);
            CompoundTag root = new CompoundTag();
            ListTag size = new ListTag();
            size.add(IntTag.valueOf(sx));
            size.add(IntTag.valueOf(sy));
            size.add(IntTag.valueOf(sz));
            root.put("size", size);
            ListTag pal = new ListTag();
            for (String st : palette) {
                CompoundTag t = new CompoundTag();
                int br = st.indexOf('[');
                t.putString("Name", br < 0 ? st : st.substring(0, br));
                if (br >= 0) {
                    CompoundTag props = new CompoundTag();
                    for (String kv : st.substring(br + 1, st.length() - 1).split(",")) props.putString(kv.split("=")[0], kv.split("=")[1]);
                    t.put("Properties", props);
                }
                pal.add(t);
            }
            root.put("palette", pal);
            ListTag list = new ListTag();
            for (int[] b : blocks) {
                CompoundTag bt = new CompoundTag();
                ListTag pos = new ListTag();
                pos.add(IntTag.valueOf(b[0]));
                pos.add(IntTag.valueOf(b[1]));
                pos.add(IntTag.valueOf(b[2]));
                bt.put("pos", pos);
                bt.putInt("state", b[3]);
                list.add(bt);
            }
            root.put("blocks", list);
            try {
                NbtIo.writeCompressed(root, f);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            return f;
        });
    }

    /** Stairs, a top slab and a sideways log must come out in exactly the right orientation. */
    private void testBuilderShapes(ClientGameTestContext ctx, TestSingleplayerContext sp) {
        reset(ctx, sp);
        Path file = writeStructure(ctx, "blocks_test_shapes.nbt", 3, 1, 2,
                new String[]{"minecraft:stone", "minecraft:oak_stairs[facing=east,half=bottom,shape=straight,waterlogged=false]",
                        "minecraft:oak_slab[type=top,waterlogged=false]", "minecraft:oak_log[axis=x]",
                        "minecraft:oak_stairs[facing=north,half=top,shape=straight,waterlogged=false]"},
                new int[][]{{0, 0, 0, 0}, {1, 0, 0, 1}, {2, 0, 0, 2}, {0, 0, 1, 3}, {1, 0, 1, 4}});
        cmd(sp, "give @p stone 8", "give @p oak_stairs 8", "give @p oak_slab 8", "give @p oak_log 8");
        ctx.waitTicks(5);
        ctx.runOnClient(mc -> {
            AutoBuilder b = BlocksClient.modules.get(AutoBuilder.class);
            b.load(file);
            b.origin = new BlockPos(1, -60, 2);
            b.toggleBuilding();
        });
        ctx.waitTicks(100);
        ctx.runOnClient(mc -> BlocksClient.modules.get(AutoBuilder.class).setEnabled(false));
        String[] want = {"stone", "oak_stairs[facing=east,half=bottom", "oak_slab[type=top", "oak_log[axis=x]", "oak_stairs[facing=north,half=top"};
        BlockPos[] at = {new BlockPos(1, -60, 2), new BlockPos(2, -60, 2), new BlockPos(3, -60, 2), new BlockPos(1, -60, 3), new BlockPos(2, -60, 3)};
        int ok = 0;
        StringBuilder bad = new StringBuilder();
        for (int i = 0; i < at.length; i++) {
            BlockPos p = at[i];
            String st = sp.getServer().computeOnServer(s -> s.overworld().getBlockState(p).toString());
            String norm = st.replace("Block{minecraft:", "").replace("}", "");
            boolean good = true;
            for (String part : want[i].replace("[", ",").replace("]", "").split(",")) if (!norm.contains(part)) good = false;
            if (good) ok++;
            else bad.append(" ").append(norm);
        }
        check("Auto Builder orientation", ok == at.length, ok + "/" + at.length + " exact states (stairs, top slab, log axis)" + bad);
    }

    /** Base Hunter's travel: tunnel through solid stone to a lower target, past a lava pocket. */
    private void testTravel(ClientGameTestContext ctx, TestSingleplayerContext sp) {
        reset(ctx, sp);
        cmd(sp, "fill -3 -63 1 3 -56 18 stone", "setblock 1 -61 7 lava", "item replace entity @p hotbar.0 with netherite_pickaxe",
                "give @p cobblestone 32", "effect give @p haste 60 2 true", "tp @p 0.5 -60 0.5 0 0");
        ctx.waitTicks(10);
        BlockPos goal = new BlockPos(0, -62, 14);
        ctx.runOnClient(mc -> BlocksClient.modules.get(AutoMine.class).travelTo(goal));
        ctx.waitTicks(500);
        double dist = ctx.computeOnClient(mc -> Math.sqrt(mc.player.blockPosition().distSqr(goal)));
        boolean lavaInTunnel = sp.getServer().computeOnServer(s -> {
            for (BlockPos p : BlockPos.betweenClosed(-1, -63, 1, 1, -58, 16)) if (s.overworld().getFluidState(p).is(net.minecraft.tags.FluidTags.LAVA) && !p.equals(new BlockPos(1, -61, 7))) return true;
            return false;
        });
        float hp = ctx.computeOnClient(mc -> mc.player.getHealth());
        ctx.runOnClient(mc -> BlocksClient.modules.get(AutoMine.class).setEnabled(false));
        check("Base Hunter travel", dist <= 3.5 && hp > 10, String.format("ended %.1f blocks from the target, health %.0f, lava spread %s", dist, hp, lavaInTunnel ? "yes" : "no"));
    }

    private void testFreecam(ClientGameTestContext ctx, TestSingleplayerContext sp) {
        reset(ctx, sp);
        Vec3 before = ctx.computeOnClient(mc -> mc.player.position());
        enable(ctx, com.blocks.module.visuals.Freecam.class);
        ctx.waitTicks(2);
        ctx.getInput().holdKey(o -> o.keyUp);
        ctx.waitTicks(20);
        ctx.getInput().releaseKey(o -> o.keyUp);
        ctx.waitTicks(2);
        Vec3 after = ctx.computeOnClient(mc -> mc.player.position());
        Vec3 cam = ctx.computeOnClient(mc -> Compat.camera().position());
        ctx.runOnClient(mc -> BlocksClient.modules.get(com.blocks.module.visuals.Freecam.class).setEnabled(false));
        double playerMoved = after.distanceTo(before), camMoved = cam.distanceTo(after.add(0, 1.62, 0));
        check("Freecam", playerMoved < 0.1 && camMoved > 5, String.format("player moved %.2f, camera flew %.1f blocks", playerMoved, camMoved));
    }

    private void testCrystalAura(ClientGameTestContext ctx, TestSingleplayerContext sp) {
        reset(ctx, sp);
        cmd(sp, "kill @e[type=minecraft:zombie]", "fill -3 -61 1 4 -61 7 obsidian", "fill -1 -60 -1 1 -58 -1 obsidian",
                "summon zombie 0.5 -60 4.5 {NoAI:1b,PersistenceRequired:1b,Health:20f}", "item replace entity @p hotbar.0 with end_crystal 64",
                "item replace entity @p hotbar.1 with obsidian 16", "tp @p 0.5 -60 0.5 0 30");
        ctx.waitTicks(10);
        ctx.runOnClient(mc -> {
            var m = BlocksClient.modules.get(com.blocks.module.combat.CrystalAura.class);
            for (var st : m.getSettings()) if (st instanceof com.blocks.setting.ModeSetting mo && mo.getName().equals("Targets")) mo.set("All Living");
            if (!m.isEnabled()) m.toggle();
            mc.options.setCameraType(net.minecraft.client.CameraType.THIRD_PERSON_BACK);
        });
        ctx.waitTicks(14);
        ctx.takeScreenshot("blocks-crystal-aura");
        ctx.waitTicks(70);
        float hp = sp.getServer().computeOnServer(s -> {
            for (var e : s.overworld().getAllEntities())
                if (net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath().equals("zombie") && e instanceof net.minecraft.world.entity.LivingEntity le) return le.getHealth();
            return 0f; // dead and gone
        });
        int used = ctx.computeOnClient(mc -> 64 - mc.player.getInventory().getItem(0).getCount());
        float me = ctx.computeOnClient(mc -> mc.player.getHealth());
        ctx.runOnClient(mc -> {
            BlocksClient.modules.get(com.blocks.module.combat.CrystalAura.class).setEnabled(false);
            mc.options.setCameraType(net.minecraft.client.CameraType.FIRST_PERSON);
        });
        cmd(sp, "kill @e[type=minecraft:zombie]", "kill @e[type=minecraft:end_crystal]");
        check("Crystal Aura", hp <= 10 && me > 15, "zombie at " + hp + " hp after " + used + " crystals, you at " + me + " hp");
    }

    private void testTotemHit(ClientGameTestContext ctx, TestSingleplayerContext sp) {
        reset(ctx, sp);
        cmd(sp, "kill @e[type=minecraft:zombie]", "summon zombie 0.5 -60 2.0 {NoAI:1b,PersistenceRequired:1b,Health:20f}",
                "item replace entity @p hotbar.0 with totem_of_undying", "item replace entity @p hotbar.1 with netherite_sword");
        ctx.waitTicks(25);
        ctx.runOnClient(mc -> {
            var m = BlocksClient.modules.get(com.blocks.module.combat.TotemHit.class);
            for (var st : m.getSettings()) if (st instanceof com.blocks.setting.BoolSetting b && b.getName().equals("Players Only")) b.set(false);
            if (!m.isEnabled()) m.toggle();
            mc.player.getInventory().setSelectedSlot(0);
        });
        lookAt(ctx, new Vec3(0.5, -59.0, 2.0)); // aim at the zombie: the sword comes out
        ctx.waitTicks(25);
        ctx.runOnClient(mc -> {
            net.minecraft.world.entity.Entity z = null;
            for (var e : mc.level.entitiesForRendering()) if (net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath().equals("zombie")) z = e;
            if (z != null) mc.gameMode.attack(mc.player, z);
        });
        ctx.waitTicks(3);
        ctx.runOnClient(mc -> mc.player.setXRot(-80)); // look away: the totem goes back (after half a second)
        ctx.waitTicks(16);
        float hp = sp.getServer().computeOnServer(s -> {
            for (var e : s.overworld().getAllEntities()) if (net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath().equals("zombie") && e instanceof net.minecraft.world.entity.LivingEntity zz) return zz.getHealth();
            return -1f;
        });
        int slot = ctx.computeOnClient(mc -> mc.player.getInventory().getSelectedSlot());
        cmd(sp, "kill @e[type=minecraft:zombie]");
        check("Totem Hit", hp >= 0 && hp <= 14 && slot == 0, "zombie at " + hp + " hp after one hit, back on slot " + slot);
    }

    // ------------------------------------------------------------------ screenshots

    private static void open(ClientGameTestContext ctx, Category c, Module m, boolean settings) {
        ctx.setScreen(() -> null);
        ctx.runOnClient(mc -> Compat.openUi(BlocksScreen.withState(c, m, settings)));
        ctx.waitTicks(12);
    }

    private void screenshots(ClientGameTestContext ctx, TestSingleplayerContext sp) {
        reset(ctx, sp);
        cmd(sp, "fill -4 -61 2 4 -61 9 obsidian", "summon end_crystal 1.5 -60 5.5 {ShowBottom:0b}",
                "setblock 5 -60 4 chest", "setblock 6 -60 5 barrel", "setblock 3 -63 3 ancient_debris", "setblock -3 -63 3 spawner",
                "summon zombie 0.5 -60 4.5 {NoAI:1b,PersistenceRequired:1b}", "item replace entity @p armor.head with netherite_helmet",
                "item replace entity @p armor.chest with netherite_chestplate", "effect give @p speed 600 1 true",
                "item replace entity @p hotbar.0 with end_crystal 64", "tp @p 0.5 -60 0.5 0 50");
        ctx.waitTicks(10);
        ctx.runOnClient(mc -> {
            for (Class<? extends Module> c : List.<Class<? extends Module>>of(
                    com.blocks.module.world.BlockEsp.class, com.blocks.module.world.StorageEsp.class,
                    com.blocks.module.visuals.CrystalRender.class, com.blocks.module.visuals.BlockHighlight.class,
                    com.blocks.module.visuals.Trails.class, com.blocks.module.visuals.SunHat.class,
                    com.blocks.module.visuals.JumpCircles.class, com.blocks.module.combat.AutoCrystal.class,
                    com.blocks.module.utility.Sprint.class, com.blocks.module.utility.AutoReconnect.class)) {
                Module m = BlocksClient.modules.get(c);
                if (!m.isEnabled()) m.toggle();
            }
            var hud = BlocksClient.modules.get(com.blocks.module.visuals.Hud.class);
            hud.armorHud.set(true);
            hud.potions.set(true);
            BlocksClient.modules.byName("Anchor Macro").setKey(com.mojang.blaze3d.platform.InputConstants.KEY_R);
            BlocksClient.modules.byName("Freecam").setKey(com.mojang.blaze3d.platform.InputConstants.KEY_PAGEUP);
            mc.player.setYRot(0);
            mc.player.setXRot(50);
        });
        ctx.waitTicks(40);
        ctx.takeScreenshot("blocks-xray-finders");

        // Third person: the blatant set (chams, aura spikes, boxed arraylist), trails and a jump ripple.
        ctx.runOnClient(mc -> {
            Module chams = BlocksClient.modules.get(com.blocks.module.visuals.Chams.class);
            for (var st : chams.getSettings()) if (st instanceof com.blocks.setting.BoolSetting b && b.getName().equals("Self")) b.set(true);
            Module pack = BlocksClient.modules.get(com.blocks.module.visuals.BlatantPack.class);
            if (!pack.isEnabled()) pack.toggle();
            Module buddy = BlocksClient.modules.get(com.blocks.module.visuals.Companion.class);
            if (!buddy.isEnabled()) buddy.toggle();
            for (var st : BlocksClient.modules.get(com.blocks.module.visuals.SunHat.class).getSettings())
                if (st instanceof com.blocks.setting.ModeSetting mo && mo.getName().equals("Wearers")) mo.set("Everyone");
            Module spikes = BlocksClient.modules.get(com.blocks.module.visuals.AuraSpikes.class);
            if (!spikes.isEnabled()) spikes.toggle();
            for (Class<? extends Module> c : List.<Class<? extends Module>>of(com.blocks.module.visuals.OrbitShards.class,
                    com.blocks.module.visuals.StatusBars.class, com.blocks.module.visuals.TargetEsp.class)) {
                Module m = BlocksClient.modules.get(c);
                if (!m.isEnabled()) m.toggle();
            }
            for (var st : BlocksClient.modules.get(com.blocks.module.visuals.TargetEsp.class).getSettings()) {
                if (st instanceof com.blocks.setting.ModeSetting mo && mo.getName().equals("Style")) mo.set("Rune");
                if (st instanceof com.blocks.setting.BoolSetting b && b.getName().equals("Hitbox")) b.set(true);
            }
            BlocksClient.setTarget(mc.player);
            var hud = BlocksClient.modules.get(com.blocks.module.visuals.Hud.class);
            hud.arrayStyle.set("Boxed");
            hud.watermarkXyz.set(true);
            mc.options.setCameraType(net.minecraft.client.CameraType.THIRD_PERSON_BACK);
            mc.player.setYRot(180);
            mc.player.setXRot(20);
        });
        ctx.getInput().holdKey(o -> o.keyDown);
        ctx.waitTicks(14);
        ctx.getInput().holdKey(o -> o.keyJump);
        ctx.waitTicks(4);
        ctx.getInput().releaseKey(o -> o.keyJump);
        ctx.waitTicks(10);
        ctx.getInput().releaseKey(o -> o.keyDown);
        cmd(sp, "item replace entity @p armor.head with air", "item replace entity @p armor.chest with air");
        ctx.runOnClient(mc -> BlocksClient.setTarget(mc.player)); // keep the target fresh for the target visuals
        ctx.waitTicks(3);
        ctx.runOnClient(mc -> BlocksClient.setTarget(mc.player));
        ctx.takeScreenshot("blocks-visuals-third-person");
        ctx.runOnClient(mc -> {
            mc.options.setCameraType(net.minecraft.client.CameraType.FIRST_PERSON);
            BlocksClient.modules.get(com.blocks.module.visuals.BlatantPack.class).setEnabled(false);
            BlocksClient.modules.get(com.blocks.module.visuals.Companion.class).setEnabled(false);
            BlocksClient.modules.get(com.blocks.module.visuals.Chams.class).setEnabled(false);
            BlocksClient.modules.get(com.blocks.module.visuals.AuraSpikes.class).setEnabled(false);
            BlocksClient.modules.get(com.blocks.module.visuals.OrbitShards.class).setEnabled(false);
            BlocksClient.modules.get(com.blocks.module.visuals.TargetEsp.class).setEnabled(false);
            BlocksClient.modules.get(com.blocks.module.visuals.Hud.class).arrayStyle.set("Clean");
        });
        cmd(sp, "tp @p 0.5 -60 0.5 0 50");
        ctx.waitTicks(5);

        ClickGui gui = ctx.computeOnClient(mc -> BlocksClient.modules.get(ClickGui.class));
        ctx.runOnClient(mc -> gui.tooltips.set(false));
        ctx.setScreen(() -> null);
        ctx.runOnClient(mc -> Compat.openUi(BlocksScreen.dock(Category.COMBAT, null, false)));
        ctx.waitTicks(16);
        ctx.takeScreenshot("blocks-menu-hub");
        ctx.setScreen(() -> null);
        ctx.runOnClient(mc -> Compat.openUi(BlocksScreen.dock(Category.UTILITY, BlocksClient.modules.get(com.blocks.module.utility.AutoReconnect.class), false)));
        ctx.waitTicks(18);
        ctx.takeScreenshot("blocks-menu-card");
        ctx.setScreen(() -> null);
        ctx.runOnClient(mc -> Compat.openUi(BlocksScreen.dock(Category.WORLD, BlocksClient.modules.get(AutoMine.class), false)));
        ctx.waitTicks(18);
        ctx.takeScreenshot("blocks-menu-automine");
        ctx.setScreen(() -> null);
        ctx.runOnClient(mc -> {
            BlocksClient.modules.get(AutoBuilder.class).schematic = null;
            Compat.openUi(BlocksScreen.dock(Category.WORLD, BlocksClient.modules.get(AutoBuilder.class), false));
        });
        ctx.waitTicks(18);
        ctx.takeScreenshot("blocks-menu-builder");
        ctx.setScreen(() -> null);
        ctx.runOnClient(mc -> Compat.openUi(BlocksScreen.dock(Category.VISUALS, null, true)));
        ctx.waitTicks(18);
        ctx.takeScreenshot("blocks-menu-prefs");
        ctx.setScreen(() -> null);
        ctx.runOnClient(mc -> gui.menuStyle.set("Panel Only"));
        ctx.runOnClient(mc -> Compat.openUi(BlocksScreen.dock(Category.COMBAT, BlocksClient.modules.get(AutoCrystal.class), false)));
        ctx.waitTicks(18);
        ctx.takeScreenshot("blocks-menu-panel-only");
        ctx.runOnClient(mc -> gui.menuStyle.set("Hub + Panel"));
        ctx.setScreen(() -> null);
        ctx.runOnClient(mc -> gui.theme.set("Diamond"));
        ctx.runOnClient(mc -> Compat.openUi(BlocksScreen.dock(Category.WORLD, null, false)));
        ctx.waitTicks(16);
        ctx.takeScreenshot("blocks-menu-lagoon");
        ctx.runOnClient(mc -> gui.theme.set("Amethyst"));
        ctx.setScreen(() -> null);
    }
}
