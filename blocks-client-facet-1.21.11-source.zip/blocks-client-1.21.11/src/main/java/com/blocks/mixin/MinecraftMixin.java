package com.blocks.mixin;

import com.blocks.BlocksClient;
import com.blocks.module.visuals.Esp;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Minecraft.class)
public class MinecraftMixin {
    @Inject(method = "shouldEntityAppearGlowing", at = @At("HEAD"), cancellable = true)
    private void blocks$esp(Entity entity, CallbackInfoReturnable<Boolean> cir) {
        if (BlocksClient.modules == null) return;
        if (BlocksClient.modules.get(Esp.class).shouldGlow(entity)
                || entity instanceof net.minecraft.world.entity.boss.enderdragon.EndCrystal
                && BlocksClient.modules.get(com.blocks.module.visuals.CrystalRender.class).glowCrystals()) {
            cir.setReturnValue(true);
        }
    }
}
