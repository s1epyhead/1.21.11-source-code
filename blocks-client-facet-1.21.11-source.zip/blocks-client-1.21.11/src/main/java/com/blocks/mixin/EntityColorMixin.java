package com.blocks.mixin;

import com.blocks.BlocksClient;
import com.blocks.module.visuals.Esp;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Tints the vanilla glow outline (used by ESP) with the Blocks theme. */
@Mixin(Entity.class)
public class EntityColorMixin {
    @Inject(method = "getTeamColor", at = @At("HEAD"), cancellable = true)
    private void blocks$glowColor(CallbackInfoReturnable<Integer> cir) {
        if (BlocksClient.modules == null) return;
        int c = BlocksClient.modules.get(Esp.class).glowColor((Entity) (Object) this);
        if (c != -1) cir.setReturnValue(c);
    }
}
