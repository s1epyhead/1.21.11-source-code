package com.blocks.mixin;

import com.blocks.BlocksClient;
import com.blocks.module.visuals.Chams;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingTintMixin {
    @Shadow
    public abstract Identifier getTextureLocation(LivingEntityRenderState state);

    @Inject(method = "getModelTint", at = @At("RETURN"), cancellable = true)
    private void blocks$chams(LivingEntityRenderState state, CallbackInfoReturnable<Integer> cir) {
        if (BlocksClient.modules == null) return;
        int tint = BlocksClient.modules.get(Chams.class).tintFor(state);
        if (tint != 0) cir.setReturnValue(tint);
    }

    /** Glass chams: draw the player translucent so the tint's alpha shows. */
    @Inject(method = "getRenderType", at = @At("HEAD"), cancellable = true)
    private void blocks$glass(LivingEntityRenderState state, boolean visible, boolean translucent, boolean glowing, CallbackInfoReturnable<RenderType> cir) {
        if (BlocksClient.modules != null && BlocksClient.modules.get(Chams.class).glassFor(state)) {
            cir.setReturnValue(RenderTypes.entityTranslucent(getTextureLocation(state)));
        }
    }
}
