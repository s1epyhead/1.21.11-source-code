package com.blocks.mixin;

import com.blocks.BlocksClient;
import com.blocks.module.visuals.Freecam;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public class EntityTurnMixin {
    /** With Freecam on, the mouse turns the camera instead of the player. */
    @Inject(method = "turn", at = @At("HEAD"), cancellable = true)
    private void blocks$freecamTurn(double yRot, double xRot, CallbackInfo ci) {
        if (BlocksClient.modules == null || (Object) this != Minecraft.getInstance().player) return;
        Freecam f = BlocksClient.modules.get(Freecam.class);
        if (f.active()) {
            f.turn(yRot, xRot);
            ci.cancel();
        }
    }
}
