package com.blocks.mixin;

import com.blocks.BlocksClient;
import com.blocks.module.visuals.BetterCamera;
import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Camera.class)
public class CameraMixin {
    @ModifyVariable(method = "getMaxZoom", at = @At("HEAD"), argsOnly = true)
    private float blocks$distance(float distance) {
        return BlocksClient.modules == null ? distance : BlocksClient.modules.get(BetterCamera.class).distance(distance);
    }

    @Inject(method = "getMaxZoom", at = @At("HEAD"), cancellable = true)
    private void blocks$noClip(float distance, CallbackInfoReturnable<Float> cir) {
        if (BlocksClient.modules == null) return;
        BetterCamera cam = BlocksClient.modules.get(BetterCamera.class);
        if (cam.noClip()) cir.setReturnValue(cam.distance(distance));
    }
}
