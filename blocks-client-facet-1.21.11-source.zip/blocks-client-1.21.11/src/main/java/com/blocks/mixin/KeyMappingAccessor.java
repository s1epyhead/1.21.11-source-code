package com.blocks.mixin;

import net.minecraft.client.KeyMapping;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(KeyMapping.class)
public interface KeyMappingAccessor {
    /** The real pressed state, even while Freecam holds the key back from the player. */
    @Accessor("isDown")
    boolean blocks$isDown();
}
