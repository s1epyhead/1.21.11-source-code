package com.blocks.mixin;

import com.blocks.BlocksClient;
import com.blocks.module.combat.CrystalOptimizer;
import com.blocks.module.combat.MaceSwap;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MultiPlayerGameMode.class)
public class GameModeMixin {
    /** Vanilla aborts block breaking every tick unless attack is held; let Auto Mine keep going. */
    @Inject(method = "stopDestroyBlock", at = @At("HEAD"), cancellable = true)
    private void blocks$keepMining(CallbackInfo ci) {
        if (BlocksClient.modules != null && (BlocksClient.modules.get(com.blocks.module.world.AutoMine.class).isMining()
                || BlocksClient.modules.get(com.blocks.module.world.AutoBuilder.class).isMining())) ci.cancel();
    }

    @Inject(method = "attack", at = @At("HEAD"))
    private void blocks$beforeAttack(Player player, Entity target, CallbackInfo ci) {
        if (BlocksClient.modules == null) return;
        BlocksClient.modules.get(MaceSwap.class).beforeAttack(target);
        BlocksClient.modules.get(com.blocks.module.combat.TotemHit.class).beforeAttack(target);
    }

    @Inject(method = "attack", at = @At("TAIL"))
    private void blocks$afterAttack(Player player, Entity target, CallbackInfo ci) {
        if (BlocksClient.modules == null) return;
        BlocksClient.modules.get(com.blocks.module.combat.TotemHit.class).afterAttack();
        BlocksClient.modules.get(com.blocks.module.visuals.HitParticles.class).onHit(target);
        BlocksClient.modules.get(CrystalOptimizer.class).onAttack(target);
    }
}
