package com.blocks.mixin;

import com.blocks.BlocksClient;
import com.blocks.module.visuals.Freecam;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Camera.class)
public abstract class FreecamCameraMixin {
    @Shadow protected abstract void setPosition(double x, double y, double z);
    @Shadow protected abstract void setRotation(float yRot, float xRot);

    @Inject(method = "setup", at = @At("TAIL"))
    private void blocks$freecam(Level level, Entity entity, boolean detached, boolean mirrored, float partialTick, CallbackInfo ci) {
        if (BlocksClient.modules == null) return;
        Freecam f = BlocksClient.modules.get(Freecam.class);
        if (!f.active()) return;
        setRotation(f.yaw(), f.pitch());
        setPosition(f.x(partialTick), f.y(partialTick), f.z(partialTick));
    }

    @Inject(method = "isDetached", at = @At("HEAD"), cancellable = true)
    private void blocks$detached(CallbackInfoReturnable<Boolean> cir) {
        if (BlocksClient.modules != null && BlocksClient.modules.get(Freecam.class).active()) cir.setReturnValue(true);
    }
}
