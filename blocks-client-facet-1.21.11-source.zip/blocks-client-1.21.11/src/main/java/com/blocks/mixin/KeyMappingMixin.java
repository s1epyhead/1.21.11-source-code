package com.blocks.mixin;

import com.blocks.BlocksClient;
import com.blocks.module.visuals.Freecam;
import net.minecraft.client.KeyMapping;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(KeyMapping.class)
public class KeyMappingMixin {
    @Inject(method = "isDown", at = @At("HEAD"), cancellable = true)
    private void blocks$freecamHold(CallbackInfoReturnable<Boolean> cir) {
        if (BlocksClient.modules != null && BlocksClient.modules.get(Freecam.class).blocks((KeyMapping) (Object) this)) cir.setReturnValue(false);
    }
}
