package com.blocks.mixin;

import com.blocks.BlocksClient;
import com.blocks.module.visuals.Nametags;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderer.class)
public class NametagMixin {
    /** Our own nametags replace vanilla's for players. */
    @Inject(method = "shouldShowName", at = @At("HEAD"), cancellable = true)
    private void blocks$hideVanillaTag(Entity entity, double distanceSq, CallbackInfoReturnable<Boolean> cir) {
        if (BlocksClient.modules != null && BlocksClient.modules.get(Nametags.class).hidesVanilla(entity)) cir.setReturnValue(false);
    }
}
