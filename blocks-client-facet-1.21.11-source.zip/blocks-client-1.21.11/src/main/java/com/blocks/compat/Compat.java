package com.blocks.compat;

import com.mojang.blaze3d.platform.InputConstants;
import com.blocks.render.Gfx;
import com.blocks.render.UiScreen;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.resources.Identifier;
import net.minecraft.world.inventory.ClickType;

import java.util.function.Consumer;

/** Everything that differs between 1.21.11 and 26.x, 1.21.11 side. */
public final class Compat {
    private static final Minecraft mc = Minecraft.getInstance();

    private Compat() {}

    public static Screen screen() {
        return mc.screen;
    }

    public static void setScreen(Screen screen) {
        mc.setScreen(screen);
    }

    public static void openUi(UiScreen ui) {
        mc.setScreen(new ScreenWrapper(ui));
    }

    public static boolean isUi(Screen screen) {
        return screen instanceof ScreenWrapper;
    }

    public static boolean hudHidden() {
        return mc.options.hideGui;
    }

    public static boolean isKeyDown(int key) {
        return InputConstants.isKeyDown(mc.getWindow(), key);
    }

    /** Swaps the given container slot with a hotbar slot (0-8) or the offhand (40). */
    public static void swapSlot(int syncId, int slotId, int button) {
        mc.gameMode.handleInventoryMouseClick(syncId, slotId, button, ClickType.SWAP, mc.player);
    }

    /** Drops the whole stack in a container slot (Ctrl+Q). */
    public static void dropSlot(int syncId, int slotId) {
        mc.gameMode.handleInventoryMouseClick(syncId, slotId, 1, ClickType.THROW, mc.player);
    }

    /** Adds a widget to a screen after it initialises. */
    public static void addWidget(net.minecraft.client.gui.screens.Screen screen, net.minecraft.client.gui.components.AbstractWidget w) {
        net.fabricmc.fabric.api.client.screen.v1.Screens.getButtons(screen).add(w);
    }

    public static void registerHud(Identifier id, Consumer<Gfx> renderer) {
        HudElementRegistry.addLast(id, (g, tick) -> renderer.accept(new GfxImpl(g)));
    }

    public static void swing(net.minecraft.world.InteractionHand hand, boolean attack) {
        mc.player.swing(hand);
    }

    public static String keyName(int key) {
        if (key <= 0) return "None";
        return InputConstants.Type.KEYSYM.getOrCreate(key).getDisplayName().getString();
    }

    /** Calls the consumer every frame while the world renders, with a pose stack and submit collector. */
    public static void registerWorldRender(java.util.function.BiConsumer<com.mojang.blaze3d.vertex.PoseStack, net.minecraft.client.renderer.SubmitNodeCollector> draw) {
        net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.AFTER_ENTITIES.register(ctx -> draw.accept(ctx.matrices(), ctx.commandQueue()));
    }

    /** Replaces a vanilla HUD layer (e.g. the crosshair); the renderer returns false to fall back to vanilla. */
    public static void replaceHud(Identifier id, java.util.function.Predicate<Gfx> renderer) {
        HudElementRegistry.replaceElement(id, old -> (g, tick) -> {
            if (!renderer.test(new GfxImpl(g))) old.render(g, tick);
        });
    }

    public record ChatLine(int addedTime, net.minecraft.util.FormattedCharSequence content, boolean endOfEntry) {}

    /** Visible chat lines, newest first. */
    public static java.util.List<ChatLine> chatLines() {
        var lines = ((com.blocks.mixin.ChatAccessor) mc.gui.getChat()).blocks$lines();
        java.util.List<ChatLine> out = new java.util.ArrayList<>(Math.min(lines.size(), 100));
        for (int i = 0; i < lines.size() && i < 100; i++) {
            var l = lines.get(i);
            out.add(new ChatLine(l.addedTime(), l.content(), l.endOfEntry()));
        }
        return out;
    }

    public static int guiTicks() {
        return mc.gui.getGuiTicks();
    }

    public static long chunkKey(net.minecraft.world.level.ChunkPos p) { return p.toLong(); }
    public static long chunkKey(int x, int z) { return net.minecraft.world.level.ChunkPos.asLong(x, z); }
    public static int chunkX(net.minecraft.world.level.ChunkPos p) { return p.x; }
    public static int chunkZ(net.minecraft.world.level.ChunkPos p) { return p.z; }
    public static net.minecraft.client.Camera camera() { return mc.gameRenderer.getMainCamera(); }

    // ---- See-through world geometry (ESP / finders): no depth test, no depth write ----
    private static net.minecraft.client.renderer.rendertype.RenderType xrayQuads, xrayLines;

    public static net.minecraft.client.renderer.rendertype.RenderType quads(boolean xray) {
        if (!xray) return net.minecraft.client.renderer.rendertype.RenderTypes.debugQuads();
        if (xrayQuads == null) {
            var pipe = com.mojang.blaze3d.pipeline.RenderPipeline.builder(net.minecraft.client.renderer.RenderPipelines.DEBUG_FILLED_SNIPPET)
                    .withLocation(Identifier.fromNamespaceAndPath("blocks", "pipeline/xray_quads"))
                    .withCull(false)
                    .withDepthTestFunction(com.mojang.blaze3d.platform.DepthTestFunction.NO_DEPTH_TEST)
                    .withDepthWrite(false)
                    .build();
            xrayQuads = net.minecraft.client.renderer.rendertype.RenderType.create("blocks_xray_quads",
                    net.minecraft.client.renderer.rendertype.RenderSetup.builder(pipe).sortOnUpload().createRenderSetup());
        }
        return xrayQuads;
    }

    public static net.minecraft.client.renderer.rendertype.RenderType lines(boolean xray) {
        if (!xray) return net.minecraft.client.renderer.rendertype.RenderTypes.lines();
        if (xrayLines == null) {
            var pipe = com.mojang.blaze3d.pipeline.RenderPipeline.builder(net.minecraft.client.renderer.RenderPipelines.LINES_SNIPPET)
                    .withLocation(Identifier.fromNamespaceAndPath("blocks", "pipeline/xray_lines"))
                    .withDepthTestFunction(com.mojang.blaze3d.platform.DepthTestFunction.NO_DEPTH_TEST)
                    .withDepthWrite(false)
                    .build();
            xrayLines = net.minecraft.client.renderer.rendertype.RenderType.create("blocks_xray_lines",
                    net.minecraft.client.renderer.rendertype.RenderSetup.builder(pipe)
                            .setLayeringTransform(net.minecraft.client.renderer.rendertype.LayeringTransform.VIEW_OFFSET_Z_LAYERING)
                            .createRenderSetup());
        }
        return xrayLines;
    }
}
