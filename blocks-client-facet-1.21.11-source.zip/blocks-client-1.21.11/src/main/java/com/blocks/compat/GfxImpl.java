package com.blocks.compat;

import com.blocks.render.Gfx;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.PlayerSkin;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix3x2fStack;

public class GfxImpl extends Gfx {
    private final GuiGraphics g;

    public GfxImpl(GuiGraphics g) {
        this.g = g;
    }

    @Override public Matrix3x2fStack pose() { return g.pose(); }
    @Override public int guiWidth() { return g.guiWidth(); }
    @Override public int guiHeight() { return g.guiHeight(); }

    @Override
    public void fill(int x1, int y1, int x2, int y2, int color) {
        g.fill(x1, y1, x2, y2, color);
    }

    @Override
    public void gradientV(int x1, int y1, int x2, int y2, int top, int bottom) {
        g.fillGradient(x1, y1, x2, y2, top, bottom);
    }

    @Override
    protected void textRaw(String text, int x, int y, int color, boolean shadow) {
        g.drawString(font, text, x, y, color, shadow);
    }

    @Override
    protected void textSeq(net.minecraft.util.FormattedCharSequence text, int x, int y, int color, boolean shadow) {
        g.drawString(font, text, x, y, color, shadow);
    }

    @Override
    public void blit(Identifier tex, int x, int y, int w, int h, float u, float v, int uw, int vh, int texW, int texH, int color) {
        g.blit(RenderPipelines.GUI_TEXTURED, tex, x, y, u, v, w, h, uw, vh, texW, texH, color);
    }

    @Override
    public void head(PlayerSkin skin, int x, int y, int size) {
        PlayerFaceRenderer.draw(g, skin, x, y, size);
    }

    @Override
    public void item(ItemStack stack, int x, int y) {
        g.renderItem(stack, x, y);
    }

    @Override public void scissor(int x1, int y1, int x2, int y2) { g.enableScissor(x1, y1, x2, y2); }
    @Override public void noScissor() { g.disableScissor(); }
    @Override public void blur() { g.blurBeforeThisStratum(); }

    @Override
    public void entityFollowsMouse(int x1, int y1, int x2, int y2, int size, float yOffset, float mouseX, float mouseY,
                                   net.minecraft.world.entity.LivingEntity entity) {
        net.minecraft.client.gui.screens.inventory.InventoryScreen.renderEntityInInventoryFollowsMouse(g, x1, y1, x2, y2, size, yOffset, mouseX, mouseY, entity);
    }
}
