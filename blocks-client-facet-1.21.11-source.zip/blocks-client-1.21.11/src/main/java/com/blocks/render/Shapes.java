package com.blocks.render;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import com.blocks.util.Theme;
import org.joml.Matrix3x2fStack;

import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

/**
 * Anti-aliased shapes (rounded rects, rings, soft glows, radial petals).
 *
 * Shapes are rasterised once into white alpha-mask textures at the exact real
 * pixel size and blitted 1:1 with a tint, so edges stay smooth at any GUI scale
 * and the same code works on every Minecraft version (it only needs fill/blit).
 *
 * Callers pass coordinates in "UI units". {@link #begin} sets how many real
 * pixels one UI unit is.
 */
public final class Shapes {
    private record Tex(Identifier id, int w, int h, int ox, int oy) {}

    @FunctionalInterface
    private interface AlphaFn {
        double alpha(double x, double y);
    }

    private static final Map<Long, Tex> CACHE = new HashMap<>();
    private static Gfx g;
    private static float scale = 2;

    private Shapes() {}

    /** @param pixelsPerUnit real screen pixels per UI unit */
    public static void begin(Gfx gfx, float pixelsPerUnit) {
        g = gfx;
        scale = pixelsPerUnit;
    }

    public static Gfx gfx() {
        return g;
    }

    public static float scale() {
        return scale;
    }

    // ------------------------------------------------------------------ texture cache

    /** Packs a shape type and its parameters into a cache key (no per-call string building). */
    private static long K(int type, long a, long b) {
        long h = a * 0x9E3779B97F4A7C15L ^ (b + 0x632BE59BD9B4E019L) * 0xC2B2AE3D27D4EB4FL;
        return ((long) type << 58) ^ (h & 0x03FFFFFFFFFFFFFFL);
    }

    private static Tex texture(long key, int w, int h, int ox, int oy, AlphaFn fn) {
        Tex t = CACHE.get(key);
        if (t != null) return t;
        w = Math.max(1, w);
        h = Math.max(1, h);
        NativeImage img = new NativeImage(w, h, true);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                double a = fn.alpha(x + 0.5, y + 0.5);
                int ai = (int) Math.round(Math.max(0, Math.min(1, a)) * 255);
                img.setPixel(x, y, (ai << 24) | 0xFFFFFF);
            }
        }
        String name = Long.toHexString(key);
        Identifier id = Identifier.fromNamespaceAndPath("blocks", "dyn/" + name);
        DynamicTexture dyn = new DynamicTexture(() -> "blocks:" + name, img);
        dyn.upload();
        Minecraft.getInstance().getTextureManager().register(id, dyn);
        t = new Tex(id, w, h, ox, oy);
        CACHE.put(key, t);
        return t;
    }

    private static double clamp01(double v) {
        return Math.max(0, Math.min(1, v));
    }

    private static Tex circleTex(int r) {
        return texture(K(1, r, 0), r * 2, r * 2, 0, 0, (x, y) -> clamp01(r - Math.hypot(x - r, y - r) + 0.5));
    }

    private static Tex ringTex(int r, int t) {
        return texture(K(2, r, t), r * 2, r * 2, 0, 0, (x, y) -> {
            double d = Math.hypot(x - r, y - r);
            return clamp01(r - d + 0.5) * clamp01(d - (r - t) + 0.5);
        });
    }

    private static Tex glowTex(int r, int size) {
        int c = r + size;
        return texture(K(3, r, size), c * 2, c * 2, 0, 0, (x, y) -> {
            double d = Math.hypot(x - c, y - c) - r;
            if (d <= 0) return 0;
            double f = 1 - d / size;
            return f <= 0 ? 0 : f * f * f;
        });
    }

    // ------------------------------------------------------------------ raw-pixel space

    private static void push() {
        Matrix3x2fStack pose = g.pose();
        pose.pushMatrix();
        pose.scale(1f / scale, 1f / scale);
    }

    private static void pop() {
        g.pose().popMatrix();
    }

    private static int px(double units) {
        return (int) Math.round(units * scale);
    }

    // ------------------------------------------------------------------ public shapes

    public static void rect(double x, double y, double w, double h, int color) {
        push();
        int X = px(x), Y = px(y);
        g.fill(X, Y, px(x + w), px(y + h), color);
        pop();
    }

    public static void roundRect(double x, double y, double w, double h, double radius, int color) {
        if ((color >>> 24) == 0) return;
        push();
        int X = px(x), Y = px(y), W = px(x + w) - X, H = px(y + h) - Y;
        int R = Math.max(1, Math.min(px(radius), Math.min(W, H) / 2));
        Tex t = circleTex(R);
        int s = R * 2;
        g.blit(t.id, X, Y, R, R, 0, 0, R, R, s, s, color);
        g.blit(t.id, X + W - R, Y, R, R, R, 0, R, R, s, s, color);
        g.blit(t.id, X, Y + H - R, R, R, 0, R, R, R, s, s, color);
        g.blit(t.id, X + W - R, Y + H - R, R, R, R, R, R, R, s, s, color);
        if (W > 2 * R) g.fill(X + R, Y, X + W - R, Y + H, color);
        if (H > 2 * R) {
            g.fill(X, Y + R, X + R, Y + H - R, color);
            g.fill(X + W - R, Y + R, X + W, Y + H - R, color);
        }
        pop();
    }

    public static void roundOutline(double x, double y, double w, double h, double radius, double thickness, int color) {
        if ((color >>> 24) == 0) return;
        push();
        int X = px(x), Y = px(y), W = px(x + w) - X, H = px(y + h) - Y;
        int R = Math.max(1, Math.min(px(radius), Math.min(W, H) / 2));
        int T = Math.max(1, Math.min(R, px(thickness)));
        Tex t = ringTex(R, T);
        int s = R * 2;
        g.blit(t.id, X, Y, R, R, 0, 0, R, R, s, s, color);
        g.blit(t.id, X + W - R, Y, R, R, R, 0, R, R, s, s, color);
        g.blit(t.id, X, Y + H - R, R, R, 0, R, R, R, s, s, color);
        g.blit(t.id, X + W - R, Y + H - R, R, R, R, R, R, R, s, s, color);
        if (W > 2 * R) {
            g.fill(X + R, Y, X + W - R, Y + T, color);
            g.fill(X + R, Y + H - T, X + W - R, Y + H, color);
        }
        if (H > 2 * R) {
            g.fill(X, Y + R, X + T, Y + H - R, color);
            g.fill(X + W - T, Y + R, X + W, Y + H - R, color);
        }
        pop();
    }

    /** Soft glow around (outside) a rounded rect. */
    public static void glow(double x, double y, double w, double h, double radius, double size, int color) {
        if ((color >>> 24) == 0 || size <= 0) return;
        push();
        int X = px(x), Y = px(y), W = px(x + w) - X, H = px(y + h) - Y;
        int R = Math.max(1, Math.min(px(radius), Math.min(W, H) / 2));
        int G = Math.max(1, px(size));
        int C = R + G, s = C * 2;
        Tex t = glowTex(R, G);
        int x0 = X - G, y0 = Y - G, x1 = X + W + G, y1 = Y + H + G;
        g.blit(t.id, x0, y0, C, C, 0, 0, C, C, s, s, color);
        g.blit(t.id, x1 - C, y0, C, C, C, 0, C, C, s, s, color);
        g.blit(t.id, x0, y1 - C, C, C, 0, C, C, C, s, s, color);
        g.blit(t.id, x1 - C, y1 - C, C, C, C, C, C, C, s, s, color);
        int midW = W - 2 * R, midH = H - 2 * R;
        if (midW > 0) {
            g.blit(t.id, x0 + C, y0, midW, C, C, 0, 1, C, s, s, color);
            g.blit(t.id, x0 + C, y1 - C, midW, C, C, C, 1, C, s, s, color);
        }
        if (midH > 0) {
            g.blit(t.id, x0, y0 + C, C, midH, 0, C, C, 1, s, s, color);
            g.blit(t.id, x1 - C, y0 + C, C, midH, C, C, C, 1, s, s, color);
        }
        pop();
    }

    public static void circle(double cx, double cy, double r, int color) {
        roundRect(cx - r, cy - r, r * 2, r * 2, r, color);
    }

    public static void ring(double cx, double cy, double r, double thickness, int color) {
        roundOutline(cx - r, cy - r, r * 2, r * 2, r, thickness, color);
    }

    public static void circleGlow(double cx, double cy, double r, double size, int color) {
        glow(cx - r, cy - r, r * 2, r * 2, r, size, color);
    }

    /** A rounded rect with fill, outline and optional glow in one call. */
    public static void panel(double x, double y, double w, double h, double r, int fill, int outline, int glowColor, double glowSize) {
        if (glowSize > 0) glow(x, y, w, h, r, glowSize, glowColor);
        roundRect(x, y, w, h, r, fill);
        if ((outline >>> 24) != 0) roundOutline(x, y, w, h, r, 1, outline);
    }

    // ------------------------------------------------------------------ rays and gradient capsules

    public enum Layer { FILL, STROKE, GLOW, SHEEN }

    /**
     * A sun ray: a rounded annular sector around (cx, cy), widening outward.
     * Angles in radians, 0 = right, clockwise on screen.
     */
    public static void ray(double cx, double cy, double angle, double halfAngle, double innerR, double outerR,
                           double rounding, double glowSize, Layer layer, int color) {
        if ((color >>> 24) == 0) return;
        final double sc = scale;
        final double r0 = innerR * sc, r1 = outerR * sc, rc = rounding * sc, gs = Math.max(1, glowSize * sc);
        final double ha = halfAngle;
        double margin = gs + 2;
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i <= 24; i++) {
            double a = angle - ha + 2 * ha * i / 24.0;
            for (double rr : new double[]{r0, r1}) {
                double px = Math.cos(a) * rr, py = Math.sin(a) * rr;
                minX = Math.min(minX, px); maxX = Math.max(maxX, px);
                minY = Math.min(minY, py); maxY = Math.max(maxY, py);
            }
        }
        int ox = (int) Math.floor(minX - margin), oy = (int) Math.floor(minY - margin);
        int w = (int) Math.ceil(maxX + margin) - ox, h = (int) Math.ceil(maxY + margin) - oy;
        long key = K(5, Double.doubleToLongBits(angle) * 31 + Double.doubleToLongBits(ha) + layer.ordinal(),
                (long) r0 << 40 | (long) r1 << 24 | (long) rc << 12 | (long) gs);
        Tex t = texture(key, w, h, ox, oy, (x, y) -> {
            double d = sectorSdf(x + ox, y + oy, angle, ha, r0, r1, rc);
            return switch (layer) {
                case FILL -> {
                    double a = clamp01(0.5 - d);
                    double rho = Math.hypot(x + ox, y + oy);
                    // Light gathers toward the tip of the ray.
                    yield a * (0.55 + 0.45 * clamp01((rho - r0) / (r1 - r0)));
                }
                case STROKE -> clamp01(1.2 - Math.abs(d + 0.7));
                case SHEEN -> clamp01(0.5 - d) * 0.5;
                case GLOW -> {
                    if (d <= 0) yield 0;
                    double f = 1 - d / gs;
                    yield f <= 0 ? 0 : f * f;
                }
            };
        });
        push();
        g.blit(t.id, px(cx) + t.ox, px(cy) + t.oy, t.w, t.h, color);
        pop();
    }

    private static double sectorSdf(double x, double y, double angle, double ha, double r0, double r1, double rc) {
        double rho = Math.hypot(x, y);
        double phi = Math.atan2(y, x) - angle;
        phi = Math.atan2(Math.sin(phi), Math.cos(phi));
        double u = rho - (r0 + r1) / 2;
        double v = phi * Math.max(rho, 1);
        double a = (r1 - r0) / 2 - rc;
        double b = ha * Math.max(rho, 1) - rc;
        double qx = Math.abs(u) - a, qy = Math.abs(v) - b;
        return Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) - rc;
    }

    /** A rounded rect filled with a left-to-right gradient from a to b. */
    public static void gradientRoundRect(double x, double y, double w, double h, double radius, int a, int b) {
        roundRect(x, y, w, h, radius, a);
        if ((b >>> 24) == 0) return;
        push();
        int X = px(x), Y = px(y), W = px(x + w) - X, H = px(y + h) - Y;
        final int R = Math.max(1, Math.min(px(radius), Math.min(W, H) / 2));
        final int fw = W, fh = H;
        Tex t = texture(K(9, (long) W << 20 | H, R), W, H, 0, 0, (px, py) -> {
            double qx = Math.max(Math.abs(px - fw / 2.0) - (fw / 2.0 - R), 0);
            double qy = Math.max(Math.abs(py - fh / 2.0) - (fh / 2.0 - R), 0);
            double inside = clamp01(R - Math.hypot(qx, qy) + 0.5);
            return inside * (px / fw);
        });
        g.blit(t.id, X, Y, W, H, b);
        pop();
    }

    // ------------------------------------------------------------------ textures: grain, dot grid, crop marks

    /** Fine film grain over an area (tiled 256px texture, a handful of blits). */
    public static void grain(double x, double y, double w, double h, int color) {
        if ((color >>> 24) == 0) return;
        final int T = 256;
        // Hash-based noise: only evaluated once, when the texture is first built.
        Tex t = texture(K(7, T, 0), T, T, 0, 0, (px, py) -> {
            int n = (int) px * 374761393 + (int) py * 668265263;
            n = (n ^ (n >>> 13)) * 1274126177;
            return ((n ^ (n >>> 16)) & 0xFFFF) / 65535.0 * 0.9;
        });
        tile(t, x, y, w, h, color);
    }

    /** A faint dot grid with the given spacing (UI units). */
    public static void dotGrid(double x, double y, double w, double h, double spacing, int color) {
        if ((color >>> 24) == 0) return;
        final int P = Math.max(4, px(spacing));
        final int N = Math.max(1, 192 / P);
        final int T = P * N;
        final double r = Math.max(0.6, scale * 0.55);
        Tex t = texture(K(8, P, 0), T, T, 0, 0, (px, py) -> {
            double cx = (Math.floor(px / P) + 0.5) * P, cy = (Math.floor(py / P) + 0.5) * P;
            return clamp01(r - Math.hypot(px - cx, py - cy) + 0.5);
        });
        tile(t, x, y, w, h, color);
    }

    private static void tile(Tex t, double x, double y, double w, double h, int color) {
        push();
        int X = px(x), Y = px(y), W = px(x + w) - X, H = px(y + h) - Y;
        for (int oy = 0; oy < H; oy += t.h) {
            int th = Math.min(t.h, H - oy);
            for (int ox = 0; ox < W; ox += t.w) {
                int tw = Math.min(t.w, W - ox);
                g.blit(t.id, X + ox, Y + oy, tw, th, 0, 0, tw, th, t.w, t.h, color);
            }
        }
        pop();
    }

    /** Camera-style crop marks on the four corners of a rect. */
    public static void cropMarks(double x, double y, double w, double h, double len, double thick, int color) {
        rect(x, y, len, thick, color);
        rect(x, y, thick, len, color);
        rect(x + w - len, y, len, thick, color);
        rect(x + w - thick, y, thick, len, color);
        rect(x, y + h - thick, len, thick, color);
        rect(x, y + h - len, thick, len, color);
        rect(x + w - len, y + h - thick, len, thick, color);
        rect(x + w - thick, y + h - len, thick, len, color);
    }

    // ------------------------------------------------------------------ wave line

    /** A thin sine wave (the "shoreline" divider). Seamless tiles of one period each. */
    public static void wave(double x, double y, double w, double amplitude, double period, double thickness, int color) {
        if ((color >>> 24) == 0 || w <= 0) return;
        final int P = Math.max(4, px(period));
        final double A = amplitude * scale, T = Math.max(0.8, thickness * scale);
        final int H = (int) Math.ceil(2 * A + T + 3);
        final double mid = H / 2.0;
        Tex t = texture(K(6, P, (long) (A * 10) * 100000 + (long) (T * 10)), P, H, 0, 0, (px, py) -> {
            double fx = 2 * Math.PI * px / P;
            double cy = mid + A * Math.sin(fx);
            double slope = A * 2 * Math.PI / P * Math.cos(fx);
            double d = Math.abs(py - cy) / Math.sqrt(1 + slope * slope);
            return clamp01(T / 2 - d + 0.5);
        });
        push();
        int X = px(x), Y = px(y) - H / 2, W = px(x + w) - X;
        for (int off = 0; off < W; off += P) {
            int seg = Math.min(P, W - off);
            g.blit(t.id, X + off, Y, seg, H, 0, 0, seg, H, P, H, color);
        }
        pop();
    }

    // ------------------------------------------------------------------ vector icons

    /**
     * Anti-aliased icons drawn from signed distance functions, so they stay crisp at
     * any scale. Names: sun, gear, swords, eye, grid, star, star_filled, close,
     * search, chevron_left, chevron_right, check.
     */
    public static void icon(String name, double cx, double cy, double size, int color) {
        if ((color >>> 24) == 0) return;
        int S = Math.max(4, px(size));
        final double half = S / 2.0;
        Tex t = texture(K(4, name.hashCode(), S), S, S, 0, 0, (x, y) -> {
            double ux = (x - half) / half, uy = (y - half) / half;
            double d = iconSdf(name, ux, uy);
            return clamp01(0.5 - d * half);
        });
        push();
        g.blit(t.id, px(cx) - S / 2, px(cy) - S / 2, S, S, color);
        pop();
    }

    private static double iconSdf(String name, double x, double y) {
        switch (name) {
            case "sun": {
                double d = Math.hypot(x, y) - 0.34;
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4;
                    double c = Math.cos(a), s = Math.sin(a);
                    d = Math.min(d, seg(x, y, c * 0.56, s * 0.56, c * 0.84, s * 0.84) - 0.075);
                }
                return d;
            }
            case "gear": {
                double r = Math.hypot(x, y), th = Math.atan2(y, x);
                double tooth = clamp01((Math.cos(th * 8) - 0.15) * 3.2);
                double outer = r - (0.6 + 0.2 * tooth);
                return Math.max(outer, 0.25 - r);
            }
            case "swords": {
                double d = sword(x, y);
                return Math.min(d, sword(-x, y));
            }
            case "eye": {
                double lens = Math.max(Math.hypot(x, y - 0.62) - 1.06, Math.hypot(x, y + 0.62) - 1.06);
                double ring = Math.abs(lens) - 0.07;
                return Math.min(ring, Math.hypot(x, y) - 0.2);
            }
            case "grid": {
                double d = roundBox(x + 0.4, y + 0.4, 0.27, 0.27, 0.08);
                d = Math.min(d, roundBox(x + 0.4, y - 0.4, 0.27, 0.27, 0.08));
                d = Math.min(d, roundBox(x - 0.4, y - 0.4, 0.27, 0.27, 0.08));
                // Top-right square sits rotated, like a sparkle.
                double rx = (x - 0.4 + y + 0.4) * 0.7071, ry = (y + 0.4 - (x - 0.4)) * 0.7071;
                return Math.min(d, roundBox(rx, ry, 0.25, 0.25, 0.06));
            }
            case "star":
                return Math.abs(star(x, y, 0.82, 0.42)) - 0.065;
            case "star_filled":
                return star(x, y, 0.82, 0.42);
            case "close":
                return Math.min(seg(x, y, -0.5, -0.5, 0.5, 0.5), seg(x, y, -0.5, 0.5, 0.5, -0.5)) - 0.1;
            case "search":
                return Math.min(Math.abs(Math.hypot(x + 0.14, y + 0.14) - 0.44) - 0.09, seg(x, y, 0.2, 0.2, 0.62, 0.62) - 0.1);
            case "chevron_left":
                return Math.min(seg(x, y, 0.22, -0.55, -0.28, 0), seg(x, y, -0.28, 0, 0.22, 0.55)) - 0.11;
            case "chevron_right":
                return Math.min(seg(x, y, -0.22, -0.55, 0.28, 0), seg(x, y, 0.28, 0, -0.22, 0.55)) - 0.11;
            case "sunset": {
                // Half sun sitting on the horizon with two waves below.
                double sun = Math.max(Math.hypot(x, y - 0.12) - 0.5, y - 0.12);
                double rays = 1e9;
                for (int i = 0; i < 5; i++) {
                    double a = Math.PI + i * Math.PI / 4;
                    double c = Math.cos(a), si = Math.sin(a);
                    rays = Math.min(rays, seg(x, y, c * 0.66, 0.12 + si * 0.66, c * 0.86, 0.12 + si * 0.86) - 0.055);
                }
                double horizon = seg(x, y, -0.9, 0.22, 0.9, 0.22) - 0.05;
                double w1 = Math.abs(y - 0.45 - 0.06 * Math.sin(x * 9)) - 0.045;
                w1 = Math.max(w1, Math.abs(x) - 0.7);
                double w2 = Math.abs(y - 0.66 - 0.05 * Math.sin(x * 9 + 1.6)) - 0.04;
                w2 = Math.max(w2, Math.abs(x) - 0.45);
                return Math.min(Math.min(sun, rays), Math.min(horizon, Math.min(w1, w2)));
            }
            case "sparkle": {
                double ax = Math.abs(x), ay = Math.abs(y);
                double d = Math.pow(Math.pow(ax, 0.5) + Math.pow(ay, 0.5), 2) - 0.8;
                return d * 0.5;
            }
            case "half":
                return Math.max(Math.hypot(x, y) - 0.92, x + y * 0.0);
            case "home": {
                double body = roundBox(x, y - 0.3, 0.44, 0.32, 0.06);
                double roof = Math.min(seg(x, y, -0.7, 0.02, 0, -0.62), seg(x, y, 0, -0.62, 0.7, 0.02)) - 0.1;
                return Math.min(body, roof);
            }
            case "minus":
                return seg(x, y, -0.55, 0, 0.55, 0) - 0.1;
            case "plus":
                return Math.min(seg(x, y, -0.55, 0, 0.55, 0), seg(x, y, 0, -0.55, 0, 0.55)) - 0.1;
            case "check":
                return Math.min(seg(x, y, -0.55, 0.02, -0.15, 0.42), seg(x, y, -0.15, 0.42, 0.58, -0.4)) - 0.11;
            default:
                return Math.hypot(x, y) - 0.5;
        }
    }

    /** One sword from bottom-right handle to top-left tip. */
    private static double sword(double x, double y) {
        double blade = seg(x, y, -0.72, -0.72, 0.36, 0.36) - 0.085;
        double tip = seg(x, y, -0.82, -0.82, -0.72, -0.72) - 0.03;
        double guard = seg(x, y, 0.2, 0.52, 0.52, 0.2) - 0.075;
        double handle = seg(x, y, 0.4, 0.4, 0.72, 0.72) - 0.07;
        return Math.min(Math.min(blade, tip), Math.min(guard, handle));
    }

    private static double seg(double px, double py, double ax, double ay, double bx, double by) {
        double pax = px - ax, pay = py - ay, bax = bx - ax, bay = by - ay;
        double h = clamp01((pax * bax + pay * bay) / (bax * bax + bay * bay));
        return Math.hypot(pax - bax * h, pay - bay * h);
    }

    private static double roundBox(double x, double y, double hx, double hy, double r) {
        double qx = Math.abs(x) - hx + r, qy = Math.abs(y) - hy + r;
        return Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) - r;
    }

    /** Inigo Quilez's 5-point star distance, flipped so it points up on screen. */
    private static double star(double x, double y, double r, double rf) {
        double k1x = 0.809016994375, k1y = -0.587785252292, k2x = -k1x, k2y = k1y;
        double px = Math.abs(x), py = -y;
        double d1 = Math.max(k1x * px + k1y * py, 0) * 2;
        px -= d1 * k1x;
        py -= d1 * k1y;
        double d2 = Math.max(k2x * px + k2y * py, 0) * 2;
        px -= d2 * k2x;
        py -= d2 * k2y;
        px = Math.abs(px);
        py -= r;
        double bax = rf * -k1y, bay = rf * k1x - 1;
        double h = Math.max(0, Math.min(r, (px * bax + py * bay) / (bax * bax + bay * bay)));
        double lx = px - bax * h, ly = py - bay * h;
        return Math.hypot(lx, ly) * Math.signum(py * bax - px * bay);
    }

    /** Releases all generated textures (call when the GUI scale changes a lot). */
    public static void clear() {
        var tm = Minecraft.getInstance().getTextureManager();
        for (Tex t : CACHE.values()) tm.release(t.id);
        CACHE.clear();
    }

    // ------------------------------------------------------------------ scenery (hub)

    /**
     * A palm tree silhouette: curved tapered trunk and serrated drooping fronds.
     * Rasterised once per size/variant; drawn with its base at (baseX, baseY) and
     * rotated around the base by {@code swayDeg} so it can sway in the wind.
     */
    public static void palm(double baseX, double baseY, double height, int variant, double swayDeg, boolean mirror, int color) {
        int H = Math.max(8, px(height));
        int W = H;
        int v = Math.floorMod(variant, 3);
        Tex t = texture(K(20, H, v), W, H, 0, 0, palmFn(W, H, v));
        push();
        Matrix3x2fStack pose = g.pose();
        pose.pushMatrix();
        pose.translate((float) (baseX * scale), (float) (baseY * scale));
        pose.rotate((float) Math.toRadians(swayDeg));
        if (mirror) pose.scale(-1, 1);
        // Trunk base sits at 30% of the texture width, bottom edge.
        g.blit(t.id, (int) (-W * 0.30), -H, W, H, 0, 0, W, H, W, H, color);
        pose.popMatrix();
        pop();
    }

    private static AlphaFn palmFn(int W, int H, int variant) {
        java.util.Random r = new java.util.Random(1234L + variant * 77L);
        List<double[]> segs = new ArrayList<>(); // x0,y0,w0,x1,y1,w1,serrate
        double bx = W * 0.30, by = H, lean = (0.10 + 0.08 * variant) * W;
        double tx = bx + lean, ty = H * 0.30;
        // Trunk: quadratic curve, bulging the other way a little.
        double cx = bx + lean * 0.15, cy = H * 0.62;
        int n = 18;
        double px0 = bx, py0 = by, pw0 = H * 0.030;
        for (int i = 1; i <= n; i++) {
            double t = i / (double) n;
            double x = (1 - t) * (1 - t) * bx + 2 * (1 - t) * t * cx + t * t * tx;
            double y = (1 - t) * (1 - t) * by + 2 * (1 - t) * t * cy + t * t * ty;
            double w = Math.max(H * (0.036 - 0.016 * t), 1.4) * (1 - 0.12 * Math.abs(Math.sin(t * 40)));
            segs.add(new double[]{px0, py0, pw0, x, y, w, 0});
            px0 = x; py0 = y; pw0 = w;
        }
        // Fronds: arcs out of the crown, drooping under their own weight.
        int fronds = 10 + variant;
        for (int f = 0; f < fronds; f++) {
            double ang = Math.toRadians(-178 + f * (176.0 / (fronds - 1)) + (r.nextDouble() - 0.5) * 10);
            boolean inner = f % 2 == 1;
            double len = H * (inner ? 0.20 + r.nextDouble() * 0.06 : 0.28 + r.nextDouble() * 0.08);
            double droop = H * (0.06 + 0.16 * Math.abs(Math.cos(ang)));
            double ex = tx + Math.cos(ang) * len, ey = ty + Math.sin(ang) * len * 0.55 + droop;
            double mx = tx + Math.cos(ang) * len * 0.5, my = ty + Math.sin(ang) * len * 0.55 - H * 0.03;
            int m = 16;
            double ax = tx, ay = ty, aw = H * 0.006;
            for (int i = 1; i <= m; i++) {
                double t = i / (double) m;
                double x = (1 - t) * (1 - t) * tx + 2 * (1 - t) * t * mx + t * t * ex;
                double y = (1 - t) * (1 - t) * ty + 2 * (1 - t) * t * my + t * t * ey;
                double w = Math.max(H * 0.045, 2.4) * Math.sin(Math.PI * Math.min(1, t * 1.05)) + H * 0.003;
                segs.add(new double[]{ax, ay, aw, x, y, w, 1});
                ax = x; ay = y; aw = w;
            }
        }
        // Coconuts.
        double[][] nuts = {{tx - H * 0.012, ty + H * 0.03}, {tx + H * 0.02, ty + H * 0.025}, {tx + H * 0.004, ty + H * 0.045}};
        final double[][] S = segs.toArray(new double[0][]);
        return (x, y) -> {
            double best = -1e9;
            for (double[] sg : S) {
                double dx = sg[3] - sg[0], dy = sg[4] - sg[1];
                double l2 = dx * dx + dy * dy;
                double t = l2 == 0 ? 0 : Math.max(0, Math.min(1, ((x - sg[0]) * dx + (y - sg[1]) * dy) / l2));
                double qx = sg[0] + dx * t, qy = sg[1] + dy * t;
                double d = Math.hypot(x - qx, y - qy);
                double w = sg[2] + (sg[5] - sg[2]) * t;
                if (sg[6] > 0) w *= 0.55 + 0.45 * Math.abs(Math.sin((qx * 0.7 + qy * 0.7) * 1.4));
                best = Math.max(best, w - d);
            }
            for (double[] c : nuts) best = Math.max(best, H * 0.016 - Math.hypot(x - c[0], y - c[1]));
            return clamp01(best + 0.5);
        };
    }

    /**
     * A retro sunset sun: a disc whose lower half is cut by horizontal bands that
     * get thicker toward the horizon. Top colour fades into the bottom colour.
     */
    public static void retroSun(double cx, double cy, double r, int top, int bottom, double horizon) {
        int R = Math.max(4, px(r));
        int cut = (int) Math.round(horizon * 100);
        Tex disc = texture(K(21, R, cut * 2L), R * 2, R * 2, 0, 0, sunFn(R, false, horizon));
        Tex ramp = texture(K(21, R, cut * 2L + 1), R * 2, R * 2, 0, 0, sunFn(R, true, horizon));
        push();
        int X = px(cx) - R, Y = px(cy) - R;
        g.blit(disc.id, X, Y, R * 2, R * 2, 0, 0, R * 2, R * 2, R * 2, R * 2, top);
        g.blit(ramp.id, X, Y, R * 2, R * 2, 0, 0, R * 2, R * 2, R * 2, R * 2, bottom);
        pop();
    }

    private static AlphaFn sunFn(int R, boolean ramp, double horizon) {
        return (x, y) -> {
            double a = clamp01(R - Math.hypot(x - R, y - R) + 0.5);
            double v = (y - R) / R; // -1 top .. 1 bottom
            a *= clamp01((horizon - v) * R + 0.5); // sunk into the horizon
            if (v > -0.12) {
                // Bands that get thicker toward the horizon.
                double period = R * 0.13;
                double phase = ((y - R * 0.88) % period + period) % period;
                double gap = period * (0.10 + 0.55 * (v + 0.12));
                a *= clamp01(phase - gap + 0.5) * clamp01(period - phase + 0.5);
            }
            if (ramp) a *= clamp01((v + 0.45) / 1.0);
            return a;
        };
    }

    // ------------------------------------------------------------------ facets: polygons, hexagons, iso cubes

    /** Signed distance to a polygon (negative inside), after Inigo Quilez. */
    private static double polySdf(double px, double py, double[] xs, double[] ys) {
        int n = xs.length;
        double d = (px - xs[0]) * (px - xs[0]) + (py - ys[0]) * (py - ys[0]);
        double s = 1;
        for (int i = 0, j = n - 1; i < n; j = i, i++) {
            double ex = xs[j] - xs[i], ey = ys[j] - ys[i];
            double wx = px - xs[i], wy = py - ys[i];
            double t = clamp01((wx * ex + wy * ey) / (ex * ex + ey * ey));
            double bx = wx - ex * t, by = wy - ey * t;
            d = Math.min(d, bx * bx + by * by);
            boolean c1 = py >= ys[i], c2 = py < ys[j], c3 = ex * wy > ey * wx;
            if ((c1 && c2 && c3) || (!c1 && !c2 && !c3)) s = -s;
        }
        return s * Math.sqrt(d);
    }

    /** Moves every edge of a convex polygon inward by {@code by} (used to round its corners). */
    private static double[][] inset(double[] xs, double[] ys, double by) {
        int n = xs.length;
        double area = 0;
        for (int i = 0; i < n; i++) area += xs[i] * ys[(i + 1) % n] - xs[(i + 1) % n] * ys[i];
        double sign = area > 0 ? 1 : -1;
        double[] nx = new double[n], ny = new double[n], c = new double[n];
        for (int i = 0; i < n; i++) {
            double ex = xs[(i + 1) % n] - xs[i], ey = ys[(i + 1) % n] - ys[i], len = Math.hypot(ex, ey);
            // Inward normal (screen y points down).
            nx[i] = -ey / len * sign;
            ny[i] = ex / len * sign;
            c[i] = nx[i] * xs[i] + ny[i] * ys[i] + by;
        }
        double[] ox = new double[n], oy = new double[n];
        for (int i = 0; i < n; i++) {
            int a = (i + n - 1) % n, b = i;
            double det = nx[a] * ny[b] - ny[a] * nx[b];
            if (Math.abs(det) < 1e-9) {
                ox[i] = xs[i] + nx[b] * by;
                oy[i] = ys[i] + ny[b] * by;
            } else {
                ox[i] = (c[a] * ny[b] - ny[a] * c[b]) / det;
                oy[i] = (nx[a] * c[b] - c[a] * nx[b]) / det;
            }
        }
        return new double[][]{ox, oy};
    }

    /**
     * Anti-aliased convex polygon (UI units) with rounded corners. FILL, STROKE (thin edge),
     * GLOW (soft outside) or SHEEN (fill fading toward the bottom, for glass highlights).
     * Pixel-snapped, so shapes that only move are drawn from the same cached texture.
     */
    public static void poly(double[] xs, double[] ys, double rounding, double glowSize, Layer layer, int color) {
        if ((color >>> 24) == 0) return;
        int n = xs.length;
        double[] X = new double[n], Y = new double[n];
        double sx = Math.round(xs[0] * scale) - xs[0] * scale, sy = Math.round(ys[0] * scale) - ys[0] * scale;
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            X[i] = xs[i] * scale + sx;
            Y[i] = ys[i] * scale + sy;
            minX = Math.min(minX, X[i]); maxX = Math.max(maxX, X[i]);
            minY = Math.min(minY, Y[i]); maxY = Math.max(maxY, Y[i]);
        }
        double gs = layer == Layer.GLOW ? Math.max(1, glowSize * scale) : 0;
        int ox = (int) Math.floor(minX - gs - 2), oy = (int) Math.floor(minY - gs - 2);
        int w = (int) Math.ceil(maxX + gs + 2) - ox, h = (int) Math.ceil(maxY + gs + 2) - oy;
        double[] rx = new double[n], ry = new double[n];
        long hash = 1469598103934665603L;
        for (int i = 0; i < n; i++) {
            rx[i] = X[i] - ox;
            ry[i] = Y[i] - oy;
            hash = (hash ^ Math.round(rx[i] * 4)) * 1099511628211L;
            hash = (hash ^ Math.round(ry[i] * 4)) * 1099511628211L;
        }
        double rc = Math.max(0, rounding * scale);
        double[][] in = rc > 0 ? inset(rx, ry, rc) : new double[][]{rx, ry};
        final double[] ix = in[0], iy = in[1];
        final double rr = rc, g2 = gs, top = minY - oy, height = Math.max(1, maxY - minY);
        Tex t = texture(K(22, hash, (long) layer.ordinal() << 40 | Math.round(rc * 4) << 20 | Math.round(gs * 4)), w, h, 0, 0, (x, y) -> {
            double d = polySdf(x, y, ix, iy) - rr;
            return switch (layer) {
                case FILL -> clamp01(0.5 - d);
                case SHEEN -> clamp01(0.5 - d) * clamp01(1 - (y - top) / height);
                case STROKE -> clamp01(1.2 - Math.abs(d + 0.7));
                case GLOW -> {
                    if (d <= 0) yield 0;
                    double f = 1 - d / g2;
                    yield f <= 0 ? 0 : f * f;
                }
            };
        });
        push();
        g.blit(t.id, ox, oy, t.w, t.h, color);
        pop();
    }

    private static final double C30 = Math.cos(Math.PI / 6);

    /** Pointy-top hexagon of radius r (centre to corner). */
    public static void hex(double cx, double cy, double r, double rounding, double glowSize, Layer layer, int color) {
        double[] xs = new double[6], ys = new double[6];
        for (int i = 0; i < 6; i++) {
            double a = Math.toRadians(-90 + 60 * i);
            xs[i] = cx + Math.cos(a) * r;
            ys[i] = cy + Math.sin(a) * r;
        }
        poly(xs, ys, rounding, glowSize, layer, color);
    }

    /**
     * An isometric cube seen from above: three faces of a pointy-top hexagon.
     * Colours for the top, left and right faces, plus an edge colour (0 = none).
     */
    public static void isoCube(double cx, double cy, double r, int top, int left, int right, int edge) {
        double c = r * C30;
        double[] v0 = {cx, cy - r}, v1 = {cx + c, cy - r / 2}, v2 = {cx + c, cy + r / 2}, v3 = {cx, cy + r},
                v4 = {cx - c, cy + r / 2}, v5 = {cx - c, cy - r / 2}, o = {cx, cy};
        double rd = Math.max(0.6, r * 0.06);
        poly(new double[]{v0[0], v1[0], o[0], v5[0]}, new double[]{v0[1], v1[1], o[1], v5[1]}, rd, 0, Layer.FILL, top);
        poly(new double[]{v0[0], v1[0], o[0], v5[0]}, new double[]{v0[1], v1[1], o[1], v5[1]}, rd, 0, Layer.SHEEN, Theme.withAlpha(0xFFFFFFFF, ((top >>> 24) * 60) / 255));
        poly(new double[]{v5[0], o[0], v3[0], v4[0]}, new double[]{v5[1], o[1], v3[1], v4[1]}, rd, 0, Layer.FILL, left);
        poly(new double[]{o[0], v1[0], v2[0], v3[0]}, new double[]{o[1], v1[1], v2[1], v3[1]}, rd, 0, Layer.FILL, right);
        if ((edge >>> 24) != 0) {
            hex(cx, cy, r, rd, 0, Layer.STROKE, edge);
            line(cx, cy, v1[0], v1[1], 0.7, Theme.alphaMul(edge, 0.7));
            line(cx, cy, v5[0], v5[1], 0.7, Theme.alphaMul(edge, 0.7));
            line(cx, cy, v3[0], v3[1], 0.7, Theme.alphaMul(edge, 0.7));
        }
    }

    /** A straight line with rounded caps. */
    public static void line(double x0, double y0, double x1, double y1, double thickness, int color) {
        if ((color >>> 24) == 0) return;
        double len = Math.hypot(x1 - x0, y1 - y0);
        if (len < 0.01) return;
        Matrix3x2fStack pose = g.pose();
        pose.pushMatrix();
        pose.translate((float) x0, (float) y0);
        pose.rotate((float) Math.atan2(y1 - y0, x1 - x0));
        roundRect(-thickness / 2, -thickness / 2, len + thickness, thickness, thickness / 2, color);
        pose.popMatrix();
    }

    /**
     * A "gem" panel: rounded rect with its top-left corner cut at 45 degrees. Nine-sliced from a
     * small canonical texture, so any size reuses the same few textures.
     */
    public static void facetPanel(double x, double y, double w, double h, double radius, double cut, double glowSize, Layer layer, int color) {
        if ((color >>> 24) == 0) return;
        push();
        int R = Math.max(1, px(radius)), CUT = Math.max(R + 1, px(cut)), G = layer == Layer.GLOW ? Math.max(1, px(glowSize)) : 0;
        int M = CUT + R + G + 3;            // corner block size, including the glow margin
        int S = 2 * M + 1;                  // canonical texture: corners plus one stretchable middle pixel
        final int m = M, rr = R, cc = CUT, gg = G;
        Tex t = texture(K(23, (long) layer.ordinal() << 32 | (long) R << 16 | CUT, G), S, S, 0, 0, (px, py) -> {
            // Shape occupies [gg+1, S-gg-1] in both axes.
            double a0 = gg + 1, a1 = S - gg - 1;
            double[] xs = {a0 + cc, a1, a1, a0, a0}, ys = {a0, a0, a1, a1, a0 + cc};
            double[][] in = inset(xs, ys, rr);
            double d = polySdf(px, py, in[0], in[1]) - rr;
            return switch (layer) {
                case FILL -> clamp01(0.5 - d);
                case SHEEN -> clamp01(0.5 - d) * clamp01(1 - (py - a0) / (2.0 * m));
                case STROKE -> clamp01(1.2 - Math.abs(d + 0.7));
                case GLOW -> {
                    if (d <= 0) yield 0;
                    double f = 1 - d / gg;
                    yield f <= 0 ? 0 : f * f;
                }
            };
        });
        int X = px(x) - G - 1, Y = px(y) - G - 1, W = px(x + w) - px(x) + 2 * G + 2, H = px(y + h) - px(y) + 2 * G + 2;
        int midW = Math.max(0, W - 2 * M), midH = Math.max(0, H - 2 * M);
        int cw = Math.min(M, W / 2), ch = Math.min(M, H / 2);
        g.blit(t.id, X, Y, cw, ch, 0, 0, cw, ch, S, S, color);
        g.blit(t.id, X + W - cw, Y, cw, ch, S - cw, 0, cw, ch, S, S, color);
        g.blit(t.id, X, Y + H - ch, cw, ch, 0, S - ch, cw, ch, S, S, color);
        g.blit(t.id, X + W - cw, Y + H - ch, cw, ch, S - cw, S - ch, cw, ch, S, S, color);
        if (midW > 0) {
            g.blit(t.id, X + M, Y, midW, ch, M, 0, 1, ch, S, S, color);
            g.blit(t.id, X + M, Y + H - ch, midW, ch, M, S - ch, 1, ch, S, S, color);
        }
        if (midH > 0) {
            g.blit(t.id, X, Y + M, cw, midH, 0, M, cw, 1, S, S, color);
            g.blit(t.id, X + W - cw, Y + M, cw, midH, S - cw, M, cw, 1, S, S, color);
        }
        if (midW > 0 && midH > 0) g.blit(t.id, X + M, Y + M, midW, midH, M, M, 1, 1, S, S, color);
        pop();
    }
}
