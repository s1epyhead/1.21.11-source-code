package com.blocks.render;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

/** World position to screen position (GUI units), for labels drawn on the HUD. */
public final class Projection {
    private static final Minecraft mc = Minecraft.getInstance();
    private static Vec3 camPos, fwd, right, up;
    private static double tanHalf, aspect;
    private static long frame = -1;

    private Projection() {}

    private static void update() {
        long now = System.nanoTime() / 4_000_000L; // refresh at most every 4 ms
        if (now == frame) return;
        frame = now;
        Camera cam = com.blocks.compat.Compat.camera();
        camPos = cam.position();
        double yaw = Math.toRadians(cam.yRot()), pitch = Math.toRadians(cam.xRot());
        fwd = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        right = fwd.cross(new Vec3(0, 1, 0)).normalize();
        up = right.cross(fwd);
        tanHalf = Math.tan(Math.toRadians(mc.options.fov().get()) / 2);
        aspect = (double) mc.getWindow().getWidth() / Math.max(1, mc.getWindow().getHeight());
    }

    /** @return {x, y, distance} in GUI units, or null when behind the camera. */
    public static double[] toGui(Vec3 world, int guiW, int guiH) {
        update();
        Vec3 rel = world.subtract(camPos);
        double z = rel.dot(fwd);
        if (z < 0.2) return null;
        double x = rel.dot(right), y = rel.dot(up);
        double sx = guiW / 2.0 + (x / (z * tanHalf * aspect)) * guiW / 2.0;
        double sy = guiH / 2.0 - (y / (z * tanHalf)) * guiH / 2.0;
        return new double[]{sx, sy, rel.length()};
    }
}
