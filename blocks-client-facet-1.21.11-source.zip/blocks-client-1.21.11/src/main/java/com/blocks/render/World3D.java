package com.blocks.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Small immediate-style helpers for drawing in the world (boxes, rings, halos).
 * Geometry is submitted through Minecraft's SubmitNodeCollector, which exists in
 * both 1.21.11 and 26.x; only the event that hands it to us differs (see Compat).
 */
public final class World3D {
    private static PoseStack pose;
    private static SubmitNodeCollector collector;
    private static Vec3 cam = Vec3.ZERO;
    private static boolean xray;

    /**
     * Geometry is batched: everything drawn in a frame goes out as one submit per
     * render type (instead of one per box), which keeps hundreds of ESP boxes cheap.
     * Batches are reused frame to frame; each frame's submits run before the next begins.
     */
    private static final class Batch {
        final boolean lines;
        float[] pos = new float[3 * 512];
        int[] col = new int[512];
        float[] width;
        int n;

        Batch(boolean lines) {
            this.lines = lines;
            if (lines) width = new float[512];
        }

        void add(float x, float y, float z, int c, float w) {
            if (n == col.length) {
                pos = java.util.Arrays.copyOf(pos, pos.length * 2);
                col = java.util.Arrays.copyOf(col, col.length * 2);
                if (width != null) width = java.util.Arrays.copyOf(width, width.length * 2);
            }
            pos[3 * n] = x;
            pos[3 * n + 1] = y;
            pos[3 * n + 2] = z;
            col[n] = c;
            if (width != null) width[n] = w;
            n++;
        }
    }

    private static final Batch QUADS = new Batch(false), QUADS_XRAY = new Batch(false);
    private static final Batch LINES = new Batch(true), LINES_XRAY = new Batch(true);

    private World3D() {}

    public static void begin(PoseStack poseStack, SubmitNodeCollector submits) {
        pose = poseStack;
        collector = submits;
        cam = com.blocks.compat.Compat.camera().position();
        xray = false;
        QUADS.n = QUADS_XRAY.n = LINES.n = LINES_XRAY.n = 0;
    }

    /** Sends this frame's batched geometry. */
    public static void end() {
        if (collector == null) return;
        flush(QUADS, false);
        flush(QUADS_XRAY, true);
        flush(LINES, false);
        flush(LINES_XRAY, true);
    }

    private static void flush(Batch b, boolean see) {
        if (b.n == 0) return;
        final int count = b.n;
        if (!b.lines) {
            collector.submitCustomGeometry(pose, com.blocks.compat.Compat.quads(see), (p, vc) -> {
                float[] v = b.pos;
                int[] c = b.col;
                for (int i = 0; i < count; i++) vc.addVertex(p, v[3 * i], v[3 * i + 1], v[3 * i + 2]).setColor(c[i]);
            });
        } else {
            collector.submitCustomGeometry(pose, com.blocks.compat.Compat.lines(see), (p, vc) -> {
                float[] v = b.pos;
                int[] c = b.col;
                float[] w = b.width;
                for (int i = 0; i + 1 < count; i += 2) {
                    float x0 = v[3 * i], y0 = v[3 * i + 1], z0 = v[3 * i + 2];
                    float x1 = v[3 * i + 3], y1 = v[3 * i + 4], z1 = v[3 * i + 5];
                    float nx = x1 - x0, ny = y1 - y0, nz = z1 - z0;
                    float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
                    if (len > 0) {
                        nx /= len;
                        ny /= len;
                        nz /= len;
                    }
                    vc.addVertex(p, x0, y0, z0).setColor(c[i]).setNormal(p, nx, ny, nz).setLineWidth(w[i]);
                    vc.addVertex(p, x1, y1, z1).setColor(c[i + 1]).setNormal(p, nx, ny, nz).setLineWidth(w[i + 1]);
                }
            });
        }
    }

    private static Batch quads() {
        return xray ? QUADS_XRAY : QUADS;
    }

    private static Batch lines() {
        return xray ? LINES_XRAY : LINES;
    }

    /** When on, everything drawn is visible through walls (ESP / finders). */
    public static void xray(boolean on) {
        xray = on;
    }

    public static Vec3 camera() {
        return cam;
    }

    private static boolean visible(AABB box) {
        // Skip boxes behind the camera: cheap half-space test against the view direction.
        var f = com.blocks.compat.Compat.camera().forwardVector();
        double cx = (box.minX + box.maxX) / 2 - cam.x, cy = (box.minY + box.maxY) / 2 - cam.y, cz = (box.minZ + box.maxZ) / 2 - cam.z;
        double r = Math.max(box.maxX - box.minX, Math.max(box.maxY - box.minY, box.maxZ - box.minZ));
        return cx * f.x() + cy * f.y() + cz * f.z() > -r * 1.8;
    }

    /** Translucent filled box. */
    public static void boxFill(AABB box, int color) {
        if ((color >>> 24) == 0 || collector == null || !visible(box)) return;
        final float x0 = (float) (box.minX - cam.x), y0 = (float) (box.minY - cam.y), z0 = (float) (box.minZ - cam.z);
        final float x1 = (float) (box.maxX - cam.x), y1 = (float) (box.maxY - cam.y), z1 = (float) (box.maxZ - cam.z);
        Batch b = quads();
        quad(b, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, color); // bottom
        quad(b, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0, color); // top
        quad(b, x0, y0, z0, x0, y1, z0, x1, y1, z0, x1, y0, z0, color); // north
        quad(b, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, color); // south
        quad(b, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, color); // west
        quad(b, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, color); // east
    }

    /** Box edges. */
    public static void boxLines(AABB box, int color, float width) {
        if ((color >>> 24) == 0 || collector == null || !visible(box)) return;
        final float x0 = (float) (box.minX - cam.x), y0 = (float) (box.minY - cam.y), z0 = (float) (box.minZ - cam.z);
        final float x1 = (float) (box.maxX - cam.x), y1 = (float) (box.maxY - cam.y), z1 = (float) (box.maxZ - cam.z);
        Batch b = lines();
        line(b, x0, y0, z0, x1, y0, z0, color, width);
        line(b, x1, y0, z0, x1, y0, z1, color, width);
        line(b, x1, y0, z1, x0, y0, z1, color, width);
        line(b, x0, y0, z1, x0, y0, z0, color, width);
        line(b, x0, y1, z0, x1, y1, z0, color, width);
        line(b, x1, y1, z0, x1, y1, z1, color, width);
        line(b, x1, y1, z1, x0, y1, z1, color, width);
        line(b, x0, y1, z1, x0, y1, z0, color, width);
        line(b, x0, y0, z0, x0, y1, z0, color, width);
        line(b, x1, y0, z0, x1, y1, z0, color, width);
        line(b, x1, y0, z1, x1, y1, z1, color, width);
        line(b, x0, y0, z1, x0, y1, z1, color, width);
    }

    /**
     * A horizontal ring with a soft vertical gradient band: bright line at y,
     * fading to transparent at y + height. Looks like a glowing halo.
     */
    public static void ring(Vec3 center, double radius, double height, int color, int segments) {
        if ((color >>> 24) == 0 || collector == null) return;
        final float cx = (float) (center.x - cam.x), cy = (float) (center.y - cam.y), cz = (float) (center.z - cam.z);
        final float r = (float) radius, h = (float) height;
        final int faded = color & 0x00FFFFFF;
        Batch q = quads(), l = lines();
        for (int i = 0; i < segments; i++) {
            double a0 = Math.PI * 2 * i / segments, a1 = Math.PI * 2 * (i + 1) / segments;
            float x0 = cx + (float) Math.cos(a0) * r, z0 = cz + (float) Math.sin(a0) * r;
            float x1 = cx + (float) Math.cos(a1) * r, z1 = cz + (float) Math.sin(a1) * r;
            // Two-sided so it reads from any angle.
            q.add(x0, cy, z0, color, 0);
            q.add(x1, cy, z1, color, 0);
            q.add(x1, cy + h, z1, faded, 0);
            q.add(x0, cy + h, z0, faded, 0);
            q.add(x0, cy + h, z0, faded, 0);
            q.add(x1, cy + h, z1, faded, 0);
            q.add(x1, cy, z1, color, 0);
            q.add(x0, cy, z0, color, 0);
            line(l, x0, cy, z0, x1, cy, z1, color, 2.5f);
        }
    }

    /** A line from just in front of the camera to the target, like a tracer (always through walls). */
    public static void tracer(Vec3 to, int color, float width) {
        if ((color >>> 24) == 0 || collector == null) return;
        var f = com.blocks.compat.Compat.camera().forwardVector();
        float x0 = f.x() * 0.5f, y0 = f.y() * 0.5f, z0 = f.z() * 0.5f;
        float x1 = (float) (to.x - cam.x), y1 = (float) (to.y - cam.y), z1 = (float) (to.z - cam.z);
        line(LINES_XRAY, x0, y0, z0, x1, y1, z1, color, width);
    }

    /** A chunk's footprint drawn flat at height y: outline plus a faint fill. */
    public static void chunkOutline(int chunkX, int chunkZ, double y, int lineColor, int fillColor) {
        double x0 = chunkX << 4, z0 = chunkZ << 4;
        AABB box = new AABB(x0, y, z0, x0 + 16, y + 0.02, z0 + 16);
        boxFill(box, fillColor);
        boxLines(box, lineColor, 2.5f);
    }

    /** A tall translucent column, for things worth seeing from far away. */
    public static void beam(Vec3 base, double height, double width, int color) {
        double h = width / 2;
        boxFill(new AABB(base.x - h, base.y, base.z - h, base.x + h, base.y + height, base.z + h), color);
        boxLines(new AABB(base.x - h, base.y, base.z - h, base.x + h, base.y + height, base.z + h), color | 0xFF000000, 1.5f);
    }

    /** A quad with a colour per corner (world coordinates). */
    public static void quad(Vec3 a, Vec3 b, Vec3 c, Vec3 d, int ca, int cb, int cc, int cd) {
        if (collector == null) return;
        Batch q = quads();
        q.add((float) (a.x - cam.x), (float) (a.y - cam.y), (float) (a.z - cam.z), ca, 0);
        q.add((float) (b.x - cam.x), (float) (b.y - cam.y), (float) (b.z - cam.z), cb, 0);
        q.add((float) (c.x - cam.x), (float) (c.y - cam.y), (float) (c.z - cam.z), cc, 0);
        q.add((float) (d.x - cam.x), (float) (d.y - cam.y), (float) (d.z - cam.z), cd, 0);
    }

    /** A line between two world points, coloured at each end. */
    public static void line(Vec3 a, Vec3 b, int ca, int cb, float width) {
        if (collector == null) return;
        Batch l = lines();
        l.add((float) (a.x - cam.x), (float) (a.y - cam.y), (float) (a.z - cam.z), ca, width);
        l.add((float) (b.x - cam.x), (float) (b.y - cam.y), (float) (b.z - cam.z), cb, width);
    }

    /** Partial tick for smooth motion between game ticks. */
    public static float partialTick() {
        return Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(true);
    }

    /** An entity's interpolated position this frame. */
    public static Vec3 lerpPos(net.minecraft.world.entity.Entity e) {
        float pt = partialTick();
        return new Vec3(e.xo + (e.getX() - e.xo) * pt, e.yo + (e.getY() - e.yo) * pt, e.zo + (e.getZ() - e.zo) * pt);
    }

    private static void quad(Batch b, float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz, int color) {
        b.add(ax, ay, az, color, 0);
        b.add(bx, by, bz, color, 0);
        b.add(cx, cy, cz, color, 0);
        b.add(dx, dy, dz, color, 0);
    }

    private static void line(Batch b, float x0, float y0, float z0, float x1, float y1, float z1, int color, float width) {
        b.add(x0, y0, z0, color, width);
        b.add(x1, y1, z1, color, width);
    }
}
