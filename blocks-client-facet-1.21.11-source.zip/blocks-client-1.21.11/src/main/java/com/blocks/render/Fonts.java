package com.blocks.render;

import com.blocks.BlocksClient;
import com.blocks.module.client.ClickGui;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.resources.Identifier;
import net.minecraft.util.FormattedCharSequence;

import java.util.LinkedHashMap;
import java.util.Map;

/** Blocks's UI font (Manrope, bundled) with a small cache of shaped strings. */
public final class Fonts {
    private static final FontDescription UI = new FontDescription.Resource(Identifier.fromNamespaceAndPath("blocks", "ui"));
    private static final FontDescription BOLD = new FontDescription.Resource(Identifier.fromNamespaceAndPath("blocks", "bold"));
    private static final FontDescription MONO = new FontDescription.Resource(Identifier.fromNamespaceAndPath("blocks", "mono"));
    private static final int CACHE_SIZE = 768;
    private static final Map<String, FormattedCharSequence> REGULAR = lru();
    private static final Map<String, FormattedCharSequence> BOLDS = lru();
    private static final Map<String, FormattedCharSequence> MONOS = lru();
    private static ClickGui gui;

    private Fonts() {}

    private static Map<String, FormattedCharSequence> lru() {
        return new LinkedHashMap<>(256, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<String, FormattedCharSequence> eldest) {
                return size() > CACHE_SIZE;
            }
        };
    }

    /** True when the bundled font should be used instead of the vanilla pixel font. */
    public static boolean custom() {
        if (gui == null) {
            if (BlocksClient.modules == null) return false;
            gui = BlocksClient.modules.get(ClickGui.class);
        }
        return gui.font.is("Manrope");
    }

    /** Monospace (JetBrains Mono) for codes, keys, clocks and labels. */
    public static FormattedCharSequence mono(String text) {
        FormattedCharSequence seq = MONOS.get(text);
        if (seq == null) {
            seq = Component.literal(text).withStyle(s -> s.withFont(MONO)).getVisualOrderText();
            MONOS.put(text, seq);
        }
        return seq;
    }

    public static FormattedCharSequence seq(String text, boolean bold) {
        Map<String, FormattedCharSequence> cache = bold ? BOLDS : REGULAR;
        FormattedCharSequence seq = cache.get(text);
        if (seq == null) {
            seq = Component.literal(text).withStyle(s -> s.withFont(bold ? BOLD : UI)).getVisualOrderText();
            cache.put(text, seq);
        }
        return seq;
    }
}
