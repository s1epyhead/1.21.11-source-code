package com.blocks.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.resources.Identifier;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.PlayerSkin;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix3x2fStack;

/**
 * Version-neutral drawing surface. 1.21.11 wraps GuiGraphics, 26.x wraps
 * GuiGraphicsExtractor (see versions/<mc>/.../compat/GfxImpl).
 */
public abstract class Gfx {
    protected final Font font = Minecraft.getInstance().font;

    public abstract Matrix3x2fStack pose();

    public abstract int guiWidth();

    public abstract int guiHeight();

    public abstract void fill(int x1, int y1, int x2, int y2, int color);

    public abstract void gradientV(int x1, int y1, int x2, int y2, int top, int bottom);

    /** Draws with the vanilla font. */
    protected abstract void textRaw(String text, int x, int y, int color, boolean shadow);

    /** Draws an already-styled sequence (used for the custom font). */
    protected abstract void textSeq(FormattedCharSequence text, int x, int y, int color, boolean shadow);

    public void text(String text, int x, int y, int color, boolean shadow) {
        if (Fonts.custom()) textSeq(Fonts.seq(text, false), x, y, color, shadow);
        else textRaw(text, x, y, color, shadow);
    }

    /** Heavier weight for titles (vanilla font falls back to regular). */
    public void textBold(String text, int x, int y, int color, boolean shadow) {
        if (Fonts.custom()) textSeq(Fonts.seq(text, true), x, y, color, shadow);
        else textRaw(text, x, y, color, shadow);
    }

    /** Smaller/larger text via the pose; crisp with the TTF font. */
    public void textScaled(String text, double x, double y, int color, float scale) {
        Matrix3x2fStack pose = pose();
        pose.pushMatrix();
        pose.translate((float) x, (float) y);
        pose.scale(scale, scale);
        text(text, 0, 0, color, false);
        pose.popMatrix();
    }

    public double widthScaled(String text, float scale) {
        return width(text) * scale;
    }

    /** Draws each character with a colour blended from a to b (used for the wordmark). */
    public void gradientText(String text, int x, int y, int a, int b, boolean bold) {
        int n = text.length();
        double cx = x;
        for (int i = 0; i < n; i++) {
            String ch = String.valueOf(text.charAt(i));
            double t = n <= 1 ? 0 : (double) i / (n - 1);
            int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
            int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
            int color = (a & 0xFF000000) | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
            if (bold) textBold(ch, (int) Math.round(cx), y, color, false);
            else text(ch, (int) Math.round(cx), y, color, false);
            // Measure the prefix so kerning-free advances still line up.
            cx = x + (bold ? widthBold(text.substring(0, i + 1)) : width(text.substring(0, i + 1)));
        }
    }

    /** Monospace text (falls back to the vanilla font when the custom font is off). */
    public void textMono(String text, double x, double y, int color, float scale) {
        Matrix3x2fStack pose = pose();
        pose.pushMatrix();
        pose.translate((float) x, (float) y);
        pose.scale(scale, scale);
        if (Fonts.custom()) textSeq(Fonts.mono(text), 0, 0, color, false);
        else textRaw(text, 0, 0, color, false);
        pose.popMatrix();
    }

    public double widthMono(String text, float scale) {
        return (Fonts.custom() ? font.width(Fonts.mono(text)) : font.width(text)) * scale;
    }

    /** Letter-spaced monospace caps, e.g. section labels. */
    public void textTracked(String text, double x, double y, int color, float scale, double tracking) {
        double cx = x;
        for (int i = 0; i < text.length(); i++) {
            String ch = String.valueOf(text.charAt(i));
            textMono(ch, cx, y, color, scale);
            cx += widthMono(ch, scale) + tracking;
        }
    }

    public double widthTracked(String text, float scale, double tracking) {
        double w = 0;
        for (int i = 0; i < text.length(); i++) w += widthMono(String.valueOf(text.charAt(i)), scale) + tracking;
        return Math.max(0, w - tracking);
    }

    public int widthSeq(FormattedCharSequence seq) {
        return font.width(seq);
    }

    /** Draws an already styled line (chat messages keep their own colours). */
    public void textSeqPublic(FormattedCharSequence seq, int x, int y, int color, boolean shadow) {
        textSeq(seq, x, y, color, shadow);
    }

    public int widthBold(String text) {
        return Fonts.custom() ? font.width(Fonts.seq(text, true)) : font.width(text);
    }

    /** Draws a region of a texture: (u,v,uw,vh) stretched to (w,h), tinted by color. */
    public abstract void blit(Identifier tex, int x, int y, int w, int h, float u, float v, int uw, int vh, int texW, int texH, int color);

    public abstract void head(PlayerSkin skin, int x, int y, int size);

    public abstract void item(ItemStack stack, int x, int y);

    /** Draws an entity like the inventory paper doll, its head following the mouse. GUI coordinates. */
    public abstract void entityFollowsMouse(int x1, int y1, int x2, int y2, int size, float yOffset, float mouseX, float mouseY,
                                            net.minecraft.world.entity.LivingEntity entity);

    /** Draws an item icon centred on (cx, cy), scaled to a whole number of real pixels per texel so it stays crisp. */
    public void itemIcon(ItemStack stack, double cx, double cy, double size, float pixelsPerUnit) {
        int texel = Math.max(1, (int) Math.round(size / 16.0 * pixelsPerUnit));
        float s = texel / pixelsPerUnit;
        Matrix3x2fStack pose = pose();
        pose.pushMatrix();
        pose.translate((float) (cx - 8 * s), (float) (cy - 8 * s));
        pose.scale(s, s);
        item(stack, 0, 0);
        pose.popMatrix();
    }

    public abstract void scissor(int x1, int y1, int x2, int y2);

    public abstract void noScissor();

    /** Blurs everything drawn before this call. Only valid once per frame. */
    public abstract void blur();

    public int width(String text) {
        return Fonts.custom() ? font.width(Fonts.seq(text, false)) : font.width(text);
    }

    public void text(String text, int x, int y, int color) {
        text(text, x, y, color, false);
    }

    public void textCentered(String text, int cx, int y, int color, boolean shadow) {
        text(text, cx - width(text) / 2, y, color, shadow);
    }

    public void textRight(String text, int rightX, int y, int color, boolean shadow) {
        text(text, rightX - width(text), y, color, shadow);
    }

    public void blit(Identifier tex, int x, int y, int w, int h, int color) {
        blit(tex, x, y, w, h, 0, 0, w, h, w, h, color);
    }
}
