package com.blocks.render;

/**
 * Version-neutral screen logic. Each MC version has a thin Screen subclass
 * (compat/ScreenWrapper) that forwards rendering and input here.
 * Coordinates are in Minecraft GUI units.
 */
public interface UiScreen {
    void render(Gfx g, int mouseX, int mouseY, float delta);

    /** Background layer (blur/dim). Drawn before render(). */
    void renderBackground(Gfx g);

    boolean mouseClicked(double x, double y, int button);

    boolean mouseReleased(double x, double y, int button);

    boolean mouseDragged(double x, double y, int button);

    boolean mouseScrolled(double x, double y, double amount);

    /** @return true if the key was consumed. Escape not consumed closes the screen. */
    boolean keyPressed(int key, int modifiers);

    boolean charTyped(String chars);

    void onClose();
}
