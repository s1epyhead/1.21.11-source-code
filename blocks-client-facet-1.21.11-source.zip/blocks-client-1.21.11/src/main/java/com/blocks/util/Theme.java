package com.blocks.util;

import com.blocks.BlocksClient;
import com.blocks.module.client.ClickGui;

/** Blocks colour themes. Custom uses the RGB sliders in the Themes panel. */
public final class Theme {
    public record Palette(String name, int accent, int accent2, int panel) {}

    /** Two-tone palettes named after blocks: a main accent, a lighter second accent and the panel base. */
    public static final Palette[] PRESETS = {
            new Palette("Amethyst", 0xFFB48CFF, 0xFFE3B8FF, 0xFF16111F),
            new Palette("Diamond", 0xFF4FE0D8, 0xFF9FF3FF, 0xFF0D1A1F),
            new Palette("Emerald", 0xFF3DDC84, 0xFFA6F5B8, 0xFF0E1A13),
            new Palette("Redstone", 0xFFFF4545, 0xFFFF9A7A, 0xFF1C0F10),
            new Palette("Gold", 0xFFFFC93C, 0xFFFFE89A, 0xFF1C170C),
            new Palette("Lapis", 0xFF4F86FF, 0xFF9FC0FF, 0xFF0E1221),
            new Palette("Netherite", 0xFFA8939F, 0xFFE0D2DA, 0xFF141114),
            new Palette("Grass", 0xFF7BC74D, 0xFFC9A26B, 0xFF121A0F),
    };

    public static final int TEXT = 0xFFFFF6EC;
    public static final int TEXT_DIM = 0xFFC2B6B0;
    public static final int TEXT_FAINT = 0xFF8A7F80;
    /** Text drawn on top of an accent fill. */
    public static final int TEXT_ON_ACCENT = 0xFF1A1013;

    private Theme() {}

    private static ClickGui gui;

    private static ClickGui gui() {
        if (gui == null) gui = BlocksClient.modules.get(ClickGui.class);
        return gui;
    }

    private static String cachedName;
    private static Palette cached;
    private static long cachedAt;

    public static Palette current() {
        ClickGui g = gui();
        String name = g.theme.get();
        // Called hundreds of times per frame: reuse the last answer while the theme is unchanged.
        if (name == cachedName && (!"Custom".equals(name) || System.currentTimeMillis() - cachedAt < 50)) return cached;
        cachedName = name;
        cachedAt = System.currentTimeMillis();
        for (Palette p : PRESETS) if (p.name().equals(name)) return cached = p;
        if (!"Custom".equals(name)) return cached = PRESETS[0]; // a theme from an older version
        int accent = 0xFF000000 | (g.accentR.getInt() << 16) | (g.accentG.getInt() << 8) | g.accentB.getInt();
        int panel = 0xFF000000 | (g.panelR.getInt() << 16) | (g.panelG.getInt() << 8) | g.panelB.getInt();
        return cached = new Palette("Custom", accent, blend(accent, 0xFFFFFFFF, 0.35), panel);
    }

    public static int accent() {
        return current().accent();
    }

    /** Accent that drifts toward the secondary colour over time and position (if animations are on). */
    public static int accentAt(double offset) {
        Palette p = current();
        if (!gui().animations.get()) return p.accent();
        double t = System.currentTimeMillis() / 1600.0;
        return blend(p.accent(), p.accent2(), (Math.sin(t + offset) + 1) / 2);
    }

    /** Translucent panel fill tinted with the accent. */
    public static int panel(int alpha) {
        Palette p = current();
        return withAlpha(blend(p.panel(), p.accent(), 0.10), alpha);
    }

    /** Light accent used for outlines. */
    public static int outline(int alpha) {
        return withAlpha(blend(accent(), 0xFFFFFFFF, 0.45), alpha);
    }

    public static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }

    public static int alphaMul(int color, double mul) {
        int a = (int) (((color >>> 24) & 0xFF) * Math.max(0, Math.min(1, mul)));
        return withAlpha(color, a);
    }

    public static int blend(int a, int b, double pct) {
        pct = Math.max(0, Math.min(1, pct));
        int aa = (a >>> 24) & 0xFF, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int ba = (b >>> 24) & 0xFF, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        return ((int) (aa + (ba - aa) * pct) << 24) | ((int) (ar + (br - ar) * pct) << 16)
                | ((int) (ag + (bg - ag) * pct) << 8) | (int) (ab + (bb - ab) * pct);
    }

    /** Red at 0, yellow at half, green at full. */
    public static int health(float pct) {
        pct = Math.max(0, Math.min(1, pct));
        return 0xFF000000 | (java.awt.Color.HSBtoRGB(pct / 3f, 0.7f, 0.95f) & 0xFFFFFF);
    }
}
