package com.blocks.util;

import com.blocks.BlocksClient;
import com.blocks.module.Module;
import com.blocks.module.client.ClickGui;
import com.blocks.module.visuals.Hud;
import com.blocks.render.Gfx;
import com.blocks.render.Shapes;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** Toasts in the bottom-right corner: module toggles and finder hits. */
public final class Notifications {
    private static final long LIFETIME = 2600, FIND_LIFETIME = 6000;
    private static final List<Note> NOTES = new ArrayList<>();

    private record Note(String title, String text, ItemStack icon, int color, boolean on, long created, long life) {}

    private Notifications() {}

    private static ClickGui gui() {
        return BlocksClient.modules.get(ClickGui.class);
    }

    public static void toggled(Module m) {
        if (BlocksClient.modules == null || Minecraft.getInstance().player == null) return;
        if (!gui().notifications.get() || !gui().toggleAlerts.get()) return;
        add(new Note(m.getName(), m.isEnabled() ? "On" : "Off", null, Theme.accent(), m.isEnabled(), System.currentTimeMillis(), LIFETIME));
        if (gui().notificationSound.get()) {
            Minecraft.getInstance().getSoundManager().play(
                    SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.value(), m.isEnabled() ? 1.5f : 1.1f, 0.3f));
        }
    }

    public static void push(String title, String text, boolean on) {
        add(new Note(title, text, null, Theme.accent(), on, System.currentTimeMillis(), LIFETIME));
    }

    /** A finder hit: item icon, headline and "detail · 76m NE" line. */
    public static void pushFind(ItemStack icon, String title, String text, int color) {
        if (BlocksClient.modules == null || !gui().notifications.get() || !gui().findAlerts.get()) return;
        add(new Note(title, text, icon, color, true, System.currentTimeMillis(), FIND_LIFETIME));
        if (BlocksClient.modules != null && gui().notificationSound.get()) {
            Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.NOTE_BLOCK_BELL.value(), 1.6f, 0.35f));
        }
    }

    private static void add(Note n) {
        if (BlocksClient.modules != null && !gui().notifications.get()) return;
        NOTES.add(n);
        if (NOTES.size() > 5) NOTES.remove(0);
    }

    public static void render(Gfx g) {
        if (NOTES.isEmpty()) return;
        long now = System.currentTimeMillis();
        NOTES.removeIf(n -> now - n.created > n.life);
        if (NOTES.isEmpty()) return;
        boolean anim = gui().animations.get();
        float k = Hud.scaleFactor();
        g.pose().pushMatrix();
        g.pose().scale(k, k);
        Shapes.begin(g, gui().uiScale());
        double sw = g.guiWidth() / k, sh = g.guiHeight() / k;
        double y = Math.min(sh - 46, com.blocks.module.visuals.Hud.bottomRightTop - 6);
        for (int i = NOTES.size() - 1; i >= 0; i--) {
            Note n = NOTES.get(i);
            double age = now - n.created;
            double slide = 1;
            if (anim) slide = ease(Math.min(Math.min(1, age / 220.0), Math.min(1, (n.life - age) / 220.0)));
            boolean find = n.icon != null;
            double w = Math.max(find ? 150 : 104, 34 + Math.max(g.widthBold(n.title), g.width(n.text) * 0.84) + 12);
            double h = 30;
            y -= h;
            double x = sw - 8 - w * slide - (1 - slide) * 6;
            int alpha = (int) (235 * slide);
            Shapes.roundRect(x, y, w, h, 9, Theme.withAlpha(0xFF101015, alpha));
            Shapes.roundOutline(x, y, w, h, 9, 0.8, Theme.withAlpha(n.color, (int) (120 * slide)));
            double ix = x + 15, iy = y + h / 2;
            if (find) {
                Shapes.circle(ix, iy, 9, Theme.withAlpha(n.color, (int) (45 * slide)));
                g.itemIcon(n.icon, ix, iy, 12, Shapes.scale());
            } else {
                Shapes.circle(ix, iy, 6.5, Theme.withAlpha(n.on ? n.color : 0xFF5A5560, (int) (alpha * 0.3)));
                Shapes.circle(ix, iy, 2.6, Theme.withAlpha(n.on ? n.color : 0xFF8A8590, alpha));
            }
            g.textBold(n.title, (int) x + 30, (int) y + 6, Theme.withAlpha(Theme.TEXT, Math.max(alpha, 8)), false);
            g.textScaled(n.text, x + 30, y + 17, Theme.withAlpha(Theme.TEXT_DIM, Math.max(alpha, 8)), 0.84f);
            double pct = 1 - age / n.life;
            Shapes.roundRect(x + 10, y + h - 2.2, (w - 20) * pct, 1, 0.5, Theme.withAlpha(n.color, (int) (alpha * 0.7)));
            y -= 5;
        }
        g.pose().popMatrix();
    }

    private static double ease(double t) {
        return 1 - Math.pow(1 - Math.max(0, t), 3);
    }
}
