package com.blocks.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.blocks.BlocksClient;
import com.blocks.module.Module;
import com.blocks.module.visuals.Hud;
import com.blocks.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 * Config profiles in config/blocks/profiles/<name>.json. The active profile
 * name is kept in config/blocks/active.txt and is auto-saved.
 */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static final String[] QUICK_PROFILES = {"PvP", "Builder", "Miner"};
    private static String active = "PvP";

    private Config() {}

    private static boolean migrated;

    private static Path dir() {
        Path dir = FabricLoader.getInstance().getConfigDir().resolve("blocks");
        if (!migrated) {
            migrated = true;
            // Carry profiles and schematics over from the old "summer" folder, once.
            Path old = FabricLoader.getInstance().getConfigDir().resolve("summer");
            if (!Files.exists(dir) && Files.isDirectory(old)) {
                try (Stream<Path> walk = Files.walk(old)) {
                    for (Path src : (Iterable<Path>) walk::iterator) {
                        Path dst = dir.resolve(old.relativize(src).toString());
                        if (Files.isDirectory(src)) Files.createDirectories(dst);
                        else Files.copy(src, dst);
                    }
                } catch (Exception e) {
                    BlocksClient.LOG.warn("Couldn't move old settings over", e);
                }
            }
        }
        return dir;
    }

    private static Path profileFile(String name) {
        return dir().resolve("profiles").resolve(name.replaceAll("[^A-Za-z0-9 _-]", "_") + ".json");
    }

    public static String active() {
        return active;
    }

    public static List<String> profiles() {
        List<String> list = new ArrayList<>();
        Path p = dir().resolve("profiles");
        if (Files.isDirectory(p)) {
            try (Stream<Path> s = Files.list(p)) {
                s.map(f -> f.getFileName().toString())
                        .filter(n -> n.endsWith(".json"))
                        .map(n -> n.substring(0, n.length() - 5))
                        .sorted()
                        .forEach(list::add);
            } catch (IOException ignored) {
            }
        }
        if (!list.contains(active)) list.add(0, active);
        return list;
    }

    public static void loadActive() {
        try {
            Path a = dir().resolve("active.txt");
            if (Files.exists(a)) active = Files.readString(a).trim();
        } catch (IOException ignored) {
        }
        if (active.isEmpty()) active = "PvP";
        load(active);
    }

    /** Saves the current profile, then switches to (and loads) another. */
    public static void switchTo(String name) {
        save();
        active = name;
        // A brand new profile starts as a copy of the current state.
        if (Files.exists(profileFile(name))) load(name);
        save();
        Notifications.push("Profile", "Switched to " + name, true);
    }

    public static void delete(String name) {
        if (name.equals(active)) return;
        try {
            Files.deleteIfExists(profileFile(name));
        } catch (IOException e) {
            BlocksClient.LOG.error("Failed to delete profile {}", name, e);
        }
    }

    public static void save() {
        if (BlocksClient.modules == null) return;
        try {
            JsonObject root = new JsonObject();
            JsonObject modules = new JsonObject();
            for (Module m : BlocksClient.modules.all()) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.isEnabled());
                o.addProperty("key", m.getKey());
                o.addProperty("favorite", m.isFavorite());
                JsonObject settings = new JsonObject();
                for (Setting s : m.getSettings()) settings.add(s.getName(), s.toJson());
                o.add("settings", settings);
                modules.add(m.getName(), o);
            }
            root.add("modules", modules);
            root.add("hud", BlocksClient.modules.get(Hud.class).savePositions());

            Path file = profileFile(active);
            Files.createDirectories(file.getParent());
            Files.writeString(file, GSON.toJson(root));
            Files.writeString(dir().resolve("active.txt"), active);
        } catch (Exception e) {
            BlocksClient.LOG.error("Failed to save config", e);
        }
    }

    private static void load(String name) {
        Path file = profileFile(name);
        if (!Files.exists(file)) return;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            if (root.has("modules")) {
                for (Map.Entry<String, JsonElement> e : root.getAsJsonObject("modules").entrySet()) {
                    Module m = BlocksClient.modules.byName(e.getKey());
                    if (m == null || !e.getValue().isJsonObject()) continue;
                    JsonObject o = e.getValue().getAsJsonObject();
                    if (o.has("enabled")) {
                        boolean en = o.get("enabled").getAsBoolean();
                        if (net.minecraft.client.Minecraft.getInstance().player != null) m.setEnabled(en);
                        else m.setEnabledSilently(en);
                    }
                    if (o.has("key")) m.setKey(o.get("key").getAsInt());
                    if (o.has("favorite")) m.setFavorite(o.get("favorite").getAsBoolean());
                    if (o.has("settings")) {
                        JsonObject settings = o.getAsJsonObject("settings");
                        for (Setting s : m.getSettings()) {
                            if (settings.has(s.getName())) s.fromJson(settings.get(s.getName()));
                        }
                    }
                }
            }
            if (root.has("hud")) BlocksClient.modules.get(Hud.class).loadPositions(root.getAsJsonObject("hud"));
        } catch (Exception e) {
            BlocksClient.LOG.error("Failed to load profile {}, using defaults", name, e);
        }
    }
}
