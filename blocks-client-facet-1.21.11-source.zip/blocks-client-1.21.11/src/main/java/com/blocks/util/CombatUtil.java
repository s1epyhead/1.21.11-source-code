package com.blocks.util;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.damagesource.CombatRules;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ServerExplosion;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class CombatUtil {
    private static final Minecraft mc = Minecraft.getInstance();

    private CombatUtil() {}

    /** Whether an end crystal can be placed on top of this block. */
    public static boolean canPlaceCrystal(BlockPos pos) {
        BlockState state = mc.level.getBlockState(pos);
        if (!state.is(Blocks.OBSIDIAN) && !state.is(Blocks.BEDROCK)) return false;
        BlockPos up = pos.above();
        if (!mc.level.getBlockState(up).isAir()) return false;
        AABB box = new AABB(up.getX(), up.getY(), up.getZ(), up.getX() + 1, up.getY() + 2, up.getZ() + 1);
        return mc.level.getEntities((Entity) null, box, e -> !e.isSpectator()).isEmpty();
    }

    /** Where a crystal placed on this block would explode. */
    public static Vec3 crystalPos(BlockPos base) {
        return new Vec3(base.getX() + 0.5, base.getY() + 1, base.getZ() + 0.5);
    }

    /** Estimated explosion damage (power 6, like an end crystal) to an entity, after armour and resistance. */
    public static float explosionDamage(Vec3 source, LivingEntity entity, float power) {
        double radius = power * 2.0;
        double dist = Math.sqrt(entity.distanceToSqr(source)) / radius;
        if (dist > 1) return 0;
        double impact = (1 - dist) * ServerExplosion.getSeenPercent(source, entity);
        float dmg = (float) ((impact * impact + impact) / 2.0 * 7.0 * radius + 1.0);

        if (entity instanceof Player) {
            Difficulty d = mc.level.getDifficulty();
            if (d == Difficulty.PEACEFUL) dmg = 0;
            else if (d == Difficulty.EASY) dmg = Math.min(dmg / 2 + 1, dmg);
            else if (d == Difficulty.HARD) dmg *= 1.5f;
        }

        dmg = CombatRules.getDamageAfterAbsorb(entity, dmg, mc.level.damageSources().explosion(null, null),
                entity.getArmorValue(), (float) entity.getAttributeValue(Attributes.ARMOR_TOUGHNESS));

        // Protection and Blast Protection on armour (EPF, capped at 20 = 80%).
        int epf = 0;
        for (net.minecraft.world.entity.EquipmentSlot slot : new net.minecraft.world.entity.EquipmentSlot[]{
                net.minecraft.world.entity.EquipmentSlot.HEAD, net.minecraft.world.entity.EquipmentSlot.CHEST,
                net.minecraft.world.entity.EquipmentSlot.LEGS, net.minecraft.world.entity.EquipmentSlot.FEET}) {
            for (var e : entity.getItemBySlot(slot).getEnchantments().entrySet()) {
                if (e.getKey().is(net.minecraft.world.item.enchantment.Enchantments.PROTECTION)) epf += e.getIntValue();
                else if (e.getKey().is(net.minecraft.world.item.enchantment.Enchantments.BLAST_PROTECTION)) epf += 2 * e.getIntValue();
            }
        }
        dmg *= 1 - Math.min(20, epf) / 25f;

        MobEffectInstance res = entity.getEffect(MobEffects.RESISTANCE);
        if (res != null) dmg *= Math.max(0, 1 - (res.getAmplifier() + 1) * 0.2f);
        return Math.max(0, dmg);
    }

    public static float crystalDamage(Vec3 source, LivingEntity entity) {
        return explosionDamage(source, entity, 6f);
    }

    public static float health(LivingEntity e) {
        return e.getHealth() + e.getAbsorptionAmount();
    }

    /** Nearest living enemy player within range, or null. */
    public static Player nearestPlayer(double range) {
        Player best = null;
        double bestDist = range * range;
        for (Player p : mc.level.players()) {
            if (p == mc.player || !p.isAlive() || p.isSpectator()) continue;
            double d = mc.player.distanceToSqr(p);
            if (d <= bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best;
    }

    /** {yaw, pitch} needed to look at a point. */
    public static float[] rotationsTo(Vec3 target) {
        Vec3 eye = mc.player.getEyePosition();
        double dx = target.x - eye.x, dy = target.y - eye.y, dz = target.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        return new float[]{Mth.wrapDegrees(yaw), Mth.clamp(pitch, -90f, 90f)};
    }

    /** Angle in degrees between the crosshair and a point. */
    public static double angleTo(Vec3 target) {
        float[] rot = rotationsTo(target);
        double dy = Mth.wrapDegrees(rot[0] - mc.player.getYRot());
        double dp = rot[1] - mc.player.getXRot();
        return Math.sqrt(dy * dy + dp * dp);
    }
}
