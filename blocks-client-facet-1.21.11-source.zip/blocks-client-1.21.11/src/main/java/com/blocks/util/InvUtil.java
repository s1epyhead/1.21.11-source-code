package com.blocks.util;

import com.blocks.compat.Compat;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;

import java.util.function.Predicate;

public final class InvUtil {
    private static final Minecraft mc = Minecraft.getInstance();

    private InvUtil() {}

    /** @return hotbar slot 0-8 holding a matching stack, or -1. */
    public static int findHotbar(Predicate<ItemStack> filter) {
        for (int i = 0; i < 9; i++) if (filter.test(mc.player.getInventory().getItem(i))) return i;
        return -1;
    }

    /** @return inventory index 0-35 (hotbar first) holding a matching stack, or -1. */
    public static int findInventory(Predicate<ItemStack> filter) {
        for (int i = 0; i < 36; i++) if (filter.test(mc.player.getInventory().getItem(i))) return i;
        return -1;
    }

    /** Main inventory only (9-35), skipping the hotbar. */
    public static int findMain(Predicate<ItemStack> filter) {
        for (int i = 9; i < 36; i++) if (filter.test(mc.player.getInventory().getItem(i))) return i;
        return -1;
    }

    public static int count(Predicate<ItemStack> filter) {
        int n = 0;
        for (int i = 0; i < mc.player.getInventory().getContainerSize(); i++) {
            ItemStack s = mc.player.getInventory().getItem(i);
            if (filter.test(s)) n += s.getCount();
        }
        return n;
    }

    /** Player inventory index -> InventoryMenu slot id. */
    public static int toMenuSlot(int invIndex) {
        return invIndex < 9 ? 36 + invIndex : invIndex;
    }

    public static int selected() {
        return mc.player.getInventory().getSelectedSlot();
    }

    public static void select(int slot) {
        if (slot >= 0 && slot < 9) mc.player.getInventory().setSelectedSlot(slot);
    }

    /** Moves an inventory index into the offhand via the inventory menu. */
    public static void moveToOffhand(int invIndex) {
        Compat.swapSlot(mc.player.inventoryMenu.containerId, toMenuSlot(invIndex), 40);
    }

    /** Moves an inventory index into a hotbar slot via the inventory menu. */
    public static void moveToHotbar(int invIndex, int hotbar) {
        Compat.swapSlot(mc.player.inventoryMenu.containerId, toMenuSlot(invIndex), hotbar);
    }

    public static void useOn(BlockHitResult hit, InteractionHand hand) {
        var result = mc.gameMode.useItemOn(mc.player, hand, hit);
        if (result.consumesAction()) Compat.swing(hand, false);
    }

    public static void useItem(InteractionHand hand) {
        var result = mc.gameMode.useItem(mc.player, hand);
        if (result.consumesAction()) Compat.swing(hand, false);
    }

    public static void attack(Entity target) {
        mc.gameMode.attack(mc.player, target);
        Compat.swing(InteractionHand.MAIN_HAND, true);
    }
}
