package com.blocks;

import com.blocks.compat.Compat;
import com.blocks.module.ModuleManager;
import com.blocks.util.Config;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BlocksClient implements ClientModInitializer {
    public static final String NAME = "Blocks Client";
    public static final String VERSION = "1.0";
    public static final Logger LOG = LoggerFactory.getLogger(NAME);

    public static ModuleManager modules;

    /** Last player a combat module engaged. Shown by TargetHUD. */
    private static Player target;
    private static long targetTime;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        Config.loadActive();

        ClientTickEvents.END_CLIENT_TICK.register(modules::onTick);
        Compat.registerHud(Identifier.fromNamespaceAndPath("blocks", "hud"), modules::onFrame);
        Compat.registerWorldRender((pose, submits) -> {
            com.blocks.render.World3D.begin(pose, submits);
            modules.onWorldRender();
            com.blocks.render.World3D.end();
        });
        Compat.replaceHud(net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements.CROSSHAIR,
                g -> modules.get(com.blocks.module.visuals.Crosshair.class).draw(g));
        Compat.replaceHud(net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements.HEALTH_BAR,
                g -> modules.get(com.blocks.module.visuals.StatusBars.class).drawHealth(g));
        Compat.replaceHud(net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements.FOOD_BAR,
                g -> modules.get(com.blocks.module.visuals.StatusBars.class).drawFood(g));
        Compat.replaceHud(net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements.HOTBAR,
                g -> modules.get(com.blocks.module.visuals.StatusBars.class).drawHotbar(g));
        Compat.replaceHud(net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements.ARMOR_BAR,
                g -> modules.get(com.blocks.module.visuals.StatusBars.class).hideArmorRow());
        Compat.replaceHud(net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements.CHAT,
                g -> modules.get(com.blocks.module.visuals.ChatPlus.class).draw(g));
        com.blocks.world.ChunkScanner.init();
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Config.save());

        LOG.info("{} {} loaded with {} modules", NAME, VERSION, modules.all().size());
    }

    public static void setTarget(Player player) {
        target = player;
        targetTime = System.currentTimeMillis();
    }

    public static Player getTarget() {
        if (target == null || target.isRemoved() || !target.isAlive()) return null;
        if (System.currentTimeMillis() - targetTime > 3000) return null;
        return target;
    }
}
