package com.blocks.gui;

import com.mojang.blaze3d.platform.InputConstants;
import com.blocks.BlocksClient;
import com.blocks.compat.Compat;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.module.client.ClickGui;
import com.blocks.module.visuals.Hud;
import com.blocks.module.visuals.HudElement;
import com.blocks.render.Gfx;
import com.blocks.render.Shapes;
import com.blocks.render.UiScreen;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.ModeSetting;
import com.blocks.setting.NumSetting;
import com.blocks.setting.Setting;
import com.blocks.util.Config;
import com.blocks.util.Theme;
import net.minecraft.client.Minecraft;

import java.time.LocalTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiPredicate;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

/**
 * Blocks "ops console": a macOS-style glass window with a Finder-like sidebar,
 * a module table and an inspector ("dossier") on the right, finished with
 * golden-hour accents. Everything is in UI units on a 4px grid; one UI unit is
 * ClickGui.guiScale real pixels, independent of Minecraft's GUI scale.
 */
public class BlocksScreen implements UiScreen {
    private static final Minecraft mc = Minecraft.getInstance();

    // Layout (UI units)
    private static final double WIN_W = 560, WIN_H = 304, R_WIN = 11;
    private static final double ROW_H = 22, SET_ROW = 20;
    private static final float SMALL = 0.84f, LABEL = 0.66f;
    private static final double TRACK = 1.1;

    private static final int RED = 0xFFFF5F57, AMBER = 0xFFFEBC2E, GREEN = 0xFF28C840, ONLINE = 0xFF4ADE80;

    private enum Pane { MODULE, SETTINGS }

    private enum View { HUB, MENU, DOCK }

    private record HubRay(String label, Category category, double angle) {
        net.minecraft.world.item.ItemStack icon() {
            return category != null ? category.icon() : CLOCK.get();
        }
    }

    private static final java.util.function.Supplier<net.minecraft.world.item.ItemStack> GRASS =
            com.google.common.base.Suppliers.memoize(() -> new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.GRASS_BLOCK));

    private static final java.util.function.Supplier<net.minecraft.world.item.ItemStack> CLOCK =
            com.google.common.base.Suppliers.memoize(() -> new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.CLOCK));

    /** The hub's sun rays, left to right across the sky. */
    private static final HubRay[] RAYS = {
            new HubRay("Utility", Category.UTILITY, Math.toRadians(-165)),
            new HubRay("World", Category.WORLD, Math.toRadians(-135)),
            new HubRay("Combat", Category.COMBAT, Math.toRadians(-105)),
            new HubRay("Visuals", Category.VISUALS, Math.toRadians(-75)),
            new HubRay("Client", Category.CLIENT, Math.toRadians(-45)),
            new HubRay("Preferences", null, Math.toRadians(-15)),
    };

    private record Hit(BiPredicate<Double, Double> contains, IntConsumer click, DoubleConsumer drag) {}

    // Remembered between openings.
    private static Category tab = Category.COMBAT;
    private static Module selected;
    private static Pane pane = Pane.MODULE;
    private static final Particles PARTICLES = new Particles();
    private static boolean prefilled;

    private final ClickGui gui = BlocksClient.modules.get(ClickGui.class);
    private final Hud hud = BlocksClient.modules.get(Hud.class);
    private View view = View.HUB;
    private long viewSince = System.currentTimeMillis();
    private String search = "", newProfile = "", hoverText;
    private boolean searchFocused, profileFocused, editHud;
    private com.blocks.setting.StringSetting textFocus;
    private Module binding;
    private double listScroll, listScrollTarget, paneScroll, paneScrollTarget;
    private final long openTime = System.currentTimeMillis();
    private long lastFrame = System.nanoTime();
    private final Map<Object, Double> anims = new HashMap<>();
    private Module hoverModule, lastHover;
    private long hoverSince;

    private float k = 1;
    private double W, H, mx, my, fade = 1;
    private double wx, wy, ww, wh;
    private double listX, listY, listW, listH, insX, insY, insW, insH;
    private List<Hit> hits = new ArrayList<>();
    private final List<Hit> frameHits = new ArrayList<>();
    private DoubleConsumer activeDrag;
    private HudElement draggingEl;
    private double dragOffX, dragOffY;

    /** Opens the menu in a specific state (used by the in-game screenshot tests). */
    public static BlocksScreen withState(Category category, Module module, boolean settings) {
        if (category != null) tab = category;
        selected = module;
        pane = settings ? Pane.SETTINGS : Pane.MODULE;
        BlocksScreen screen = new BlocksScreen();
        screen.view = View.MENU;
        return screen;
    }

    /** The hub. */
    public static BlocksScreen hub() {
        return new BlocksScreen();
    }

    /** What the keybind opens: the side panel by default, or the hub if picked in Preferences. */
    public static BlocksScreen open() {
        BlocksScreen screen = new BlocksScreen();
        screen.view = View.DOCK;
        return screen;
    }

    /** The side panel, optionally with one module's settings expanded (used by the screenshot tests). */
    public static BlocksScreen dock(Category category, Module expand, boolean prefs) {
        if (category != null) tab = category;
        expanded = expand;
        dockPrefs = prefs;
        BlocksScreen screen = new BlocksScreen();
        screen.view = View.DOCK;
        return screen;
    }

    private void switchView(View v) {
        view = v;
        viewSince = System.currentTimeMillis();
        searchFocused = false;
    }

    // ================================================================== helpers

    private int a(int color) {
        return Theme.alphaMul(color, fade);
    }

    private double anim(Object key, double target, double dt) {
        if (!gui.animations.get()) {
            anims.put(key, target);
            return target;
        }
        double cur = anims.getOrDefault(key, target);
        cur += (target - cur) * (1 - Math.exp(-dt * 16));
        if (Math.abs(target - cur) < 0.002) cur = target;
        anims.put(key, cur);
        return cur;
    }

    private boolean over(double x, double y, double w, double h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private void hit(double x, double y, double w, double h, IntConsumer click) {
        frameHits.add(new Hit((px, py) -> px >= x && px <= x + w && py >= y && py <= y + h, click, null));
    }

    private void clippedHit(double x, double y, double w, double h, double clipTop, double clipBottom, IntConsumer click) {
        frameHits.add(new Hit((px, py) -> py >= clipTop && py <= clipBottom && px >= x && px <= x + w && py >= y && py <= y + h, click, null));
    }

    private void dragHit(double x, double y, double w, double h, double clipTop, double clipBottom, DoubleConsumer drag) {
        frameHits.add(new Hit((px, py) -> py >= clipTop && py <= clipBottom && px >= x && px <= x + w && py >= y && py <= y + h, b -> {}, drag));
    }

    private String trim(Gfx g, String s, double maxW) {
        if (g.width(s) <= maxW) return s;
        while (s.length() > 1 && g.width(s + "...") > maxW) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    private List<String> wrap(Gfx g, String text, double maxW, int maxLines) {
        List<String> lines = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            String next = line.isEmpty() ? word : line + " " + word;
            if (g.width(next) > maxW && !line.isEmpty()) {
                lines.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(next);
            }
        }
        if (!line.isEmpty()) lines.add(line.toString());
        if (lines.size() > maxLines) {
            List<String> cut = new ArrayList<>(lines.subList(0, maxLines));
            cut.set(maxLines - 1, trim(g, cut.get(maxLines - 1) + " " + lines.get(maxLines), maxW));
            return cut;
        }
        return lines;
    }

    /** Tracked monospace caps label. */
    private void label(Gfx g, String text, double x, double y, int color) {
        g.textTracked(text, x, y, a(color), LABEL, TRACK);
    }

    private double labelWidth(Gfx g, String text) {
        return g.widthTracked(text, LABEL, TRACK);
    }

    private static String codename(Module m) {
        return String.format("%02d", BlocksClient.modules.all().indexOf(m) + 1);
    }

    private boolean glowOn() {
        return gui.glow.get();
    }

    private void close() {
        Compat.setScreen(null);
    }

    /** Neutral "space gray" glass base tinted very slightly by the theme. */
    private static int glass(Theme.Palette pal, int alpha) {
        return Theme.withAlpha(Theme.blend(0xFF141518, pal.panel(), 0.45), alpha);
    }

    // ================================================================== render

    @Override
    public void renderBackground(Gfx g) {
        // The side panel keeps the game visible; it only darkens its own edge.
        if (view == View.DOCK && !editHud) {
            if (!hubShown()) return;
            if (gui.blur.get()) g.blur();
            if (gui.dim.get()) {
                double f = gui.animations.get() ? Math.min(1, (System.currentTimeMillis() - openTime) / 220.0) : 1;
                int top = Theme.withAlpha(0x0A0612, (int) (40 * f));
                int bottom = Theme.withAlpha(Theme.blend(Theme.accent(), 0xFF000000, 0.55), (int) (120 * f));
                g.gradientV(0, 0, g.guiWidth(), g.guiHeight(), top, bottom);
            }
            return;
        }
        if (gui.blur.get() && !editHud) g.blur();
        if (gui.dim.get()) {
            double f = gui.animations.get() ? Math.min(1, (System.currentTimeMillis() - openTime) / 220.0) : 1;
            // Golden-hour wash: cool and dark up top, warm toward the horizon.
            int top = Theme.withAlpha(0x06070A, (int) ((editHud ? 30 : 95) * f));
            int bottom = Theme.withAlpha(Theme.blend(Theme.accent(), 0xFF000000, 0.66), (int) ((editHud ? 60 : 150) * f));
            g.gradientV(0, 0, g.guiWidth(), g.guiHeight(), top, bottom);
        }
    }

    @Override
    public void render(Gfx g, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        double dt = Math.min(0.1, (now - lastFrame) / 1e9);
        lastFrame = now;

        float uiScale = gui.uiScale();
        k = uiScale / (float) mc.getWindow().getGuiScale();
        // The HUD sits under the background blur; redraw it sharp so it can be dragged.
        if (view == View.DOCK && !editHud && hubShown() && gui.blur.get()) {
            Hud.worldLabels = false; // finder labels would float over the menu
            hud.renderAll(g, false);
            Hud.worldLabels = true;
        }
        W = g.guiWidth() / k;
        H = g.guiHeight() / k;
        mx = mouseX / k;
        my = mouseY / k;
        frameHits.clear();
        Hud.editing = editHud;
        Hud.coveredRight = -1;

        if (editHud) {
            renderHudEditor(g);
            hits = new ArrayList<>(frameHits);
            return;
        }

        boolean anim = gui.animations.get();
        double open = Math.min(1, (System.currentTimeMillis() - openTime) / 260.0);
        double sw = Math.min(1, (System.currentTimeMillis() - viewSince) / 300.0);
        fade = anim ? ease(open) * ease(sw) : 1;

        var pose = g.pose();
        pose.pushMatrix();
        pose.scale(k, k);
        Shapes.begin(g, uiScale);

        if (view == View.DOCK) {
            renderDock(g, dt);
            renderTooltip(g);
            pose.popMatrix();
            if (hubVisible && picker == null) {
                if (facet()) renderShowcase(g, mouseX, mouseY);
                else renderHead(g, mouseX, mouseY);
            }
            hits = new ArrayList<>(frameHits);
            return;
        }

        if (gui.particles.get()) {
            if (!prefilled) {
                PARTICLES.prefill(W, H, gui.particleStyle.get());
                prefilled = true;
            }
            PARTICLES.render(pose, W, H, dt, gui.particleStyle.get(), anim ? ease(open) : 1);
        }

        // Both views pop in from the centre with a slight scale.
        double s = anim ? 0.94 + 0.06 * fade : 1;
        double ocx = W / 2, ocy = view == View.HUB ? H * 0.55 : H / 2;
        pose.pushMatrix();
        pose.translate((float) ocx, (float) ocy);
        pose.scale((float) s, (float) s);
        pose.translate((float) -ocx, (float) -ocy);
        double smx = mx, smy = my;
        mx = ocx + (mx - ocx) / s;
        my = ocy + (my - ocy) / s;
        int hitStart = frameHits.size();
        if (view == View.HUB) renderHub(g, dt);
        else renderSheet(g, dt);
        if (s != 1) {
            for (int i = hitStart; i < frameHits.size(); i++) {
                Hit h = frameHits.get(i);
                final double sc = s;
                frameHits.set(i, new Hit((hx, hy) -> h.contains.test(ocx + (hx - ocx) / sc, ocy + (hy - ocy) / sc),
                        h.click, h.drag == null ? null : v -> h.drag.accept(ocx + (v - ocx) / sc)));
            }
        }
        mx = smx;
        my = smy;
        pose.popMatrix();

        if (view == View.HUB) renderHubCorners(g);
        renderTooltip(g);
        pose.popMatrix();
        if (view == View.HUB) renderPaperdoll(g, mouseX, mouseY);
        hits = new ArrayList<>(frameHits);
    }

    private static double ease(double t) {
        return 1 - Math.pow(1 - Math.max(0, Math.min(1, t)), 3);
    }

    // ================================================================== dock (side panel + settings card + hub scene)

    private static final double DOCK_W = 200, DOCK_ROW = 22, DOCK_TOP = 118, CARD_W = 236;
    private static Module expanded;
    private static boolean dockPrefs;
    private static double dockScroll;
    private boolean dockRestored;
    private double dockX, dockY, dockW, dockH;
    private double cardX, cardY, cardW, cardH;
    private HudElement hoverEl;

    /** Panel fill at the user's chosen opacity (Preferences, "Panel Opacity"). */
    private int dockGlass(Theme.Palette pal) {
        return a(glass(pal, (int) (255 * gui.panelOpacity.get() / 100.0)));
    }

    private boolean hubShown() {
        return !gui.menuStyle.is("Panel Only");
    }

    private void renderDock(Gfx g, double dt) {
        Theme.Palette pal = Theme.current();
        boolean anim = gui.animations.get();
        if (!dockRestored) {
            dockRestored = true;
            listScroll = listScrollTarget = dockScroll;
        }
        double slide = anim ? ease((System.currentTimeMillis() - openTime) / 200.0) : 1;
        dockW = Math.min(DOCK_W, W - 16);
        dockH = H - 16;
        dockX = 8 - (dockW + 14) * (1 - slide);
        dockY = 8;
        boolean cardOpen = expanded != null || dockPrefs;
        cardW = Math.min(CARD_W, W - (dockX + dockW + 16));
        cardX = dockX + dockW + 8;
        double sceneX = (cardOpen && cardW > 150 ? cardX + cardW : dockX + dockW) + 8;
        Hud.coveredRight = (cardOpen && cardW > 150 ? cardX + cardW : dockX + dockW) + 4;
        Particles.fadeLeftOf = facet() ? Hud.coveredRight : 0;

        if (draggingEl != null) draggingEl.moveTo(mx - dragOffX, my - dragOffY, W, H);

        // Particles drift across everything, behind the UI.
        if (gui.particles.get()) {
            if (!prefilled) {
                PARTICLES.prefill(W, H, gui.particleStyle.get());
                prefilled = true;
            }
            Shapes.begin(g, gui.uiScale());
            PARTICLES.render(g.pose(), W, H, dt, gui.particleStyle.get(), fade);
        }
        if (expanded != lastCardModule || dockPrefs != lastCardPrefs) {
            lastCardModule = expanded;
            lastCardPrefs = dockPrefs;
            cardOpenAt = System.currentTimeMillis();
        }
        if (!(facet() && hubShown())) Particles.exclR = 0;
        if (hubShown() && W - sceneX > 220) {
            if (facet()) renderFacetHub(g, dt, sceneX, W - sceneX, pal);
            else renderHubScene(g, dt, sceneX, W - sceneX, pal);
        } else {
            hubVisible = false;
        }

        if (facet()) renderFacetPanel(g, dt, pal);
        else renderPanel(g, dt, pal);
        if (cardOpen && cardW > 150) {
            if (facet()) renderFacetCard(g, dt, pal);
            else renderCard(g, dt, pal);
        }
        renderPicker(g, dt, pal);

        // HUD elements can be dragged around while the menu is open.
        hoverEl = null;
        if (picker == null && draggingEl == null) {
            boolean overUi = false;
            for (Hit h : frameHits) if (h.contains.test(mx, my)) { overUi = true; break; }
            if (!overUi) {
                for (int i = hud.elements.size() - 1; i >= 0; i--) {
                    HudElement e = hud.elements.get(i);
                    if (e.visible() && e.x(W) >= Hud.coveredRight && e.contains(mx, my, W, H)) { hoverEl = e; break; }
                }
            }
        }
        HudElement mark = draggingEl != null ? draggingEl : hoverEl;
        if (mark != null) {
            double ex = mark.x(W), ey = mark.y(H);
            Shapes.cropMarks(ex - 4, ey - 4, mark.w + 8, mark.h + 8, 6, 1, Theme.withAlpha(pal.accent(), 230));
            g.textTracked(mark.name.toUpperCase() + "  ·  DRAG", ex - 3, ey - 13, Theme.TEXT, LABEL, TRACK);
        }
    }

    // ------------------------------------------------------------------ hub scene

    private boolean hubVisible;
    private static final String[] PILL_NAMES = {"Combat", "Visuals", "World", "Utility", "Client", "Settings"};

    /** Petal angles (degrees, 90 = straight down): a ring with a gap at the bottom for your name. */
    private static final double[] PETAL_ANGLES = {245, 295, 345, 35, 145, 195};
    private double hubCy, hubRb;

    private void renderHubScene(Gfx g, double dt, double ax, double aw, Theme.Palette pal) {
        hubVisible = true;
        double time = gui.animations.get() ? System.currentTimeMillis() / 1000.0 : 0;
        double cx = ax + aw / 2, cy = Math.round(H * 0.5);
        double r1 = Math.min(Math.min(aw * 0.44, H * 0.42), 185);
        double rb = Math.max(26, r1 * 0.27), r0 = rb + 16;

        // Backdrop: a soft glow and a few big blocks bobbing around the ring.
        if (glowOn()) Shapes.circleGlow(cx, cy, 2, r1 * 1.05, a(Theme.withAlpha(pal.accent(), 60)));
        var blocks = Particles.BLOCKS.get();
        double[][] spots = {{-1.25, -0.75, 26}, {1.3, -0.55, 22}, {-1.35, 0.7, 20}, {1.2, 0.85, 28}};
        for (int i = 0; i < spots.length; i++) {
            double bx = cx + spots[i][0] * r1, by = cy + spots[i][1] * r1 + Math.sin(time * 0.9 + i * 1.7) * 5;
            if (bx < ax + 16 || bx > ax + aw - 16) continue;
            var pose2 = g.pose();
            pose2.pushMatrix();
            pose2.translate((float) bx, (float) by);
            pose2.rotate((float) (Math.sin(time * 0.5 + i) * 0.25));
            g.itemIcon(blocks[(i * 3 + 1) % blocks.length], 0, 0, spots[i][2], Shapes.scale());
            pose2.popMatrix();
        }

        // Petals.
        boolean searching = !search.isEmpty();
        double ha = Math.toRadians(20.5);
        for (int i = 0; i < PETAL_ANGLES.length; i++) {
            double ang = Math.toRadians(PETAL_ANGLES[i]);
            boolean settings = i == PETAL_ANGLES.length - 1;
            Category cat = settings ? null : Category.values()[i];
            boolean active = settings ? dockPrefs : !searching && tab == cat;
            double dx = mx - cx, dy = my - cy, rho = Math.hypot(dx, dy);
            double dphi = Math.atan2(Math.sin(Math.atan2(dy, dx) - ang), Math.cos(Math.atan2(dy, dx) - ang));
            boolean hov = rho >= r0 && rho <= r1 + 6 && Math.abs(dphi) <= ha + 0.03;
            double t = anim("petal/" + i, active ? 1 : 0, dt), hv = anim("petalh/" + i, hov ? 1 : 0, dt);
            double push = 7 * hv + 3 * t;
            double px = cx + Math.cos(ang) * push, py = cy + Math.sin(ang) * push;
            double rc = 18;
            if (glowOn() && (hv > 0.01 || t > 0.01)) Shapes.ray(px, py, ang, ha, r0, r1, rc, 16, Shapes.Layer.GLOW,
                    a(Theme.withAlpha(pal.accent(), (int) (90 * Math.max(hv, t)))));
            int fill = Theme.blend(Theme.blend(glass(pal, 255), 0xFFFFFFFF, 0.10 + 0.08 * hv), pal.accent(), 0.30 * t);
            Shapes.ray(px, py, ang, ha, r0, r1, rc, 16, Shapes.Layer.FILL, a(Theme.withAlpha(fill, (int) (120 + 50 * hv + 50 * t))));
            Shapes.ray(px, py, ang, ha, r0, r1, rc, 16, Shapes.Layer.STROKE,
                    a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.55), (int) (80 + 140 * Math.max(hv, t)))));
            double mid = r0 + (r1 - r0) * 0.55;
            double ix = px + Math.cos(ang) * mid, iy = py + Math.sin(ang) * mid;
            double isz = 22 + 3 * hv;
            if (settings) Shapes.icon("gear", ix, iy - 6, isz * 0.9, a(Theme.blend(Theme.TEXT_DIM, Theme.TEXT, Math.max(hv, t))));
            else g.itemIcon(cat.icon(), ix, iy - 6, isz, Shapes.scale());
            String label = settings ? "Settings" : cat.title;
            g.textCentered(label, (int) ix, (int) (iy + 10), a(Theme.blend(Theme.TEXT_DIM, Theme.TEXT, Math.max(hv, t))), false);
            if (!settings) {
                String n = String.valueOf(BlocksClient.modules.inCategory(cat).size());
                g.textMono(n, ix - g.widthMono(n, 0.62f) / 2, iy + 20, a(Theme.withAlpha(Theme.TEXT_FAINT, (int) (140 + 100 * hv))), 0.62f);
            }
            final int idx = i;
            final double fang = ang, fr0 = r0, fr1 = r1, fha = ha, fcx = cx, fcy = cy;
            frameHits.add(new Hit((hx, hy) -> {
                double ddx = hx - fcx, ddy = hy - fcy, rr = Math.hypot(ddx, ddy);
                double dp = Math.atan2(Math.sin(Math.atan2(ddy, ddx) - fang), Math.cos(Math.atan2(ddy, ddx) - fang));
                return rr >= fr0 && rr <= fr1 + 6 && Math.abs(dp) <= fha + 0.03;
            }, b -> {
                if (idx == PETAL_ANGLES.length - 1) {
                    dockPrefs = !dockPrefs;
                    if (dockPrefs) expanded = null;
                    paneScroll = paneScrollTarget = 0;
                } else {
                    tab = Category.values()[idx];
                    search = "";
                    searchFocused = false;
                    listScroll = listScrollTarget = 0;
                }
            }, null));
        }

        // Centre bubble: your head lives here (drawn after the UI pass, see render()).
        if (glowOn()) Shapes.circleGlow(cx, cy, rb, 14, a(Theme.withAlpha(pal.accent(), 80)));
        Shapes.circle(cx, cy, rb, a(Theme.withAlpha(Theme.blend(glass(pal, 255), pal.accent(), 0.18), 215)));
        Shapes.ring(cx, cy, rb, 1.4, a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.45), 230)));
        hubCx = cx;
        hubCy = cy;
        hubRb = rb;
        hit(cx - rb, cy - rb, rb * 2, rb * 2, b -> {});

        // Name and profile chip in the gap under the bubble.
        String name = mc.player.getName().getString();
        double ny = cy + rb + 9;
        g.textBold(name, (int) (cx - g.widthBold(name) / 2), (int) ny, a(Theme.TEXT), false);
        String prof = Config.active();
        double pw = g.widthScaled(prof, 0.72f) + 12;
        Shapes.roundRect(cx - pw / 2, ny + 12, pw, 11, 5.5, a(Theme.withAlpha(pal.accent(), 220)));
        g.textScaled(prof, cx - pw / 2 + 6, ny + 14.5, a(Theme.TEXT_ON_ACCENT), 0.72f);
    }

    /** Your head in the centre bubble, turning to follow the cursor. */
    private void renderHead(Gfx g, int mouseX, int mouseY) {
        double rb = hubRb;
        // Only the head: the clip box ends exactly at the bottom of the head, so no shoulders show.
        double D = rb * 2;
        double headPx = D * 0.36;                 // head is 0.5 blocks tall
        double hw = headPx * 0.72;                // half-width of the clip box (head + room to turn)
        double top = hubCy - hw, bottomY = hubCy + headPx * 0.44; // stop just above the shoulders
        int x1 = (int) ((hubCx - hw) * k), x2 = (int) ((hubCx + hw) * k);
        int y1 = (int) (top * k), y2 = (int) (bottomY * k);
        // Players render at 15/16 scale: the head is 0.469 blocks tall and centred 1.64 blocks up.
        double perBlock = headPx / (0.5 * 0.9375);
        int size = (int) Math.round(perBlock * k);
        // The renderer centres the point (height/2 + yOffset) on the box; aim it so the head centre lands on the bubble centre.
        double boxMid = (top + bottomY) / 2;
        float yOffset = (float) (1.75 * 0.9375 - 0.9 + (hubCy - boxMid) / perBlock);
        // Just you: armour comes off for the portrait (put straight back afterwards, same frame).
        var slots = new net.minecraft.world.entity.EquipmentSlot[]{net.minecraft.world.entity.EquipmentSlot.HEAD, net.minecraft.world.entity.EquipmentSlot.CHEST};
        net.minecraft.world.item.ItemStack[] saved = new net.minecraft.world.item.ItemStack[slots.length];
        for (int i = 0; i < slots.length; i++) {
            saved[i] = mc.player.getItemBySlot(slots[i]);
            if (!saved[i].isEmpty()) mc.player.setItemSlot(slots[i], net.minecraft.world.item.ItemStack.EMPTY);
        }
        com.blocks.module.visuals.Chams.paused = true;
        try {
            g.entityFollowsMouse(x1, y1, x2, y2, size, yOffset, mouseX, mouseY, mc.player);
        } finally {
            com.blocks.module.visuals.Chams.paused = false;
            for (int i = 0; i < slots.length; i++) if (!saved[i].isEmpty()) mc.player.setItemSlot(slots[i], saved[i]);
        }
    }

    // ------------------------------------------------------------------ panel (module list)

    private static final double DROW_H = 26, DROW_GAP = 6;

    private void renderPanel(Gfx g, double dt, Theme.Palette pal) {
        double x = dockX, y = dockY, w = dockW, h = dockH;
        // A faint backdrop only; the rows themselves carry the glass.
        Shapes.roundRect(x, y, w, h, 14, a(glass(pal, (int) (110 * gui.panelOpacity.get() / 100.0))));
        hit(x, y, w, h, b -> {});
        boolean searching = !search.isEmpty();
        List<Module> mods = listModules();

        // ---- header: the open category (or search results) and a module count
        double hy = y + 16;
        if (searching) Shapes.icon("search", x + 18, hy + 4, 10, a(pal.accent2()));
        else g.itemIcon(tab.icon(), x + 18, hy + 4, 11, Shapes.scale());
        var pose = g.pose();
        pose.pushMatrix();
        pose.translate((float) (x + 29), (float) (hy - 1));
        pose.scale(1.15f, 1.15f);
        g.textBold(searching ? "Search" : tab.title, 0, 0, a(Theme.TEXT), false);
        pose.popMatrix();
        String cnt = mods.size() + " modules";
        g.textScaled(cnt, x + w - 12 - g.widthScaled(cnt, 0.72f), hy + 1.5, a(Theme.TEXT_FAINT), 0.72f);

        // Small round buttons: preferences and hub on/off.
        double by = y + h - 17;
        double gx = x + w - 18;
        boolean hovGear = over(gx - 9, by - 9, 18, 18);
        Shapes.circle(gx, by, 9, a(dockPrefs ? Theme.withAlpha(pal.accent(), 230) : Theme.withAlpha(0xFFFFFF, hovGear ? 30 : 12)));
        Shapes.icon("gear", gx, by, 10, a(dockPrefs ? Theme.TEXT_ON_ACCENT : hovGear ? Theme.TEXT : Theme.TEXT_DIM));
        hit(gx - 9, by - 9, 18, 18, b -> {
            dockPrefs = !dockPrefs;
            if (dockPrefs) expanded = null;
            paneScroll = paneScrollTarget = 0;
        });
        if (hovGear) hoverText = "Preferences";
        double hbx = gx - 22;
        boolean hovHub = over(hbx - 9, by - 9, 18, 18);
        Shapes.circle(hbx, by, 9, a(Theme.withAlpha(0xFFFFFF, hovHub ? 30 : 12)));
        Shapes.icon("grid", hbx, by, 10, a(hubShown() ? pal.accent2() : hovHub ? Theme.TEXT : Theme.TEXT_DIM));
        hit(hbx - 9, by - 9, 18, 18, b -> gui.menuStyle.set(hubShown() ? "Panel Only" : "Hub + Panel"));
        if (hovHub) hoverText = hubShown() ? "Hide the hub" : "Show the hub";
        // Wordmark, with the hint under it.
        g.itemIcon(GRASS.get(), x + 17, by - 5, 9, Shapes.scale());
        g.textScaled("Blocks Client", x + 25, by - 8.5, a(Theme.TEXT_DIM), 0.82f);
        g.textScaled("Esc or click outside to close", x + 12, by + 3, a(Theme.TEXT_FAINT), 0.62f);

        // ---- search
        double sx = x + 10, sy = y + 34, sw = w - 20, sh = 18;
        boolean hovSearch = over(sx, sy, sw, sh);
        Shapes.roundRect(sx, sy, sw, sh, 9, a(Theme.withAlpha(0xFFFFFF, searchFocused ? 22 : hovSearch ? 14 : 8)));
        Shapes.roundOutline(sx, sy, sw, sh, 9, 1, a(searchFocused ? Theme.withAlpha(pal.accent(), 200) : 0x14FFFFFF));
        Shapes.icon("search", sx + 11, sy + sh / 2, 7, a(searchFocused ? Theme.TEXT : Theme.TEXT_FAINT));
        if (search.isEmpty() && !searchFocused) g.textScaled("Search, or just type", sx + 21, sy + 5.5, a(Theme.TEXT_FAINT), 0.88f);
        else g.textScaled(trim(g, search, (sw - 40) / 0.88) + caret(searchFocused), sx + 21, sy + 5.5, a(Theme.TEXT), 0.88f);
        if (!search.isEmpty()) {
            double cx = sx + sw - 10;
            Shapes.icon("close", cx, sy + sh / 2, 6, a(over(cx - 7, sy + 2, 14, 14) ? Theme.TEXT : Theme.TEXT_FAINT));
            hit(cx - 7, sy + 2, 14, 14, b -> {
                search = "";
                searchFocused = false;
                listScroll = listScrollTarget = 0;
            });
        }
        hit(sx, sy, sw, sh, b -> {
            searchFocused = true;
            profileFocused = false;
        });

        // ---- category tabs (only without the hub; with it, the hub picks the category)
        double top = sy + sh + 10;
        if (!hubVisible) {
            Category[] cats = Category.values();
            double tx = x + 8, tw = (w - 16) / cats.length, th = 28;
            for (int i = 0; i < cats.length; i++) {
                Category c = cats[i];
                double cx = tx + i * tw;
                boolean active = !searching && tab == c;
                boolean hov = over(cx + 1, top, tw - 2, th);
                double t = anim("dtab/" + c, active ? 1 : 0, dt);
                if (t > 0.01) Shapes.roundRect(cx + 1, top, tw - 2, th, 8, a(Theme.withAlpha(pal.accent(), (int) (70 * t))));
                if (hov && t < 0.99) Shapes.roundRect(cx + 1, top, tw - 2, th, 8, a(0x12FFFFFF));
                g.itemIcon(c.icon(), cx + tw / 2, top + 10, 11, Shapes.scale());
                g.textScaled(c.title, cx + tw / 2 - g.widthScaled(c.title, 0.58f) / 2, top + 19, a(Theme.blend(hov ? Theme.TEXT_DIM : Theme.TEXT_FAINT, Theme.TEXT, t)), 0.58f);
                final Category cat = c;
                hit(cx + 1, top, tw - 2, th, b -> {
                    tab = cat;
                    search = "";
                    searchFocused = false;
                    listScroll = listScrollTarget = 0;
                });
            }
            top += th + 8;
        }

        // ---- rows
        double bottom = y + h - 36;
        double lx = x + 16, lw = w - 26;
        double content = mods.size() * (DROW_H + DROW_GAP) - DROW_GAP;
        listScrollTarget = Math.max(0, Math.min(listScrollTarget, content - (bottom - top)));
        listScroll += (listScrollTarget - listScroll) * (gui.animations.get() ? 1 - Math.exp(-dt * 16) : 1);
        hoverModule = null;
        // The accent rail on the left doubles as the scrollbar.
        double view = bottom - top;
        Shapes.roundRect(x + 7, top, 1.5, view, 0.75, a(0x22FFFFFF));
        double barH = content > view ? Math.max(20, view * view / content) : view;
        double barY = content > view ? top + (view - barH) * (listScroll / (content - view)) : top;
        Shapes.roundRect(x + 7, barY, 1.5, barH, 0.75, a(Theme.withAlpha(pal.accent(), 200)));
        g.scissor((int) x, (int) top - 4, (int) (x + w), (int) bottom + 4);
        for (int i = 0; i < mods.size(); i++) {
            double ry = top - listScroll + i * (DROW_H + DROW_GAP);
            if (ry + DROW_H < top - 4 || ry > bottom + 4) continue;
            dockRow(g, mods.get(i), lx, ry, lw, top, bottom, dt, pal);
        }
        g.noScissor();
        if (mods.isEmpty()) g.textScaled("Nothing matches \"" + search + "\"", lx + 4, top + 6, a(Theme.TEXT_DIM), SMALL);
    }

    private void dockRow(Gfx g, Module m, double x, double y, double w, double top, double bottom, double dt, Theme.Palette pal) {
        boolean hov = over(x, y, w, DROW_H) && my >= top && my <= bottom;
        if (hov) hoverModule = m;
        boolean open = m == expanded;
        double on = anim(m, m.isEnabled() ? 1 : 0, dt);
        double hv = anim("hov/" + m.getName(), hov ? 1 : 0, dt);
        double sel = anim("sel/" + m.getName(), open ? 1 : 0, dt);
        // The open one pops out a little.
        double rx = x - 5 * sel, rw = w + 8 * sel, r = 9;
        int opa = (int) (255 * gui.panelOpacity.get() / 100.0);
        if (glowOn() && (on > 0.01 || sel > 0.01)) Shapes.glow(rx, y, rw, DROW_H, r, 8, a(Theme.withAlpha(pal.accent(), (int) (70 * Math.max(on, sel)))));
        Shapes.roundRect(rx, y, rw, DROW_H, r, a(Theme.withAlpha(Theme.blend(glass(pal, 255), pal.accent(), 0.16 * on + 0.1 * sel), (int) (opa * (0.78 + 0.22 * hv)))));
        int outline = Theme.blend(Theme.withAlpha(0xFFFFFF, (int) (26 + 34 * hv)), Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.2), 235), Math.max(on, sel));
        Shapes.roundOutline(rx, y, rw, DROW_H, r, 1, a(outline));

        double cy = y + DROW_H / 2;
        int fg = Theme.blend(Theme.TEXT_FAINT, Theme.TEXT, Math.max(on, Math.max(hv * 0.6, sel)));
        double right = rx + rw - 10;
        toggleSwitch(right - 20, cy - 5, m.isEnabled(), "dock/" + m.getName(), dt);
        double chipW = 0;
        String key = binding == m ? "PRESS KEY" : m.getKey() > 0 ? Compat.keyName(m.getKey()) : null;
        if (key != null) {
            if (key.length() > 6) key = key.substring(0, 6);
            chipW = g.widthMono(key, 0.64f) + 10;
            double cx = right - 26 - chipW;
            Shapes.roundRect(cx, cy - 6, chipW, 12, 4, a(binding == m ? Theme.withAlpha(pal.accent(), 220) : Theme.withAlpha(0xFFFFFF, 20)));
            g.textMono(key, cx + 5, cy - 2.4, a(binding == m ? Theme.TEXT_ON_ACCENT : Theme.TEXT_DIM), 0.64f);
            chipW += 6;
        }
        double nameMax = rw - 12 - 30 - chipW - (m.isFavorite() ? 10 : 0);
        g.text(trim(g, m.getName(), nameMax), (int) (rx + 11), (int) (cy - 4), a(fg), false);
        if (m.isFavorite()) Shapes.icon("star_filled", rx + 11 + Math.min(nameMax, g.width(m.getName())) + 7, cy, 7, a(pal.accent2()));

        clippedHit(x, y, w, DROW_H, top, bottom, b -> {
            boolean onSwitch = mx >= right - 24;
            if (b == 1 || (b == 0 && onSwitch)) {
                m.toggle();
            } else if (b == 0) {
                expanded = expanded == m ? null : m;
                dockPrefs = false;
                paneScroll = paneScrollTarget = 0;
            } else if (b == 2) {
                binding = m;
            }
        });
    }

    // ------------------------------------------------------------------ settings card

    private void renderCard(Gfx g, double dt, Theme.Palette pal) {
        Module m = expanded;
        double x = cardX, w = cardW;
        int opa = (int) (255 * gui.panelOpacity.get() / 100.0);
        if (dockPrefs) {
            cardY = dockY;
            cardH = Math.min(dockH, 440);
            cardShell(x, cardY, w, cardH, pal, opa);
            insX = x;
            insY = cardY;
            insW = w;
            insH = cardH;
            renderPreferences(g, dt, pal);
            closeButton(g, x + w - 17, cardY + 17, () -> dockPrefs = false);
            return;
        }
        double inner = w - 40;
        List<String> desc = wrap(g, m.getDescription(), (w - 28) / SMALL, 3);
        double headH = 30 + desc.size() * 9 + 8;
        double body = 0;
        for (Setting st : m.getSettings()) if (st.isVisible()) body += rowHeight(g, st, inner);
        if (m instanceof com.blocks.module.world.AutoBuilder ab) body += 12 + builderSection(g, ab, 0, 0, inner, false, 0, 0, pal);
        if (m instanceof com.blocks.module.world.AutoMine am) body += 12 + mineSection(g, am, 0, 0, inner, false, 0, 0, pal);
        if (body == 0) body = 16;
        body += 12;
        double footH = 34;
        cardH = Math.min(dockH, headH + body + 8 + footH);
        cardY = Math.max(dockY, Math.min(dockY + 26, dockY + dockH - cardH));
        double y = cardY, h = cardH;
        cardShell(x, y, w, h, pal, opa);

        // Header: name, favourite star, on/off switch, close.
        double hx = x + 14;
        g.textBold(trim(g, m.getName(), w - 100), (int) hx, (int) (y + 13), a(Theme.TEXT), false);
        closeButton(g, x + w - 17, y + 17, () -> expanded = null);
        toggleSwitch(x + w - 56, y + 12, m.isEnabled(), "card/" + m.getName(), dt);
        hit(x + w - 60, y + 8, 28, 18, b -> m.toggle());
        boolean hovStar = over(x + w - 80, y + 9, 16, 16);
        Shapes.icon(m.isFavorite() ? "star_filled" : "star", x + w - 72, y + 17, 9,
                a(m.isFavorite() ? pal.accent2() : hovStar ? Theme.TEXT : Theme.TEXT_FAINT));
        hit(x + w - 80, y + 9, 16, 16, b -> m.setFavorite(!m.isFavorite()));
        if (hovStar) hoverText = m.isFavorite() ? "Unfavourite" : "Favourite";
        double dy = y + 26;
        for (String line : desc) {
            g.textScaled(line, hx, dy, a(Theme.TEXT_FAINT), SMALL);
            dy += 9;
        }
        dy += 6;

        // Body: grouped settings in an inner panel, scrollable.
        double gx = x + 8, gw = w - 16, gTop = dy, gBottom = y + h - footH - 6;
        Shapes.roundRect(gx, gTop, gw, gBottom - gTop, 10, a(0x0CFFFFFF));
        Shapes.roundOutline(gx, gTop, gw, gBottom - gTop, 10, 1, a(0x16FFFFFF));
        double clipTop = gTop + 2, clipBottom = gBottom - 2;
        double view = clipBottom - clipTop;
        paneScrollTarget = Math.max(0, Math.min(paneScrollTarget, body - view));
        paneScroll += (paneScrollTarget - paneScroll) * (gui.animations.get() ? 1 - Math.exp(-dt * 16) : 1);
        g.scissor((int) gx, (int) clipTop, (int) (gx + gw), (int) clipBottom);
        double sx = gx + 12, ry = gTop + 6 - paneScroll;
        boolean any = false;
        for (Setting st : m.getSettings()) {
            if (!st.isVisible()) continue;
            any = true;
            double rh = rowHeight(g, st, inner);
            if (ry + rh >= clipTop && ry <= clipBottom) renderSettingRow(g, st, sx, ry, inner, rh, clipTop, clipBottom, dt, pal);
            ry += rh;
        }
        if (m instanceof com.blocks.module.world.AutoBuilder ab) {
            ry += 12;
            ry += builderSection(g, ab, sx, ry, inner, true, clipTop, clipBottom, pal);
        }
        if (m instanceof com.blocks.module.world.AutoMine am) {
            ry += 12;
            ry += mineSection(g, am, sx, ry, inner, true, clipTop, clipBottom, pal);
        }
        if (!any && !(m instanceof com.blocks.module.world.AutoBuilder)) g.textScaled("No settings. Toggle and go.", sx, gTop + 8, a(Theme.TEXT_FAINT), SMALL);
        g.noScissor();
        if (body > view) {
            double barH = Math.max(14, view * view / body);
            double barY = clipTop + (view - barH) * (paneScroll / (body - view));
            Shapes.roundRect(gx + gw - 4, barY, 2, barH, 1, a(Theme.withAlpha(pal.accent(), 160)));
        }

        // Footer: the keybind, in its own little box.
        double fy = y + h - footH;
        Shapes.roundRect(gx, fy, gw, footH - 8, 9, a(0x0CFFFFFF));
        Shapes.roundOutline(gx, fy, gw, footH - 8, 9, 1, a(0x16FFFFFF));
        boolean listening = binding == m;
        String key = listening ? "PRESS KEY" : m.getKey() > 0 ? Compat.keyName(m.getKey()).toUpperCase() : "None";
        double kw = g.widthMono(key, 0.72f) + 14;
        double fcy = fy + (footH - 8) / 2;
        g.text("Keybind", (int) (gx + 11), (int) (fcy - 4), a(Theme.TEXT), false);
        String tip = listening ? "Esc clears" : "click to rebind";
        g.textScaled(tip, gx + gw - 10 - kw - 6 - g.widthScaled(tip, 0.66f), fcy - 2.5, a(Theme.TEXT_FAINT), 0.66f);
        boolean hovKey = over(gx + gw - 10 - kw, fcy - 7, kw, 14);
        Shapes.roundRect(gx + gw - 10 - kw, fcy - 7, kw, 14, 5, a(listening ? Theme.withAlpha(pal.accent(), 235) : Theme.withAlpha(0xFFFFFF, hovKey ? 34 : 18)));
        g.textMono(key, gx + gw - 10 - kw + 7, fcy - 2.8, a(listening ? Theme.TEXT_ON_ACCENT : Theme.TEXT), 0.72f);
        hit(gx, fy, gw, footH - 8, b -> binding = listening ? null : m);
    }

    /** The card's glass: soft shadow, accent glow and a bright accent rim. */
    private void cardShell(double x, double y, double w, double h, Theme.Palette pal, int opa) {
        Shapes.glow(x, y + 4, w, h, 14, 18, a(0x55000000));
        if (glowOn()) Shapes.glow(x, y, w, h, 14, 12, a(Theme.withAlpha(pal.accent(), 70)));
        Shapes.roundRect(x, y, w, h, 14, a(Theme.withAlpha(Theme.blend(glass(pal, 255), pal.accent(), 0.08), opa)));
        Shapes.roundOutline(x, y, w, h, 14, 1.2, a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.3), 210)));
        hit(x, y, w, h, b -> {});
    }

    // ================================================================== Facet design (hub + panel + card)

    private Module lastCardModule;
    private boolean lastCardPrefs;
    private long cardOpenAt;
    private double rowAnchorX = -1, rowAnchorY;

    private boolean facet() {
        return !gui.design.is("Classic");
    }

    private static double easeOutBack(double t) {
        t = Math.max(0, Math.min(1, t));
        double c1 = 1.70158, c3 = c1 + 1;
        return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
    }

    // Showcase geometry, shared with the character pass in render().
    private double showFeetX, showFeetY, showHeight;
    private boolean showcaseVisible;

    /**
     * Hub: a character showcase. You stand on a glowing glass pedestal under a stage light,
     * over an isometric floor; categories live in a dock that magnifies under the cursor.
     */
    private void renderFacetHub(Gfx g, double dt, double ax, double aw, Theme.Palette pal) {
        hubVisible = true;
        showcaseVisible = true;
        long now = System.currentTimeMillis();
        boolean animOn = gui.animations.get();
        double time = animOn ? now / 1000.0 : 0;
        double intro = animOn ? ease((now - openTime) / 520.0) : 1;
        double cx = Math.round(ax + aw / 2);
        int glassC = glass(pal, 255);

        // ---- layout (everything centred on cx)
        // Dock first (clear of the HUD), then the pedestal and you stacked above it, all on one centre line.
        double dockTile = 56, dockH = 66;
        double dockW = dockTile * 6 + 24;
        double dockY = H - dockH - 18;
        // Keep the dock clear of HUD elements.
        for (int pass = 0; pass < 4; pass++) {
            boolean moved = false;
            for (HudElement el : hud.elements) {
                if (!el.visible()) continue;
                double ex = el.x(W), ey = el.y(H);
                if (ex < cx + dockW / 2 && ex + el.w > cx - dockW / 2 && ey < dockY + dockH && ey + el.h > dockY) {
                    dockY = ey - dockH - 6;
                    moved = true;
                }
            }
            if (!moved) break;
        }
        double pedR = Math.min(62, aw * 0.14);             // pedestal cube radius
        double pedCy = dockY - 22 - pedR;                  // cube centre, its bottom corner just above the dock
        double feetY = pedCy - pedR / 2;                   // the top face is centred on your feet
        double charH = Math.max(80, Math.min(136, feetY - 70)); // leaves room for the name plate above
        showFeetX = cx;
        showFeetY = feetY;
        showHeight = charH;

        // ---- stage light: a soft beam from above onto the pedestal
        double beamTop = 0, beamBot = feetY;
        double bw0 = 46, bw1 = pedR * 2.1;
        Shapes.poly(new double[]{cx - bw0, cx + bw0, cx + bw1, cx - bw1}, new double[]{beamTop, beamTop, beamBot, beamBot}, 0, 0,
                Shapes.Layer.SHEEN, a(Theme.withAlpha(Theme.blend(pal.accent2(), 0xFFFFFFFF, 0.4), (int) (70 * intro))));
        if (glowOn()) Shapes.circleGlow(cx, feetY, 2, pedR * 2.6, a(Theme.withAlpha(pal.accent(), (int) (70 * intro))));

        // ---- isometric floor grid, fading out around the pedestal
        double floorY = pedCy + pedR * 0.5, cell = pedR * 0.62, reach = pedR * 4.2;
        double slope = 0.5774; // tan(30 degrees)
        for (int dir = -1; dir <= 1; dir += 2) {
            for (int k = -6; k <= 6; k++) {
                // Line: y - floorY = dir * slope * (x - cx) + k * cell
                double prevX = cx - reach, prevY = floorY + dir * slope * (prevX - cx) + k * cell;
                for (int seg = 1; seg <= 14; seg++) {
                    double x1 = cx - reach + 2 * reach * seg / 14.0, y1 = floorY + dir * slope * (x1 - cx) + k * cell;
                    double mxs = (prevX + x1) / 2, mys = (prevY + y1) / 2;
                    double d = Math.hypot((mxs - cx) / reach, (mys - floorY) / (reach * 0.5));
                    if (mys > floorY - 2 && d < 1 && mys < H) {
                        int al = (int) (46 * (1 - d) * (1 - d) * intro);
                        if (al > 1) Shapes.line(prevX, prevY, x1, y1, 0.8, a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.5), al)));
                    }
                    prevX = x1;
                    prevY = y1;
                }
            }
        }
        // Light pool on the floor, and a slow ring travelling outward.
        double ring = animOn ? (time * 0.35) % 1 : 0.5;
        Shapes.ring(cx, floorY + 4, pedR * (1.1 + ring * 1.6), 0.8, a(Theme.withAlpha(pal.accent(), (int) (120 * (1 - ring) * intro))));

        // ---- pedestal: a big glass block, rim lit, gently breathing
        double breathe = 0.5 + 0.5 * Math.sin(time * 1.6);
        if (glowOn()) Shapes.hex(cx, pedCy, pedR, pedR * 0.06, 16, Shapes.Layer.GLOW, a(Theme.withAlpha(pal.accent(), (int) ((70 + 50 * breathe) * intro))));
        Shapes.isoCube(cx, pedCy, pedR,
                a(Theme.withAlpha(Theme.blend(Theme.blend(glassC, 0xFFFFFFFF, 0.30), pal.accent2(), 0.35), (int) (210 * intro))),
                a(Theme.withAlpha(Theme.blend(glassC, pal.accent(), 0.45), (int) (200 * intro))),
                a(Theme.withAlpha(Theme.blend(glassC, pal.accent(), 0.22), (int) (200 * intro))),
                a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.7), (int) ((150 + 80 * breathe) * intro))));
        // Inner top face glow where you stand, and a soft contact shadow under your feet.
        Shapes.circleGlow(cx, feetY + 1, charH * 0.05, charH * 0.12, a(Theme.withAlpha(0xFF000000, (int) (110 * intro))));

        // ---- motes rising off the pedestal
        if (animOn) {
            for (int i = 0; i < 9; i++) {
                double life = ((time * 0.45 + i * 0.137) % 1);
                double mxp = cx + Math.sin(i * 2.3 + time * 0.6) * pedR * 0.75;
                double myp = feetY - life * charH * 1.1;
                int al = (int) (170 * Math.sin(Math.PI * life) * intro);
                Shapes.hex(mxp, myp, 1.6 + (i % 3) * 0.5, 0.3, 0, Shapes.Layer.FILL, a(Theme.withAlpha(Theme.blend(pal.accent2(), 0xFFFFFFFF, 0.5), al)));
            }
        }

        // ---- name plate, centred above the head
        String name = mc.player.getName().getString();
        String sub = Config.active() + "   " + countEnabled() + " on";
        double nw = Math.max(g.widthBold(name), g.widthScaled(sub, 0.7f)) + 26;
        double ny = feetY - charH - 50;
        Shapes.roundRect(cx - nw / 2, ny, nw, 26, 13, a(Theme.withAlpha(glassC, (int) (215 * intro))));
        Shapes.roundOutline(cx - nw / 2, ny, nw, 26, 13, 1, a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.4), (int) (190 * intro))));
        g.textBold(name, (int) (cx - g.widthBold(name) / 2), (int) (ny + 4), a(Theme.TEXT), false);
        g.textScaled(sub, cx - g.widthScaled(sub, 0.7f) / 2, ny + 15.5, a(Theme.withAlpha(pal.accent2(), 230)), 0.7f);

        // ---- dock: six glass cubes that magnify under the cursor
        double dockIntro = animOn ? ease((now - openTime - 120) / 420.0) : 1;
        double dy = dockY + (1 - dockIntro) * 24;
        double saved = fade;
        fade *= dockIntro;
        double dx0 = cx - dockW / 2;
        Shapes.glow(dx0, dy + 4, dockW, dockH, 18, 14, a(0x40000000));
        Shapes.facetPanel(dx0, dy, dockW, dockH, 14, 12, 0, Shapes.Layer.FILL, a(Theme.withAlpha(glassC, 205)));
        Shapes.facetPanel(dx0, dy, dockW, dockH, 14, 12, 0, Shapes.Layer.SHEEN, a(Theme.withAlpha(0xFFFFFFFF, 20)));
        Shapes.facetPanel(dx0, dy, dockW, dockH, 14, 12, 0, Shapes.Layer.STROKE, a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.35), 180)));
        hit(dx0, dy, dockW, dockH, b -> {});
        boolean inDock = my >= dy - 20 && my <= dy + dockH + 6 && mx >= dx0 - 10 && mx <= dx0 + dockW + 10;
        boolean searching = !search.isEmpty();
        for (int i = 0; i < 6; i++) {
            boolean settings = i == 5;
            Category cat = settings ? null : Category.values()[i];
            boolean active = settings ? dockPrefs : !dockPrefs && !searching && tab == cat;
            double tx = dx0 + 12 + dockTile * i + dockTile / 2;
            double near = inDock ? Math.max(0, 1 - Math.abs(mx - tx) / 70) : 0;
            double mag = anim("dock/m" + i, near, dt);
            double act = anim("dock/a" + i, active ? 1 : 0, dt);
            double r = 16 * (1 + 0.30 * mag);
            double ty = dy + dockH / 2 - 7 - 8 * mag;
            if (glowOn() && (act > 0.01 || mag > 0.3)) Shapes.hex(tx, ty, r, r * 0.06, 9, Shapes.Layer.GLOW, a(Theme.withAlpha(pal.accent(), (int) (120 * Math.max(act, mag * 0.6)))));
            Shapes.isoCube(tx, ty, r,
                    a(Theme.withAlpha(Theme.blend(Theme.blend(glassC, 0xFFFFFFFF, 0.38), pal.accent2(), 0.8 * act), (int) (190 + 50 * act))),
                    a(Theme.withAlpha(Theme.blend(Theme.blend(glassC, pal.accent(), 0.30), pal.accent(), 0.75 * act), (int) (180 + 60 * act))),
                    a(Theme.withAlpha(Theme.blend(Theme.blend(glassC, pal.accent(), 0.12), Theme.blend(pal.accent(), 0xFF000000, 0.3), 0.75 * act), (int) (175 + 60 * act))),
                    a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.65), (int) (120 + 120 * Math.max(act, mag)))));
            if (settings) Shapes.icon("gear", tx, ty - r * 0.5, r * 0.5, a(act > 0.5 ? Theme.TEXT_ON_ACCENT : Theme.TEXT));
            else g.itemIcon(cat.icon(), tx, ty - r * 0.5, r * 0.62, Shapes.scale());
            String label = settings ? "Settings" : cat.title;
            float ls = 0.7f;
            g.textScaled(label, tx - g.widthScaled(label, ls) / 2, dy + dockH - 13, a(Theme.blend(Theme.TEXT_FAINT, Theme.TEXT, Math.max(act, mag))), ls);
            if (act > 0.01) Shapes.roundRect(tx - 7, dy + dockH - 3.5, 14, 2, 1, a(Theme.withAlpha(pal.accent(), (int) (255 * act))));
            final int idx = i;
            hit(tx - dockTile / 2, dy, dockTile, dockH, b -> {
                if (idx == 5) {
                    dockPrefs = !dockPrefs;
                    if (dockPrefs) expanded = null;
                    paneScroll = paneScrollTarget = 0;
                } else {
                    tab = Category.values()[idx];
                    search = "";
                    searchFocused = false;
                    listScroll = listScrollTarget = 0;
                }
            });
        }
        fade = saved;
        // Particles stay out of the stage.
        Particles.exclX = cx;
        Particles.exclY = feetY - charH * 0.4;
        Particles.exclR = Math.max(pedR * 2.2, charH * 0.9);
    }

    private int countEnabled() {
        int n = 0;
        for (Module m : BlocksClient.modules.all()) if (m.isEnabled() && !m.hiddenInArraylist()) n++;
        return n;
    }

    /** Your full character on the pedestal; body and head turn to face the cursor. */
    private void renderShowcase(Gfx g, int mouseX, int mouseY) {
        double charH = showHeight;
        double perBlock = charH / (1.8 * 0.9375);           // UI units per block (players render at 15/16)
        double boxTop = showFeetY - charH - 10, boxBottom = showFeetY + 4;
        double boxMid = (boxTop + boxBottom) / 2;
        int x1 = (int) ((showFeetX - charH * 0.42) * k), x2 = (int) ((showFeetX + charH * 0.42) * k);
        int y1 = (int) (boxTop * k), y2 = (int) (boxBottom * k);
        int size = (int) Math.round(perBlock * k);
        float yOffset = (float) ((showFeetY - boxMid) / perBlock - 0.9);
        net.minecraft.world.item.ItemStack helmet = mc.player.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD);
        if (!helmet.isEmpty()) mc.player.setItemSlot(net.minecraft.world.entity.EquipmentSlot.HEAD, net.minecraft.world.item.ItemStack.EMPTY);
        com.blocks.module.visuals.Chams.paused = true;
        try {
            g.entityFollowsMouse(x1, y1, x2, y2, size, yOffset, mouseX, mouseY, mc.player);
        } finally {
            com.blocks.module.visuals.Chams.paused = false;
            if (!helmet.isEmpty()) mc.player.setItemSlot(net.minecraft.world.entity.EquipmentSlot.HEAD, helmet);
        }
    }

    /** Small glass cubes drifting upward behind the hub. */
    private void facetFloaters(double ax, double aw, double cx, double cy, double keepOut, double time, Theme.Palette pal) {
        int glassC = glass(pal, 255);
        for (int i = 0; i < 10; i++) {
            long seed = i * 2654435761L;
            double fx = ax + 20 + ((seed >>> 8) % 1000) / 1000.0 * (aw - 40);
            double speed = 6 + ((seed >>> 18) % 100) / 10.0;
            double fy = H + 20 - ((time * speed + ((seed >>> 28) % 1000)) % (H + 40));
            double fr = 5 + (seed >>> 38) % 7;
            if (Math.hypot(fx - cx, fy - cy) < keepOut) continue;
            double alpha = 0.35 + 0.25 * Math.sin(time * 0.8 + i);
            Shapes.isoCube(fx, fy, fr,
                    a(Theme.withAlpha(Theme.blend(glassC, 0xFFFFFFFF, 0.25), (int) (150 * alpha))),
                    a(Theme.withAlpha(Theme.blend(glassC, pal.accent(), 0.3), (int) (140 * alpha))),
                    a(Theme.withAlpha(Theme.blend(glassC, 0xFF000000, 0.2), (int) (130 * alpha))),
                    a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.5), (int) (120 * alpha))));
        }
    }

    // ------------------------------------------------------------------ Facet panel

    private static final double FROW = 25, FGAP = 4;

    private void renderFacetPanel(Gfx g, double dt, Theme.Palette pal) {
        double x = dockX, y = dockY, w = dockW, h = dockH;
        long now = System.currentTimeMillis();
        Shapes.facetPanel(x, y, w, h, 12, 18, 0, Shapes.Layer.FILL, a(glass(pal, (int) (95 * gui.panelOpacity.get() / 100.0))));
        Shapes.facetPanel(x, y, w, h, 12, 18, 0, Shapes.Layer.STROKE, a(Theme.withAlpha(0xFFFFFFFF, 16)));
        hit(x, y, w, h, b -> {});
        boolean searching = !search.isEmpty();
        List<Module> mods = listModules();

        // Header: a little lit cube, the category and a count.
        double hy = y + 20;
        Shapes.isoCube(x + 22, hy, 8.5, a(Theme.withAlpha(pal.accent2(), 235)), a(Theme.withAlpha(pal.accent(), 235)),
                a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFF000000, 0.35), 235)), a(Theme.withAlpha(0xFFFFFFFF, 140)));
        var pose = g.pose();
        pose.pushMatrix();
        pose.translate((float) (x + 37), (float) (hy - 6));
        pose.scale(1.18f, 1.18f);
        g.textBold(searching ? "Search" : tab.title, 0, 0, a(Theme.TEXT), false);
        pose.popMatrix();
        String cnt = mods.size() + " modules";
        g.textScaled(cnt, x + w - 12 - g.widthScaled(cnt, 0.7f), hy - 2.5, a(Theme.TEXT_FAINT), 0.7f);

        // Search pill.
        double sx = x + 12, sy = y + 38, sw = w - 24, sh = 18;
        boolean hovSearch = over(sx, sy, sw, sh);
        Shapes.roundRect(sx, sy, sw, sh, 9, a(Theme.withAlpha(0xFFFFFF, searchFocused ? 22 : hovSearch ? 14 : 8)));
        if (searchFocused) Shapes.roundOutline(sx, sy, sw, sh, 9, 1, a(Theme.withAlpha(pal.accent(), 200)));
        Shapes.icon("search", sx + 11, sy + sh / 2, 7, a(searchFocused ? Theme.TEXT : Theme.TEXT_FAINT));
        if (search.isEmpty() && !searchFocused) g.textScaled("Search, or just type", sx + 21, sy + 5.5, a(Theme.TEXT_FAINT), 0.88f);
        else g.textScaled(trim(g, search, (sw - 40) / 0.88) + caret(searchFocused), sx + 21, sy + 5.5, a(Theme.TEXT), 0.88f);
        if (!search.isEmpty()) {
            double ccx = sx + sw - 10;
            Shapes.icon("close", ccx, sy + sh / 2, 6, a(over(ccx - 7, sy + 2, 14, 14) ? Theme.TEXT : Theme.TEXT_FAINT));
            hit(ccx - 7, sy + 2, 14, 14, b -> {
                search = "";
                searchFocused = false;
                listScroll = listScrollTarget = 0;
            });
        }
        hit(sx, sy, sw, sh, b -> {
            searchFocused = true;
            profileFocused = false;
        });

        // Category hexagons (only without the hub).
        double top = sy + sh + 12;
        if (!hubVisible) {
            Category[] cats = Category.values();
            double tw = (w - 24) / cats.length;
            for (int i = 0; i < cats.length; i++) {
                Category c = cats[i];
                double ccx = x + 12 + tw * i + tw / 2, ccy = top + 13;
                boolean active = !searching && tab == c;
                boolean hov = Math.hypot(mx - ccx, my - ccy) < 13;
                double t = anim("dtab/" + c, active ? 1 : 0, dt);
                Shapes.hex(ccx, ccy, 12, 2, 0, Shapes.Layer.FILL, a(Theme.withAlpha(Theme.blend(0xFFFFFFFF, pal.accent(), t), (int) (14 + 150 * t + (hov ? 14 : 0)))));
                Shapes.hex(ccx, ccy, 12, 2, 0, Shapes.Layer.STROKE, a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.5), (int) (40 + 180 * t))));
                g.itemIcon(c.icon(), ccx, ccy, 10, Shapes.scale());
                if (hov) hoverText = c.title;
                final Category cat = c;
                hit(ccx - 12, ccy - 12, 24, 24, b -> {
                    tab = cat;
                    search = "";
                    searchFocused = false;
                    listScroll = listScrollTarget = 0;
                });
            }
            top += 32;
        }

        // Rows.
        double bottom = y + h - 40;
        double lx = x + 14, lw = w - 24;
        double content = mods.size() * (FROW + FGAP) - FGAP;
        listScrollTarget = Math.max(0, Math.min(listScrollTarget, content - (bottom - top)));
        listScroll += (listScrollTarget - listScroll) * (gui.animations.get() ? 1 - Math.exp(-dt * 16) : 1);
        hoverModule = null;
        rowAnchorX = -1;
        double view = bottom - top;
        // Spine: a thin line with a glowing bead for the scroll position.
        Shapes.roundRect(x + 7, top, 1, view, 0.5, a(0x1CFFFFFF));
        double beadY = content > view ? top + view * (listScroll / (content - view)) : top;
        if (content > view) {
            if (glowOn()) Shapes.circleGlow(x + 7.5, beadY, 2, 6, a(Theme.withAlpha(pal.accent(), 120)));
            Shapes.hex(x + 7.5, beadY, 3, 0.5, 0, Shapes.Layer.FILL, a(pal.accent2()));
        }
        g.scissor((int) x, (int) top - 4, (int) (x + w), (int) bottom + 4);
        for (int i = 0; i < mods.size(); i++) {
            double ry = top - listScroll + i * (FROW + FGAP);
            if (ry + FROW < top - 4 || ry > bottom + 4) continue;
            double e = gui.animations.get() ? ease((now - openTime - i * 22) / 260.0) : 1;
            double saved = fade;
            fade *= e;
            facetRow(g, mods.get(i), lx - 14 * (1 - e), ry, lw, top, bottom, dt, pal);
            fade = saved;
        }
        g.noScissor();
        if (mods.isEmpty()) g.textScaled("Nothing matches \"" + search + "\"", lx + 4, top + 6, a(Theme.TEXT_DIM), SMALL);

        // Footer: wordmark, hint, hub and preferences buttons.
        double by = y + h - 18;
        g.itemIcon(GRASS.get(), x + 17, by - 5, 9, Shapes.scale());
        g.textScaled("Blocks Client", x + 25, by - 8.5, a(Theme.TEXT_DIM), 0.82f);
        g.textScaled("Click the hexagon to toggle", x + 12, by + 3, a(Theme.TEXT_FAINT), 0.6f);
        double gx = x + w - 18;
        boolean hovGear = Math.hypot(mx - gx, my - by) < 9;
        Shapes.hex(gx, by, 9, 1.5, 0, Shapes.Layer.FILL, a(dockPrefs ? Theme.withAlpha(pal.accent(), 230) : Theme.withAlpha(0xFFFFFF, hovGear ? 30 : 12)));
        Shapes.icon("gear", gx, by, 9, a(dockPrefs ? Theme.TEXT_ON_ACCENT : hovGear ? Theme.TEXT : Theme.TEXT_DIM));
        hit(gx - 9, by - 9, 18, 18, b -> {
            dockPrefs = !dockPrefs;
            if (dockPrefs) expanded = null;
            paneScroll = paneScrollTarget = 0;
        });
        if (hovGear) hoverText = "Preferences";
        double hbx = gx - 21;
        boolean hovHub = Math.hypot(mx - hbx, my - by) < 9;
        Shapes.hex(hbx, by, 9, 1.5, 0, Shapes.Layer.FILL, a(Theme.withAlpha(0xFFFFFF, hovHub ? 30 : 12)));
        Shapes.icon("grid", hbx, by, 9, a(hubShown() ? pal.accent2() : hovHub ? Theme.TEXT : Theme.TEXT_DIM));
        hit(hbx - 9, by - 9, 18, 18, b -> gui.menuStyle.set(hubShown() ? "Panel Only" : "Hub + Panel"));
        if (hovHub) hoverText = hubShown() ? "Hide the hub" : "Show the hub";
    }

    private void facetRow(Gfx g, Module m, double x, double y, double w, double top, double bottom, double dt, Theme.Palette pal) {
        boolean hov = over(x, y, w, FROW) && my >= top && my <= bottom;
        if (hov) hoverModule = m;
        boolean open = m == expanded;
        double on = anim(m, m.isEnabled() ? 1 : 0, dt);
        double hv = anim("hov/" + m.getName(), hov ? 1 : 0, dt);
        double sel = anim("sel/" + m.getName(), open ? 1 : 0, dt);
        double cy = y + FROW / 2;
        if (open) {
            rowAnchorX = x + w;
            rowAnchorY = cy;
        }
        // Soft pill only on hover / when open; a light sweep crosses it while hovered.
        int bgA = (int) (16 * hv + 22 * sel);
        if (bgA > 0) Shapes.roundRect(x, y, w, FROW, FROW / 2, a(Theme.withAlpha(Theme.blend(0xFFFFFFFF, pal.accent(), 0.25 * sel), bgA)));
        if (sel > 0.01) Shapes.roundOutline(x, y, w, FROW, FROW / 2, 1, a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.35), (int) (190 * sel))));
        if (hv > 0.05 && gui.animations.get()) {
            double p = (System.currentTimeMillis() % 1400) / 1400.0;
            double sx = x - 30 + (w + 60) * p;
            g.scissor((int) x, (int) Math.max(top - 4, y), (int) (x + w), (int) Math.min(bottom + 4, y + FROW));
            Shapes.gradientRoundRect(sx - 18, y, 18, FROW, 0, 0, a(Theme.withAlpha(0xFFFFFFFF, (int) (22 * hv))));
            Shapes.gradientRoundRect(sx, y, 18, FROW, 0, a(Theme.withAlpha(0xFFFFFFFF, (int) (22 * hv))), 0);
            g.noScissor();
        }
        // Hexagon badge: lit when on; click it to toggle.
        double bx = x + 13;
        boolean hovBadge = Math.hypot(mx - bx, my - cy) < 8 && my >= top && my <= bottom;
        if (glowOn() && on > 0.01) Shapes.hex(bx, cy, 6.2, 1, 7, Shapes.Layer.GLOW, a(Theme.withAlpha(pal.accent(), (int) (150 * on))));
        Shapes.hex(bx, cy, 6.2, 1, 0, Shapes.Layer.FILL, a(Theme.blend(Theme.withAlpha(0xFFFFFFFF, hovBadge ? 46 : 18), Theme.withAlpha(pal.accent(), 255), on)));
        Shapes.hex(bx, cy, 6.2, 1, 0, Shapes.Layer.STROKE, a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.45), (int) (80 + 160 * Math.max(on, hovBadge ? 1 : 0)))));
        if (on > 0.01) Shapes.hex(bx, cy, 2.3, 0.5, 0, Shapes.Layer.FILL, a(Theme.withAlpha(0xFFFFFFFF, (int) (235 * on))));
        int fg = Theme.blend(Theme.TEXT_FAINT, Theme.TEXT, Math.max(on, Math.max(hv * 0.7, sel)));
        double right = x + w - 9;
        double chipW = 0;
        String key = binding == m ? "PRESS KEY" : m.getKey() > 0 ? Compat.keyName(m.getKey()) : null;
        if (key != null) {
            if (key.length() > 6) key = key.substring(0, 6);
            chipW = g.widthMono(key, 0.62f) + 10;
            double kx = right - 10 - chipW;
            Shapes.roundRect(kx, cy - 6, chipW, 12, 6, a(binding == m ? Theme.withAlpha(pal.accent(), 220) : Theme.withAlpha(0xFFFFFF, 18)));
            g.textMono(key, kx + 5, cy - 2.4, a(binding == m ? Theme.TEXT_ON_ACCENT : Theme.TEXT_DIM), 0.62f);
            chipW += 6;
        }
        double nameMax = w - 26 - 18 - chipW - (m.isFavorite() ? 10 : 0);
        g.text(trim(g, m.getName(), nameMax), (int) (x + 25), (int) (cy - 4), a(fg), false);
        if (m.isFavorite()) Shapes.icon("star_filled", x + 25 + Math.min(nameMax, g.width(m.getName())) + 7, cy, 7, a(pal.accent2()));
        Shapes.icon("chevron_right", right - 2, cy, 6.5, a(Theme.withAlpha(Theme.TEXT, (int) (40 + 170 * Math.max(hv, sel)))));

        clippedHit(x, y, w, FROW, top, bottom, b -> {
            boolean onBadge = mx <= x + 23;
            if (b == 1 || (b == 0 && onBadge)) {
                m.toggle();
            } else if (b == 0) {
                expanded = expanded == m ? null : m;
                dockPrefs = false;
                paneScroll = paneScrollTarget = 0;
            } else if (b == 2) {
                binding = m;
            }
        });
    }

    // ------------------------------------------------------------------ Facet card

    private void renderFacetCard(Gfx g, double dt, Theme.Palette pal) {
        long now = System.currentTimeMillis();
        double e = gui.animations.get() ? ease((now - cardOpenAt) / 240.0) : 1;
        double saved = fade;
        fade *= e;
        double slideX = -10 * (1 - e);
        cardX += slideX;
        int opa = (int) (255 * gui.panelOpacity.get() / 100.0);
        Module m = expanded;
        double x = cardX, w = cardW;
        if (dockPrefs) {
            cardY = dockY;
            cardH = Math.min(dockH, 440);
            facetShell(x, cardY, w, cardH, pal, opa);
            insX = x;
            insY = cardY;
            insW = w;
            insH = cardH;
            renderPreferences(g, dt, pal);
            closeButton(g, x + w - 17, cardY + 17, () -> dockPrefs = false);
            fade = saved;
            return;
        }
        double inner = w - 40;
        List<String> desc = wrap(g, m.getDescription(), (w - 28) / SMALL, 3);
        double headH = 32 + desc.size() * 9 + 8;
        double body = 0;
        for (Setting st : m.getSettings()) if (st.isVisible()) body += rowHeight(g, st, inner);
        if (m instanceof com.blocks.module.world.AutoBuilder ab) body += 12 + builderSection(g, ab, 0, 0, inner, false, 0, 0, pal);
        if (m instanceof com.blocks.module.world.AutoMine am) body += 12 + mineSection(g, am, 0, 0, inner, false, 0, 0, pal);
        if (body == 0) body = 16;
        body += 12;
        double footH = 34;
        cardH = Math.min(dockH, headH + body + 8 + footH);
        cardY = Math.max(dockY, Math.min(dockY + 26, dockY + dockH - cardH));
        double y = cardY, h = cardH;

        // Connector: a glowing curve from the open row into the card, with a bead flowing along it.
        if (rowAnchorX > 0) {
            double x0 = rowAnchorX + 2, y0 = rowAnchorY, x1 = x - 1, y1 = y + 22;
            double px0 = x0, py0 = y0;
            int col = a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.3), 150));
            for (int i = 1; i <= 24; i++) {
                double t = i / 24.0, u = 1 - t;
                double bx = u * u * u * x0 + 3 * u * u * t * (x0 + 18) + 3 * u * t * t * (x1 - 18) + t * t * t * x1;
                double by = u * u * u * y0 + 3 * u * u * t * y0 + 3 * u * t * t * y1 + t * t * t * y1;
                Shapes.line(px0, py0, bx, by, 1.1, col);
                px0 = bx;
                py0 = by;
            }
            if (gui.animations.get()) {
                double t = (now % 1300) / 1300.0, u = 1 - t;
                double bx = u * u * u * x0 + 3 * u * u * t * (x0 + 18) + 3 * u * t * t * (x1 - 18) + t * t * t * x1;
                double by = u * u * u * y0 + 3 * u * u * t * y0 + 3 * u * t * t * y1 + t * t * t * y1;
                if (glowOn()) Shapes.circleGlow(bx, by, 1.5, 5, a(Theme.withAlpha(pal.accent2(), 160)));
                Shapes.hex(bx, by, 2.4, 0.4, 0, Shapes.Layer.FILL, a(0xFFFFFFFF));
            }
        }

        facetShell(x, y, w, h, pal, opa);

        // Header: lit hexagon, name, favourite, switch, close.
        double hx = x + 16;
        boolean onNow = m.isEnabled();
        double hexX = x + 22, hexY = y + 19;
        if (glowOn() && onNow) Shapes.hex(hexX, hexY, 8, 1.4, 8, Shapes.Layer.GLOW, a(Theme.withAlpha(pal.accent(), 140)));
        Shapes.hex(hexX, hexY, 8, 1.4, 0, Shapes.Layer.FILL, a(onNow ? pal.accent() : Theme.withAlpha(0xFFFFFFFF, 20)));
        Shapes.hex(hexX, hexY, 8, 1.4, 0, Shapes.Layer.STROKE, a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.45), 220)));
        if (onNow) Shapes.hex(hexX, hexY, 3, 0.6, 0, Shapes.Layer.FILL, a(0xFFFFFFFF));
        g.textBold(trim(g, m.getName(), w - 120), (int) (x + 36), (int) (y + 15), a(Theme.TEXT), false);
        closeButton(g, x + w - 17, y + 19, () -> expanded = null);
        toggleSwitch(x + w - 56, y + 14, m.isEnabled(), "card/" + m.getName(), dt);
        hit(x + w - 60, y + 10, 28, 18, b -> m.toggle());
        boolean hovStar = over(x + w - 80, y + 11, 16, 16);
        Shapes.icon(m.isFavorite() ? "star_filled" : "star", x + w - 72, y + 19, 9, a(m.isFavorite() ? pal.accent2() : hovStar ? Theme.TEXT : Theme.TEXT_FAINT));
        hit(x + w - 80, y + 11, 16, 16, b -> m.setFavorite(!m.isFavorite()));
        if (hovStar) hoverText = m.isFavorite() ? "Unfavourite" : "Favourite";
        double dy = y + 31;
        for (String line : desc) {
            g.textScaled(line, hx, dy, a(Theme.TEXT_FAINT), SMALL);
            dy += 9;
        }
        dy += 6;

        // Body: settings in a soft inset, scrollable.
        double gx = x + 8, gw = w - 16, gTop = dy, gBottom = y + h - footH - 6;
        Shapes.roundRect(gx, gTop, gw, gBottom - gTop, 12, a(0x0AFFFFFF));
        double clipTop = gTop + 2, clipBottom = gBottom - 2;
        double view = clipBottom - clipTop;
        paneScrollTarget = Math.max(0, Math.min(paneScrollTarget, body - view));
        paneScroll += (paneScrollTarget - paneScroll) * (gui.animations.get() ? 1 - Math.exp(-dt * 16) : 1);
        g.scissor((int) gx, (int) clipTop, (int) (gx + gw), (int) clipBottom);
        double sx = gx + 12, ry = gTop + 6 - paneScroll;
        boolean any = false;
        for (Setting st : m.getSettings()) {
            if (!st.isVisible()) continue;
            any = true;
            double rh = rowHeight(g, st, inner);
            if (ry + rh >= clipTop && ry <= clipBottom) renderSettingRow(g, st, sx, ry, inner, rh, clipTop, clipBottom, dt, pal);
            ry += rh;
        }
        if (m instanceof com.blocks.module.world.AutoBuilder ab) {
            ry += 12;
            ry += builderSection(g, ab, sx, ry, inner, true, clipTop, clipBottom, pal);
        }
        if (m instanceof com.blocks.module.world.AutoMine am) {
            ry += 12;
            ry += mineSection(g, am, sx, ry, inner, true, clipTop, clipBottom, pal);
        }
        if (!any && !(m instanceof com.blocks.module.world.AutoBuilder)) g.textScaled("No settings. Toggle and go.", sx, gTop + 8, a(Theme.TEXT_FAINT), SMALL);
        g.noScissor();
        if (body > view) {
            double barH = Math.max(14, view * view / body);
            double barY = clipTop + (view - barH) * (paneScroll / (body - view));
            Shapes.roundRect(gx + gw - 4, barY, 2, barH, 1, a(Theme.withAlpha(pal.accent(), 160)));
        }

        // Footer: keybind pill.
        double fy = y + h - footH;
        double fh = footH - 8, fcy = fy + fh / 2;
        Shapes.roundRect(gx, fy, gw, fh, fh / 2, a(0x0CFFFFFF));
        boolean listening = binding == m;
        String key = listening ? "PRESS KEY" : m.getKey() > 0 ? Compat.keyName(m.getKey()).toUpperCase() : "None";
        double kw = g.widthMono(key, 0.72f) + 14;
        g.text("Keybind", (int) (gx + 12), (int) (fcy - 4), a(Theme.TEXT), false);
        String tip = listening ? "Esc clears" : "click to rebind";
        g.textScaled(tip, gx + gw - 10 - kw - 6 - g.widthScaled(tip, 0.66f), fcy - 2.5, a(Theme.TEXT_FAINT), 0.66f);
        boolean hovKey = over(gx + gw - 10 - kw, fcy - 7, kw, 14);
        Shapes.roundRect(gx + gw - 10 - kw, fcy - 7, kw, 14, 7, a(listening ? Theme.withAlpha(pal.accent(), 235) : Theme.withAlpha(0xFFFFFF, hovKey ? 34 : 18)));
        g.textMono(key, gx + gw - 10 - kw + 7, fcy - 2.8, a(listening ? Theme.TEXT_ON_ACCENT : Theme.TEXT), 0.72f);
        hit(gx, fy, gw, fh, b -> binding = listening ? null : m);
        fade = saved;
    }

    /** The gem-cut card: soft shadow, accent glow, glass fill with a sheen, bright rim. */
    private void facetShell(double x, double y, double w, double h, Theme.Palette pal, int opa) {
        Shapes.glow(x, y + 5, w, h, 14, 18, a(0x50000000));
        if (glowOn()) Shapes.facetPanel(x, y, w, h, 12, 18, 14, Shapes.Layer.GLOW, a(Theme.withAlpha(pal.accent(), 80)));
        Shapes.facetPanel(x, y, w, h, 12, 18, 0, Shapes.Layer.FILL, a(Theme.withAlpha(Theme.blend(glass(pal, 255), pal.accent(), 0.08), opa)));
        Shapes.facetPanel(x, y, w, h, 12, 18, 0, Shapes.Layer.SHEEN, a(Theme.withAlpha(0xFFFFFFFF, 22)));
        Shapes.facetPanel(x, y, w, h, 12, 18, 0, Shapes.Layer.STROKE, a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.35), 215)));
        hit(x, y, w, h, b -> {});
    }

    /** Opens a folder in the system file browser (works on every version). */
    private static void openFolder(java.nio.file.Path dir) {
        try {
            java.nio.file.Files.createDirectories(dir);
            String os = System.getProperty("os.name", "").toLowerCase(java.util.Locale.ROOT);
            String[] cmd = os.contains("win") ? new String[]{"explorer", dir.toAbsolutePath().toString()}
                    : os.contains("mac") ? new String[]{"open", dir.toAbsolutePath().toString()}
                    : new String[]{"xdg-open", dir.toAbsolutePath().toString()};
            new ProcessBuilder(cmd).start();
        } catch (Exception e) {
            com.blocks.util.Notifications.push("Schematics folder", dir.toAbsolutePath().toString(), false);
        }
    }

    private void closeButton(Gfx g, double cx, double cy, Runnable action) {
        boolean hov = over(cx - 8, cy - 8, 16, 16);
        Shapes.circle(cx, cy, 8, a(Theme.withAlpha(0xFFFFFF, hov ? 34 : 14)));
        Shapes.icon("close", cx, cy, 6.5, a(hov ? Theme.TEXT : Theme.TEXT_DIM));
        hit(cx - 8, cy - 8, 16, 16, b -> action.run());
    }

    // ------------------------------------------------------------------ auto mine region panel

    private double mineSection(Gfx g, com.blocks.module.world.AutoMine m, double x, double y, double w,
                               boolean draw, double clipTop, double clipBottom, Theme.Palette pal) {
        double y0 = y;
        if (draw) label(g, "REGION", x, y, Theme.TEXT_FAINT);
        y += 11;
        if (draw) {
            double bx = pill(g, "Corner 2", x + w, y, m.corner2 != null, clipTop, clipBottom, m::setCorner2);
            pill(g, "Corner 1", bx - 5, y, m.corner1 != null, clipTop, clipBottom, m::setCorner1);
            g.textScaled("Look at a block, then", x, y + 3.5, a(Theme.TEXT_FAINT), 0.78f);
        }
        y += 18;
        if (draw) g.textMono(m.regionText(), x, y + 2, a(pal.accent2()), 0.72f);
        y += 12;
        if (draw && (m.corner1 != null || m.corner2 != null)) pill(g, "Clear corners", x + w, y, false, clipTop, clipBottom, m::clearCorners);
        y += 18;
        return y - y0;
    }

    // ================================================================== hub

    private void renderHub(Gfx g, double dt) {
        Theme.Palette pal = Theme.current();
        double cx = W / 2, cy = H * 0.56;
        double r0 = 58, r1 = 162, ha = Math.toRadians(12), rc = 12, mid = (r0 + r1) / 2 + 8;
        hubCx = cx;
        hubHy = cy + 22;

        // Rays
        for (HubRay r : RAYS) {
            double dx = mx - cx, dy = my - cy, rho = Math.hypot(dx, dy);
            double dphi = Math.atan2(Math.sin(Math.atan2(dy, dx) - r.angle), Math.cos(Math.atan2(dy, dx) - r.angle));
            boolean hov = rho >= r0 && rho <= r1 + 8 && Math.abs(dphi) <= ha + 0.02;
            double h = anim(r, hov ? 1 : 0, dt);
            double push = 9 * h;
            double px = cx + Math.cos(r.angle) * push, py = cy + Math.sin(r.angle) * push;
            if (glowOn()) Shapes.ray(px, py, r.angle, ha, r0, r1, rc, 14, Shapes.Layer.GLOW,
                    a(Theme.withAlpha(pal.accent(), (int) (40 + 140 * h))));
            Shapes.ray(px, py, r.angle, ha, r0, r1, rc, 14, Shapes.Layer.FILL,
                    a(Theme.withAlpha(Theme.blend(glass(pal, 255), pal.accent(), 0.2 + 0.5 * h), (int) (150 + 70 * h))));
            Shapes.ray(px, py, r.angle, ha, r0, r1, rc, 14, Shapes.Layer.STROKE,
                    a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.45), (int) (90 + 150 * h))));
            double ix = px + Math.cos(r.angle) * mid, iy = py + Math.sin(r.angle) * mid;
            g.itemIcon(r.icon(), ix, iy - 7, 20 + 4 * h, Shapes.scale());
            g.textCentered(r.label, (int) ix, (int) iy + 8, a(h > 0.5 ? Theme.TEXT : Theme.TEXT_DIM), false);
            if (r.category != null) {
                String n = BlocksClient.modules.inCategory(r.category).size() + "";
                g.textMono(n, ix - g.widthMono(n, 0.7f) / 2, iy + 19, a(Theme.withAlpha(Theme.TEXT_FAINT, (int) (150 + 100 * h))), 0.7f);
            }
            final HubRay ray = r;
            frameHits.add(new Hit((hx, hy) -> {
                double ddx = hx - cx, ddy = hy - cy, rr = Math.hypot(ddx, ddy);
                double dp = Math.atan2(Math.sin(Math.atan2(ddy, ddx) - ray.angle), Math.cos(Math.atan2(ddy, ddx) - ray.angle));
                return rr >= r0 && rr <= r1 + 8 && Math.abs(dp) <= ha + 0.02;
            }, b -> {
                if (ray.category != null) {
                    tab = ray.category;
                    pane = Pane.MODULE;
                    if (selected != null && selected.getCategory() != tab) selected = null;
                } else {
                    pane = Pane.SETTINGS;
                }
                listScroll = listScrollTarget = paneScroll = paneScrollTarget = 0;
                switchView(View.MENU);
            }, null));
        }

        // The sun sits on the horizon behind you.
        double hy = hubHy, hw = 260;
        double breathe = gui.animations.get() ? 0.85 + 0.15 * Math.sin(System.currentTimeMillis() / 900.0) : 1;
        double sr = 40, scy = hy - 6;
        if (glowOn()) {
            Shapes.circleGlow(cx, scy, sr, 30, a(Theme.withAlpha(pal.accent2(), (int) (110 * breathe))));
            Shapes.circleGlow(cx, scy, sr, 70, a(Theme.withAlpha(pal.accent(), (int) (40 * breathe))));
        }
        g.scissor((int) (cx - sr - 90), (int) (scy - sr - 90), (int) (cx + sr + 90), (int) hy);
        Shapes.circle(cx, scy, sr, a(pal.accent2()));
        Shapes.circle(cx, scy + 6, sr - 5, a(Theme.withAlpha(Theme.blend(pal.accent2(), pal.accent(), 0.7), 210)));
        g.noScissor();

        // Horizon, fading out at both ends.
        for (int i = -24; i < 24; i++) {
            double t = Math.abs((i + 0.5) / 24.0);
            Shapes.rect(cx + i * hw / 24, hy, hw / 24 + 0.2, 0.7, a(Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.5), (int) (150 * (1 - t * t)))));
        }
        // Reflection: calm, shimmering lines under the horizon.
        double[] widths = {130, 88, 48};
        for (int i = 0; i < widths.length; i++) {
            double t = gui.animations.get() ? System.currentTimeMillis() / 1800.0 + i * 1.7 : i;
            double wob = Math.sin(t) * 5;
            Shapes.wave(cx - widths[i] / 2 + wob, hy + 8 + i * 6, widths[i], 0.8, 16, 0.8,
                    a(Theme.withAlpha(pal.accent2(), 130 - i * 35)));
        }

        // Name and profile
        String name = mc.player.getName().getString();
        double ny = hy + 30;
        g.textBold(name, (int) (cx - g.widthBold(name) / 2.0), (int) ny, a(Theme.TEXT), false);

        // Search capsule
        double sw2 = 210, sh = 22, sx = cx - sw2 / 2, sy = ny + 18;
        boolean hovSearch = over(sx, sy, sw2, sh);
        Shapes.roundRect(sx, sy, sw2, sh, 11, a(glass(pal, hovSearch ? 235 : 215)));
        Shapes.roundOutline(sx, sy, sw2, sh, 11, 1, a(hovSearch ? Theme.withAlpha(pal.accent(), 180) : 0x1EFFFFFF));
        Shapes.icon("search", sx + 13, sy + sh / 2, 8, a(Theme.TEXT_FAINT));
        g.text("Search modules and settings", (int) sx + 24, (int) (sy + sh / 2 - 4), a(Theme.TEXT_FAINT), false);
        hit(sx, sy, sw2, sh, b -> {
            switchView(View.MENU);
            searchFocused = true;
        });

        // Profile capsules
        List<String> chips = profileCycle();
        double total = 0;
        for (String c : chips) total += g.width(c) + 22 + 6;
        total -= 6;
        double x = cx - total / 2, y = sy + sh + 10;
        for (String c : chips) {
            boolean active = c.equals(Config.active());
            double cw = g.width(c) + 22;
            boolean hov = over(x, y, cw, 18);
            double t = anim("chip/" + c, active ? 1 : 0, dt);
            Shapes.roundRect(x, y, cw, 18, 9, a(Theme.blend(Theme.withAlpha(0xFFFFFF, hov ? 22 : 10), Theme.withAlpha(pal.accent(), 220), t)));
            g.text(c, (int) (x + 11), (int) y + 5, a(Theme.blend(hov ? Theme.TEXT : Theme.TEXT_DIM, Theme.TEXT_ON_ACCENT, t)), false);
            final String name2 = c;
            hit(x, y, cw, 18, b -> {
                if (!name2.equals(Config.active())) Config.switchTo(name2);
            });
            x += cw + 6;
        }
    }

    private double hubCx, hubHy;

    /** Your whole character standing in the sun, head following the cursor. Drawn in GUI units. */
    private void renderPaperdoll(Gfx g, int mouseX, int mouseY) {
        double hBox = 88, wBox = 54;
        int x1 = (int) ((hubCx - wBox / 2) * k), x2 = (int) ((hubCx + wBox / 2) * k);
        int y1 = (int) ((hubHy - hBox) * k), y2 = (int) (hubHy * k);
        int size = (int) Math.round(hBox * 0.5 * k);
        g.entityFollowsMouse(x1, y1, x2, y2, size, 0.0625f, mouseX, mouseY, mc.player);
    }

    /** Small readouts in the screen corners. */
    private void renderHubCorners(Gfx g) {
        Theme.Palette pal = Theme.current();
        double m = 16;
        Shapes.icon("sun", m + 5, m + 4, 11, a(pal.accent2()));
        g.gradientText("blocks", (int) (m + 14), (int) m, a(pal.accent2()), a(pal.accent()), true);

        LocalTime time = LocalTime.now();
        int ping = 0;
        if (mc.getConnection() != null) {
            var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
            if (info != null) ping = info.getLatency();
        }
        String right = String.format("%02d:%02d   %d fps   %d ms", time.getHour(), time.getMinute(), mc.getFps(), ping);
        g.textMono(right, W - m - g.widthMono(right, 0.8f), m + 0.6, a(Theme.TEXT_DIM), 0.8f);
        String hint = "type to search   esc to close";
        g.textScaled(hint, W / 2 - g.widthScaled(hint, SMALL) / 2, H - m - 6, a(Theme.TEXT_FAINT), SMALL);
    }

    // ================================================================== menu sheet

    private static final double SHEET_W = 540, SHEET_H = 320, R_SHEET = 18, HEADER = 84, FOOT = 30;
    private static final double CAP_H = 24, CAP_GAP = 6;

    private void renderSheet(Gfx g, double dt) {
        Theme.Palette pal = Theme.current();
        ww = Math.min(SHEET_W, W - 24);
        wh = Math.min(SHEET_H, H - 24);
        wx = Math.round((W - ww) / 2);
        wy = Math.round((H - wh) / 2);

        Shapes.glow(wx, wy + 8, ww, wh, R_SHEET, 30, a(0x90000000));
        if (glowOn()) Shapes.glow(wx, wy, ww, wh, R_SHEET, 16, a(Theme.withAlpha(pal.accent(), 40)));
        Shapes.roundRect(wx, wy, ww, wh, R_SHEET, a(glass(pal, 236)));
        g.scissor((int) wx, (int) wy, (int) (wx + ww), (int) (wy + wh));
        Shapes.circleGlow(wx + ww - 80, wy - 30, 1, 190, a(Theme.withAlpha(pal.accent(), 46)));
        Shapes.circleGlow(wx + 60, wy + wh + 50, 1, 170, a(Theme.withAlpha(pal.accent2(), 18)));
        g.noScissor();
        Shapes.roundOutline(wx, wy, ww, wh, R_SHEET, 1, a(0x2AFFFFFF));
        hit(wx, wy, ww, wh, b -> {});

        insW = Math.round(ww * 0.4);
        insX = wx + ww - 16 - insW;
        insY = wy + HEADER;
        insH = wh - HEADER - FOOT - 4;
        listX = wx + 18;
        listW = insX - 14 - listX;
        listY = insY;
        listH = insH;

        renderSheetHeader(g, dt, pal);
        renderCapsules(g, dt, pal);
        renderInspector(g, dt, pal);
        renderSheetFooter(g, pal);
        renderPicker(g, dt, pal);

        if (gui.particles.get() || glowOn()) {
            g.scissor((int) wx, (int) wy, (int) (wx + ww), (int) (wy + wh));
            Shapes.grain(wx, wy, ww, wh, a(0x0AFFFFFF));
            g.noScissor();
        }
    }

    private void renderSheetHeader(Gfx g, double dt, Theme.Palette pal) {
        boolean searching = !search.isEmpty() || searchFocused;
        boolean prefs = pane == Pane.SETTINGS && !searching;
        String icon = prefs ? "gear" : "search";
        String title = prefs ? "Preferences" : searching ? "Search" : tab.title;

        double ix = wx + 34, iy = wy + 32;
        if (glowOn()) Shapes.circleGlow(ix, iy, 14, 14, a(Theme.withAlpha(pal.accent(), 90)));
        Shapes.circle(ix, iy, 15, a(Theme.withAlpha(pal.accent(), prefs || searching ? 235 : 60)));
        Shapes.ring(ix, iy, 15, 1, a(Theme.withAlpha(pal.accent(), 200)));
        if (prefs || searching) Shapes.icon(icon, ix, iy, 15, a(Theme.TEXT_ON_ACCENT));
        else g.itemIcon(tab.icon(), ix, iy, 16, Shapes.scale());

        var pose = g.pose();
        pose.pushMatrix();
        pose.translate((float) (ix + 24), (float) (iy - 12));
        pose.scale(1.55f, 1.55f);
        g.textBold(title, 0, 0, a(Theme.TEXT), false);
        pose.popMatrix();
        List<Module> mods = listModules();
        int on = 0;
        for (Module m : mods) if (m.isEnabled()) on++;
        String sub = prefs ? "SYSTEM   THEME " + gui.theme.get().toUpperCase() : mods.size() + " MODULES   " + on + " ACTIVE";
        label(g, sub, ix + 25, iy + 6, Theme.TEXT_FAINT);

        // Right side: search capsule, then home (back to hub).
        double hx = wx + ww - 32, hcy = iy;
        boolean hovHome = over(hx - 13, hcy - 13, 26, 26);
        Shapes.circle(hx, hcy, 13, a(Theme.withAlpha(0xFFFFFF, hovHome ? 28 : 12)));
        Shapes.icon("sun", hx, hcy, 13, a(hovHome ? pal.accent2() : Theme.TEXT_DIM));
        hit(hx - 13, hcy - 13, 26, 26, b -> switchView(View.HUB));
        if (hovHome) hoverText = "Back to hub";

        double sw = 150, sh = 24, sx = hx - 20 - sw, sy = hcy - sh / 2;
        boolean hovSearch = over(sx, sy, sw, sh);
        Shapes.roundRect(sx, sy, sw, sh, 12, a(Theme.withAlpha(0xFFFFFF, searchFocused ? 22 : hovSearch ? 16 : 10)));
        Shapes.roundOutline(sx, sy, sw, sh, 12, 1, a(searchFocused ? Theme.withAlpha(pal.accent(), 200) : 0x16FFFFFF));
        Shapes.icon("search", sx + 13, sy + sh / 2, 8, a(searchFocused ? Theme.TEXT : Theme.TEXT_FAINT));
        if (search.isEmpty() && !searchFocused) g.text("Search", (int) sx + 24, (int) (sy + sh / 2 - 4), a(Theme.TEXT_FAINT), false);
        else g.text(trim(g, search, sw - 34) + caret(searchFocused), (int) sx + 24, (int) (sy + sh / 2 - 4), a(Theme.TEXT), false);
        hit(sx, sy, sw, sh, b -> {
            searchFocused = true;
            profileFocused = false;
        });

        // Category capsules
        double cx = wx + 18, cy = wy + 56;
        for (Category c : Category.values()) {
            boolean active = !searching && pane == Pane.MODULE && tab == c;
            double cw = 12 + 6 + g.width(c.title) + 20;
            boolean hov = over(cx, cy, cw, 18);
            double t = anim("cat/" + c, active ? 1 : 0, dt);
            if (t > 0.01) Shapes.gradientRoundRect(cx, cy, cw, 18, 9, a(Theme.withAlpha(pal.accent(), (int) (240 * t))), a(Theme.withAlpha(pal.accent2(), (int) (150 * t))));
            if (t < 0.99) Shapes.roundRect(cx, cy, cw, 18, 9, a(Theme.withAlpha(0xFFFFFF, (int) ((hov ? 20 : 9) * (1 - t)))));
            int fg = Theme.blend(hov ? Theme.TEXT : Theme.TEXT_DIM, Theme.TEXT_ON_ACCENT, t);
            g.itemIcon(c.icon(), cx + 13, cy + 9, 10, Shapes.scale());
            g.text(c.title, (int) (cx + 10 + 12), (int) cy + 5, a(fg), false);
            final Category cat = c;
            hit(cx, cy, cw, 18, b -> {
                tab = cat;
                pane = Pane.MODULE;
                search = "";
                searchFocused = false;
                listScroll = listScrollTarget = 0;
                if (selected != null && selected.getCategory() != cat) selected = null;
            });
            cx += cw + 6;
        }
        // Preferences capsule at the end of the row.
        boolean pActive = prefs;
        double pw = 12 + 6 + g.width("Preferences") + 20;
        boolean hovP = over(cx, cy, pw, 18);
        double pt = anim("cat/prefs", pActive ? 1 : 0, dt);
        if (pt > 0.01) Shapes.gradientRoundRect(cx, cy, pw, 18, 9, a(Theme.withAlpha(pal.accent(), (int) (240 * pt))), a(Theme.withAlpha(pal.accent2(), (int) (150 * pt))));
        if (pt < 0.99) Shapes.roundRect(cx, cy, pw, 18, 9, a(Theme.withAlpha(0xFFFFFF, (int) ((hovP ? 20 : 9) * (1 - pt)))));
        int pfg = Theme.blend(hovP ? Theme.TEXT : Theme.TEXT_DIM, Theme.TEXT_ON_ACCENT, pt);
        g.itemIcon(CLOCK.get(), cx + 13, cy + 9, 10, Shapes.scale());
        g.text("Preferences", (int) (cx + 22), (int) cy + 5, a(pfg), false);
        hit(cx, cy, pw, 18, b -> {
            pane = pane == Pane.SETTINGS ? Pane.MODULE : Pane.SETTINGS;
            search = "";
            paneScroll = paneScrollTarget = 0;
        });
    }

    private List<String> profileCycle() {
        List<String> list = new ArrayList<>(List.of(Config.QUICK_PROFILES));
        for (String p : Config.profiles()) if (!list.contains(p)) list.add(p);
        return list;
    }

    private List<Module> listModules() {
        if (search.isEmpty()) return BlocksClient.modules.inCategory(tab);
        String q = search.toLowerCase();
        List<Module> out = new ArrayList<>();
        for (Module m : BlocksClient.modules.all()) {
            boolean match = m.getName().toLowerCase().contains(q) || m.getDescription().toLowerCase().contains(q);
            for (Setting s : m.getSettings()) if (s.getName().toLowerCase().contains(q)) match = true;
            if (match) out.add(m);
        }
        return out;
    }

    /** Modules as two columns of capsules; enabled ones glow with a sunset gradient. */
    private void renderCapsules(Gfx g, double dt, Theme.Palette pal) {
        List<Module> mods = listModules();
        double top = listY, bottom = listY + listH;
        double capW = (listW - CAP_GAP) / 2;
        int rows = (mods.size() + 1) / 2;
        double content = rows * (CAP_H + CAP_GAP) - CAP_GAP;
        listScrollTarget = Math.max(0, Math.min(listScrollTarget, content - (bottom - top)));
        listScroll += (listScrollTarget - listScroll) * (gui.animations.get() ? 1 - Math.exp(-dt * 16) : 1);

        hoverModule = null;
        g.scissor((int) (listX - 4), (int) (top - 2), (int) (listX + listW + 4), (int) bottom);
        for (int i = 0; i < mods.size(); i++) {
            double x = listX + (i % 2) * (capW + CAP_GAP);
            double y = top + (i / 2) * (CAP_H + CAP_GAP) - listScroll;
            if (y + CAP_H < top || y > bottom) continue;
            renderCapsule(g, mods.get(i), x, y, capW, top, bottom, dt, pal);
        }
        g.noScissor();
        if (mods.isEmpty()) g.textScaled("No match for \"" + search + "\"", listX + 4, top + 6, a(Theme.TEXT_DIM), SMALL);
        if (content > bottom - top) {
            double view = bottom - top, barH = Math.max(16, view * view / content);
            double barY = top + (view - barH) * (listScroll / (content - view));
            Shapes.roundRect(listX + listW + 5, barY, 2, barH, 1, a(0x40FFFFFF));
        }
    }

    private void renderCapsule(Gfx g, Module m, double x, double y, double w, double clipTop, double clipBottom,
                               double dt, Theme.Palette pal) {
        boolean sel = m == selected && pane == Pane.MODULE;
        boolean hov = over(x, y, w, CAP_H) && my >= clipTop && my <= clipBottom;
        if (hov) hoverModule = m;
        double on = anim(m, m.isEnabled() ? 1 : 0, dt);
        double hv = anim("hov/" + m.getName(), hov ? 1 : 0, dt);
        double r = CAP_H / 2;

        if (on > 0.01) {
            if (glowOn()) Shapes.glow(x, y, w, CAP_H, r, 7, a(Theme.withAlpha(pal.accent(), (int) (70 * on))));
            Shapes.gradientRoundRect(x, y, w, CAP_H, r, a(Theme.withAlpha(pal.accent(), (int) (235 * on))),
                    a(Theme.withAlpha(pal.accent2(), (int) (190 * on))));
        }
        if (on < 0.99) Shapes.roundRect(x, y, w, CAP_H, r, a(Theme.withAlpha(0xFFFFFF, (int) ((9 + 9 * hv) * (1 - on)))));
        if (sel) Shapes.roundOutline(x - 1.5, y - 1.5, w + 3, CAP_H + 3, r + 1.5, 1.2, a(0xE6FFFFFF));
        else if (on < 0.5) Shapes.roundOutline(x, y, w, CAP_H, r, 1, a(Theme.withAlpha(0xFFFFFF, (int) (14 + 20 * hv))));

        // Status dot (click to toggle)
        double dx = x + 12, cy = y + CAP_H / 2;
        int dotColor = Theme.blend(0xFF6E6772, Theme.TEXT_ON_ACCENT, on);
        Shapes.circle(dx, cy, 3, a(dotColor));
        if (on < 0.5) Shapes.ring(dx, cy, 5, 0.7, a(Theme.withAlpha(0xFFFFFF, (int) (30 * hv))));

        int fg = Theme.blend(sel ? Theme.TEXT : hov ? Theme.TEXT : Theme.TEXT_DIM, Theme.TEXT_ON_ACCENT, on);
        double keyW = 0;
        if (m.getKey() > 0) {
            String key = Compat.keyName(m.getKey()).toUpperCase();
            if (key.length() > 5) key = key.substring(0, 5);
            keyW = g.widthMono(key, 0.7f);
            g.textMono(key, x + w - 11 - keyW, cy - 2.8, a(Theme.withAlpha(fg, 170)), 0.7f);
            keyW += 6;
        }
        double nameMax = w - 22 - 10 - keyW - (m.isFavorite() ? 10 : 0);
        g.text(trim(g, m.getName(), nameMax), (int) x + 21, (int) cy - 4, a(fg), false);
        if (m.isFavorite()) Shapes.icon("star_filled", x + 21 + Math.min(nameMax, g.width(m.getName())) + 7, cy, 7,
                a(on > 0.5 ? Theme.TEXT_ON_ACCENT : pal.accent2()));

        clippedHit(x, y, w, CAP_H, clipTop, clipBottom, b -> {
            boolean onDot = mx <= x + 20;
            if (b == 1 || (b == 0 && onDot)) {
                m.toggle();
            } else if (b == 0) {
                selected = selected == m && pane == Pane.MODULE ? null : m;
                pane = Pane.MODULE;
                paneScroll = paneScrollTarget = 0;
            } else if (b == 2) {
                selected = m;
                pane = Pane.MODULE;
                binding = m;
            }
        });
    }

    private void renderSheetFooter(Gfx g, Theme.Palette pal) {
        double fy = wy + wh - FOOT;
        // The sea along the bottom edge of the sheet.
        g.scissor((int) wx, (int) fy - 6, (int) (wx + ww), (int) (wy + wh));
        double t = gui.animations.get() ? System.currentTimeMillis() / 2000.0 : 0;
        for (int i = 0; i < 3; i++) {
            double off = Math.sin(t + i * 1.3) * 10 - 12;
            Shapes.wave(wx + off, fy - 2 + i * 5, ww + 24, 1.2, 30 + i * 6, 1.0,
                    a(Theme.withAlpha(i == 1 ? pal.accent2() : pal.accent(), 70 - i * 18)));
        }
        g.noScissor();
        double ly = wy + wh - 13;
        String left = "BLOCKS  //  OP " + Config.active().toUpperCase();
        label(g, left, wx + 20, ly, Theme.TEXT_FAINT);
        String right = "RMB TOGGLE   MMB BIND   ESC HUB";
        label(g, right, wx + ww - 20 - labelWidth(g, right), ly, Theme.TEXT_FAINT);
    }

    private String caret(boolean focused) {
        return focused && (System.currentTimeMillis() / 500) % 2 == 0 ? "|" : "";
    }

    // ------------------------------------------------------------------ inspector


    private void renderInspector(Gfx g, double dt, Theme.Palette pal) {
        Shapes.roundRect(insX, insY, insW, insH, 14, a(0x0DFFFFFF));
        Shapes.roundOutline(insX, insY, insW, insH, 14, 1, a(0x16FFFFFF));
        if (pane == Pane.SETTINGS) renderPreferences(g, dt, pal);
        else if (selected != null) renderDossier(g, dt, pal, selected);
        else renderEmptyInspector(g, pal);
    }

    private void renderEmptyInspector(Gfx g, Theme.Palette pal) {
        double cx = insX + insW / 2, cy = insY + insH / 2 - 18;
        if (glowOn()) Shapes.circleGlow(cx, cy - 4, 6, 26, a(Theme.withAlpha(pal.accent(), 50)));
        Shapes.icon("sunset", cx, cy, 42, a(pal.accent2()));
        String t = "PICK A MODULE";
        label(g, t, cx - labelWidth(g, t) / 2, cy + 28, Theme.TEXT_DIM);
        String hint = "Click one to change its settings";
        g.textScaled(hint, cx - g.widthScaled(hint, SMALL) / 2, cy + 40, a(Theme.TEXT_FAINT), SMALL);
    }

    private double rowHeight(Gfx g, Setting s, double w) {
        if (s instanceof NumSetting) return 28;
        if (s instanceof com.blocks.setting.BlockListSetting) return 38;
        if (s instanceof ModeSetting m && segmentedWidth(g, m) > w - g.width(s.getName()) - 12) {
            return segmentedWidth(g, m) <= w ? 34 : 18 + wrappedRows(g, m, w) * 17 + 2;
        }
        return SET_ROW;
    }

    private void renderDossier(Gfx g, double dt, Theme.Palette pal, Module m) {
        double x = insX + 12, w = insW - 24;
        double clipTop = insY + 1, clipBottom = insY + insH - 1;
        List<Setting> visible = new ArrayList<>();
        for (Setting s : m.getSettings()) if (s.isVisible()) visible.add(s);
        List<String> desc = wrap(g, m.getDescription(), w / SMALL, 3);

        double content = 12 + 14 + 16 + 16 + desc.size() * 9 + 10 + 12;
        for (Setting s : visible) content += rowHeight(g, s, w);
        content += 10 + 22 + 12;
        if (m instanceof com.blocks.module.world.AutoBuilder ab) content += 12 + builderSection(g, ab, x, 0, w, false, 0, 0, pal);
        paneScrollTarget = Math.max(0, Math.min(paneScrollTarget, content - insH));
        paneScroll += (paneScrollTarget - paneScroll) * (gui.animations.get() ? 1 - Math.exp(-dt * 16) : 1);

        g.scissor((int) insX, (int) clipTop, (int) (insX + insW), (int) clipBottom);
        double y = insY + 11 - paneScroll;

        label(g, m.getCategory().title.toUpperCase(), x, y, Theme.TEXT_FAINT);
        y += 12;

        // Name, a size up.
        var pose = g.pose();
        pose.pushMatrix();
        pose.translate((float) x, (float) y);
        pose.scale(1.3f, 1.3f);
        g.textBold(trim(g, m.getName(), (w - 16) / 1.3), 0, 0, a(Theme.TEXT), false);
        pose.popMatrix();
        boolean hovStar = over(x + w - 12, y - 1, 13, 13) && my >= clipTop && my <= clipBottom;
        Shapes.icon(m.isFavorite() ? "star_filled" : "star", x + w - 5, y + 5, 10,
                a(m.isFavorite() ? pal.accent2() : hovStar ? Theme.TEXT : Theme.TEXT_FAINT));
        clippedHit(x + w - 12, y - 1, 13, 13, clipTop, clipBottom, b -> m.setFavorite(!m.isFavorite()));
        y += 16;

        toggleSwitch(x, y + 1, m.isEnabled(), "dossier/" + m.getName(), dt);
        label(g, m.isEnabled() ? "ACTIVE" : "STANDBY", x + 26, y + 3.2, m.isEnabled() ? Theme.blend(pal.accent(), 0xFFFFFFFF, 0.25) : Theme.TEXT_FAINT);
        clippedHit(x - 2, y - 2, 70, 16, clipTop, clipBottom, b -> m.toggle());
        y += 16;

        for (String line : desc) {
            g.textScaled(line, x, y, a(Theme.TEXT_FAINT), SMALL);
            y += 9;
        }
        y += 4;
        Shapes.rect(x, y, w, 0.5, a(0x18FFFFFF));
        y += 6;
        label(g, "SETTINGS", x, y, Theme.TEXT_FAINT);
        y += 8;

        for (Setting s : visible) {
            double rh = rowHeight(g, s, w);
            renderSettingRow(g, s, x, y, w, rh, clipTop, clipBottom, dt, pal);
            y += rh;
        }
        if (visible.isEmpty()) {
            g.textScaled("None. Toggle and go.", x, y + 4, a(Theme.TEXT_FAINT), SMALL);
            y += 16;
        }

        if (m instanceof com.blocks.module.world.AutoBuilder ab) {
            y += 12;
            y += builderSection(g, ab, x, y, w, true, clipTop, clipBottom, pal);
        }

        // Keybind
        y += 10;
        boolean listening = binding == m;
        String key = listening ? "PRESS KEY" : m.getKey() > 0 ? Compat.keyName(m.getKey()).toUpperCase() : "NONE";
        double kw = g.widthMono(key, 0.75f) + 14;
        Shapes.roundRect(x, y, w, 22, 6, a(Theme.withAlpha(0xFFFFFF, listening ? 16 : 8)));
        Shapes.roundOutline(x, y, w, 22, 6, 1, a(listening ? Theme.withAlpha(pal.accent(), 180) : 0x10FFFFFF));
        g.text("Keybind", (int) x + 9, (int) y + 7, a(Theme.TEXT_DIM), false);
        Shapes.roundRect(x + w - 6 - kw, y + 4, kw, 14, 4, a(listening ? Theme.withAlpha(pal.accent(), 235) : 0x18FFFFFF));
        g.textMono(key, x + w - 6 - kw + 7, y + 8, a(listening ? Theme.TEXT_ON_ACCENT : Theme.TEXT), 0.75f);
        clippedHit(x, y, w, 22, clipTop, clipBottom, b -> binding = listening ? null : m);
        g.noScissor();
    }

    private void renderSettingRow(Gfx g, Setting s, double x, double y, double w, double h,
                                  double clipTop, double clipBottom, double dt, Theme.Palette pal) {
        if (s instanceof BoolSetting b) {
            boolean hov = over(x - 4, y, w + 8, h) && my >= clipTop && my <= clipBottom;
            g.text(s.getName(), (int) x, (int) y + 6, a(hov ? Theme.TEXT : Theme.TEXT_DIM), false);
            toggleSwitch(x + w - 20, y + 5, b.get(), b, dt);
            clippedHit(x - 4, y, w + 8, h, clipTop, clipBottom, btn -> {
                b.toggle();
                if (b == gui.particles) prefilled = false;
            });
        } else if (s instanceof NumSetting n) {
            g.text(s.getName(), (int) x, (int) y + 4, a(Theme.TEXT_DIM), false);
            String val = n.display();
            double vw = g.widthMono(val, 0.8f);
            g.textMono(val, x + w - vw, y + 4.6, a(pal.accent2()), 0.8f);
            slider(g, x, y + 19, w, n, clipTop, clipBottom, dt, pal);
        } else if (s instanceof ModeSetting m) {
            g.text(s.getName(), (int) x, (int) y + 6, a(Theme.TEXT_DIM), false);
            if (segmentedWidth(g, m) > w) segmentedWrapped(g, x, y + 18, w, m, clipTop, clipBottom, pal);
            else if (h > SET_ROW) segmented(g, x + w, y + 17, m, clipTop, clipBottom, pal);
            else segmented(g, x + w, y + 3, m, clipTop, clipBottom, pal);
        } else if (s instanceof com.blocks.setting.BlockListSetting bl) {
            blockListRow(g, bl, x, y, w, clipTop, clipBottom, pal);
        } else if (s instanceof com.blocks.setting.StringSetting str) {
            boolean focused = textFocus == str;
            g.text(s.getName(), (int) x, (int) y + 6, a(Theme.TEXT_DIM), false);
            double fw = Math.max(70, w - g.width(s.getName()) - 10), fx = x + w - fw;
            Shapes.roundRect(fx, y + 2, fw, 15, 5, a(Theme.withAlpha(0xFFFFFF, focused ? 24 : 14)));
            Shapes.roundOutline(fx, y + 2, fw, 15, 5, 1, a(focused ? Theme.withAlpha(pal.accent(), 210) : 0x14FFFFFF));
            String v = str.get();
            String shown = focused ? v : trim(g, v, (fw - 10) / 0.84);
            if (focused) while (shown.length() > 1 && g.widthScaled(shown + "|", 0.84f) > fw - 10) shown = shown.substring(1);
            g.textScaled(shown + caret(focused), fx + 5, y + 6, a(Theme.TEXT), 0.84f);
            clippedHit(fx, y + 2, fw, 15, clipTop, clipBottom, b -> {
                textFocus = str;
                searchFocused = false;
                profileFocused = false;
            });
        }
    }

    // ------------------------------------------------------------------ block list rows + picker

    private com.blocks.setting.BlockListSetting picker;
    private String pickerSearch = "", pickerFilter = "All";
    private double pickerScroll, pickerScrollTarget;
    private static List<net.minecraft.world.level.block.Block> allBlocks;
    private static final String[] FILTERS = {"All", "Selected", "Ores", "Storage", "Light", "Redstone", "Plants"};

    private static List<net.minecraft.world.level.block.Block> allBlocks() {
        if (allBlocks == null) {
            allBlocks = new ArrayList<>();
            for (var b : net.minecraft.core.registries.BuiltInRegistries.BLOCK) {
                if (b.asItem() != net.minecraft.world.item.Items.AIR) allBlocks.add(b);
            }
        }
        return allBlocks;
    }

    private static boolean matchesFilter(net.minecraft.world.level.block.Block b, String filter, com.blocks.setting.BlockListSetting set) {
        String id = net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(b).getPath();
        return switch (filter) {
            case "Selected" -> set.contains(b);
            case "Ores" -> id.endsWith("_ore") || id.equals("ancient_debris") || id.equals("raw_iron_block") || id.contains("amethyst");
            case "Storage" -> id.matches(".*(chest|barrel|shulker_box|hopper|furnace|smoker|dispenser|dropper|crafter).*");
            case "Light" -> id.matches(".*(torch|lantern|glowstone|lamp|shroomlight|candle|campfire|end_rod|froglight).*");
            case "Redstone" -> id.matches(".*(redstone|repeater|comparator|piston|observer|lever|button|pressure_plate|tnt|rail|target|daylight).*");
            case "Plants" -> id.matches(".*(kelp|sapling|leaves|flower|grass|fern|vine|mushroom|cactus|sugar_cane|bamboo|wheat|carrots|potatoes|beetroots|melon|pumpkin|tulip|daisy|poppy|orchid|allium|bluet|cornflower|lily|azalea|moss).*");
            default -> true;
        };
    }

    private double blockListRow(Gfx g, com.blocks.setting.BlockListSetting s, double x, double y, double w,
                                double clipTop, double clipBottom, Theme.Palette pal) {
        g.text(s.getName(), (int) x, (int) y + 4, a(Theme.TEXT_DIM), false);
        String n = s.get().size() + " picked";
        g.textScaled(n, x + g.width(s.getName()) + 6, y + 5, a(Theme.TEXT_FAINT), SMALL);
        pill(g, "Edit", x + w, y + 1, true, clipTop, clipBottom, () -> {
            picker = s;
            pickerSearch = "";
            pickerScroll = pickerScrollTarget = 0;
        });
        double ix = x + 8;
        int i = 0;
        for (var b : s.get()) {
            if (i++ >= 9) break;
            Shapes.roundRect(ix - 8, y + 16, 16, 16, 4, a(0x14FFFFFF));
            g.itemIcon(new net.minecraft.world.item.ItemStack(b), ix, y + 24, 12, Shapes.scale());
            ix += 19;
        }
        return 38;
    }

    private void renderPicker(Gfx g, double dt, Theme.Palette pal) {
        if (picker == null) return;
        double pw = Math.min(400, W - 40), ph = Math.min(270, H - 40);
        double px = W / 2 - pw / 2, py = H / 2 - ph / 2;
        Shapes.rect(0, 0, W, H, a(0x60000000));
        hit(0, 0, W, H, b -> picker = null);
        Shapes.glow(px, py + 6, pw, ph, 14, 24, a(0xA0000000));
        Shapes.roundRect(px, py, pw, ph, 14, a(glass(pal, 248)));
        Shapes.roundOutline(px, py, pw, ph, 14, 1, a(Theme.withAlpha(pal.accent(), 120)));
        hit(px, py, pw, ph, b -> {});

        g.textBold("Blocks", (int) px + 16, (int) py + 13, a(Theme.TEXT), false);
        g.textScaled(picker == null ? "" : "for " + pickerOwner(), px + 20 + g.widthBold("Blocks"), py + 14, a(Theme.TEXT_FAINT), SMALL);

        // Search
        double sx = px + 14, sy = py + 30, sw = pw - 28, sh = 20;
        Shapes.roundRect(sx, sy, sw, sh, 10, a(0x16FFFFFF));
        Shapes.roundOutline(sx, sy, sw, sh, 10, 1, a(Theme.withAlpha(pal.accent(), 150)));
        Shapes.icon("search", sx + 11, sy + sh / 2, 8, a(Theme.TEXT_DIM));
        g.text(pickerSearch.isEmpty() ? "Type to filter blocks" : pickerSearch + caret(true), (int) sx + 21, (int) (sy + sh / 2 - 4),
                a(pickerSearch.isEmpty() ? Theme.TEXT_FAINT : Theme.TEXT), false);

        // Filters
        double fx = px + 14, fy = sy + sh + 8;
        for (String f : FILTERS) {
            String label = f.equals("Selected") ? f + "  " + picker.get().size() : f;
            double fw = g.width(label) * 0.88 + 16;
            boolean on = pickerFilter.equals(f);
            boolean hov = over(fx, fy, fw, 16);
            Shapes.roundRect(fx, fy, fw, 16, 8, a(on ? Theme.withAlpha(pal.accent(), 235) : Theme.withAlpha(0xFFFFFF, hov ? 24 : 12)));
            g.textScaled(label, fx + 8, fy + 4.5, a(on ? Theme.TEXT_ON_ACCENT : Theme.TEXT_DIM), 0.88f);
            hit(fx, fy, fw, 16, b -> {
                pickerFilter = f;
                pickerScroll = pickerScrollTarget = 0;
            });
            fx += fw + 5;
        }

        // Grid
        String q = pickerSearch.toLowerCase();
        List<net.minecraft.world.level.block.Block> list = new ArrayList<>();
        for (var b : allBlocks()) {
            if (!matchesFilter(b, pickerFilter, picker)) continue;
            if (!q.isEmpty() && !b.getName().getString().toLowerCase().contains(q)
                    && !net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(b).getPath().contains(q)) continue;
            list.add(b);
        }
        double gx = px + 14, gy = fy + 24, gw = pw - 28, gh = py + ph - 38 - gy;
        double cell = 50, gap = 6;
        int cols = Math.max(1, (int) ((gw + gap) / (cell + gap)));
        double content = Math.ceil(list.size() / (double) cols) * (cell + gap);
        pickerScrollTarget = Math.max(0, Math.min(pickerScrollTarget, content - gh));
        pickerScroll += (pickerScrollTarget - pickerScroll) * (gui.animations.get() ? 1 - Math.exp(-dt * 16) : 1);
        g.scissor((int) gx, (int) gy, (int) (gx + gw), (int) (gy + gh));
        for (int i = 0; i < list.size(); i++) {
            double cx = gx + (i % cols) * (cell + gap), cy = gy + (i / cols) * (cell + gap) - pickerScroll;
            if (cy + cell < gy || cy > gy + gh) continue;
            var b = list.get(i);
            boolean sel = picker.contains(b);
            boolean hov = over(cx, cy, cell, cell) && my >= gy && my <= gy + gh;
            Shapes.roundRect(cx, cy, cell, cell, 8, a(sel ? Theme.withAlpha(pal.accent(), 60) : Theme.withAlpha(0xFFFFFF, hov ? 22 : 10)));
            if (sel) Shapes.roundOutline(cx, cy, cell, cell, 8, 1.2, a(Theme.withAlpha(pal.accent(), 240)));
            g.itemIcon(new net.minecraft.world.item.ItemStack(b), cx + cell / 2, cy + 18, 16, Shapes.scale());
            String name = trim(g, b.getName().getString(), (cell - 6) / 0.7);
            g.textScaled(name, cx + cell / 2 - g.widthScaled(name, 0.7f) / 2, cy + 35, a(sel ? Theme.TEXT : Theme.TEXT_DIM), 0.7f);
            if (sel) {
                Shapes.circle(cx + cell - 8, cy + 8, 4.5, a(pal.accent()));
                Shapes.icon("check", cx + cell - 8, cy + 8, 6, a(Theme.TEXT_ON_ACCENT));
            }
            final var blk = b;
            clippedHit(cx, cy, cell, cell, gy, gy + gh, btn -> picker.toggle(blk));
        }
        g.noScissor();
        if (list.isEmpty()) g.textScaled("No blocks match", gx + 4, gy + 6, a(Theme.TEXT_FAINT), SMALL);

        // Footer
        double fy2 = py + ph - 28;
        g.text(picker.get().size() + " selected", (int) px + 16, (int) fy2 + 5, a(Theme.TEXT_DIM), false);
        double dx = pill(g, "Done", px + pw - 14, fy2 + 2, true, 0, H, () -> picker = null);
        pill(g, "Clear", dx - 6, fy2 + 2, false, 0, H, () -> picker.clear());
    }

    private String pickerOwner() {
        for (Module m : BlocksClient.modules.all()) if (m.getSettings().contains(picker)) return m.getName();
        return "";
    }

    // ------------------------------------------------------------------ auto builder panel

    private final Map<Object, int[]> previewCache = new HashMap<>();

    private double builderSection(Gfx g, com.blocks.module.world.AutoBuilder b, double x, double y, double w,
                                  boolean draw, double clipTop, double clipBottom, Theme.Palette pal) {
        double y0 = y;
        if (draw) label(g, "SCHEMATIC", x, y, Theme.TEXT_FAINT);
        y += 11;
        if (b.schematic == null) {
            var files = b.files();
            if (draw) pill(g, "Open folder", x + w, y - 12, false, clipTop, clipBottom, () -> openFolder(com.blocks.module.world.AutoBuilder.folder()));
            if (files.isEmpty()) {
                if (draw) {
                    String[] steps = {"1  Put .litematic, .schem or .nbt files in", "    the schematics folder (Open folder)",
                            "2  Pick one here", "3  Stand where it goes, press Place here", "4  Rotate if needed, then Start"};
                    double sy = y + 2;
                    for (String st : steps) {
                        g.textScaled(st, x, sy, a(st.startsWith(" ") ? Theme.TEXT_FAINT : Theme.TEXT_DIM), 0.8f);
                        sy += 10;
                    }
                }
                return y + 54 - y0;
            }
            if (draw) g.textScaled("Pick a schematic:", x, y + 1, a(Theme.TEXT_FAINT), 0.78f);
            y += 12;
            for (var f : files) {
                if (draw) {
                    boolean hov = over(x - 4, y, w + 8, 18) && my >= clipTop && my <= clipBottom;
                    Shapes.roundRect(x - 4, y, w + 8, 18, 6, a(Theme.withAlpha(0xFFFFFF, hov ? 22 : 10)));
                    g.text(trim(g, f.getFileName().toString(), w - 10), (int) x + 3, (int) y + 5, a(hov ? Theme.TEXT : Theme.TEXT_DIM), false);
                    final var file = f;
                    clippedHit(x - 4, y, w + 8, 18, clipTop, clipBottom, btn -> b.load(file));
                }
                y += 21;
            }
            return y - y0;
        }
        var sc = b.schematic;
        if (draw) {
            g.textBold(trim(g, sc.name, w - 50), (int) x, (int) y, a(Theme.TEXT), false);
            pill(g, "Change", x + w, y - 3, false, clipTop, clipBottom, () -> { b.schematic = null; b.building = false; });
            g.textScaled(sc.sizeX + " x " + sc.sizeY + " x " + sc.sizeZ + "  ·  " + sc.blocks.size() + " blocks", x, y + 12, a(Theme.TEXT_FAINT), SMALL);
        }
        y += 26;
        // Top-down preview
        double pv = Math.min(w, 96);
        if (draw) drawPreview(g, sc, x + (w - pv) / 2, y, pv, pal);
        y += pv + 8;
        if (draw) {
            int total = b.progressTotal(), done = b.progressDone();
            double pct = total == 0 ? 0 : done / (double) total;
            Shapes.roundRect(x, y, w, 3, 1.5, a(0x22FFFFFF));
            Shapes.roundRect(x, y, Math.max(3, w * pct), 3, 1.5, a(pal.accent()));
            g.textMono((int) (pct * 100) + "%", x + w - g.widthMono((int) (pct * 100) + "%", 0.72f), y + 6, a(Theme.TEXT_DIM), 0.72f);
            g.textScaled(b.origin == null ? "Not placed yet" : "at " + b.origin.getX() + ", " + b.origin.getY() + ", " + b.origin.getZ(), x, y + 6.5, a(Theme.TEXT_FAINT), 0.78f);
        }
        y += 18;
        if (draw) {
            g.textScaled(b.origin == null ? "Stand where it goes, then Place here" : b.building ? "Building..." : "Placed: press Start", x, y - 9, a(Theme.TEXT_FAINT), 0.72f);
            double bx = pill(g, b.building ? "Pause" : "Start", x + w, y, true, clipTop, clipBottom, b::toggleBuilding);
            String rot = switch (b.rotation) { case CLOCKWISE_90 -> "90"; case CLOCKWISE_180 -> "180"; case COUNTERCLOCKWISE_90 -> "270"; default -> "0"; };
            bx = pill(g, "Rotate " + rot + "°", bx - 5, y, false, clipTop, clipBottom, b::rotate);
            pill(g, "Place here", bx - 5, y, false, clipTop, clipBottom, b::placeHere);
        }
        y += 22;
        if (draw) label(g, "MATERIALS", x, y, Theme.TEXT_FAINT);
        y += 11;
        int rows = 0;
        for (var e : b.materialStatus().entrySet()) {
            if (rows++ >= 14) break;
            if (draw) {
                int have = e.getValue()[0], need = e.getValue()[1];
                g.itemIcon(new net.minecraft.world.item.ItemStack(e.getKey()), x + 7, y + 7, 12, Shapes.scale());
                String nm = trim(g, e.getKey().getName(new net.minecraft.world.item.ItemStack(e.getKey())).getString(), w - 70);
                g.textScaled(nm, x + 18, y + 2, a(have >= need ? Theme.TEXT_DIM : Theme.TEXT), 0.84f);
                String cnt = Math.min(have, need) + "/" + need;
                g.textMono(cnt, x + w - g.widthMono(cnt, 0.72f), y + 2.5, a(have >= need ? 0xFF6BE08E : Theme.TEXT_FAINT), 0.72f);
                double pct = Math.min(1, have / (double) need);
                Shapes.roundRect(x + 18, y + 11, w - 18, 1.6, 0.8, a(0x1EFFFFFF));
                Shapes.roundRect(x + 18, y + 11, Math.max(1.6, (w - 18) * pct), 1.6, 0.8, a(have >= need ? 0xFF6BE08E : pal.accent()));
            }
            y += 17;
        }
        return y - y0;
    }

    /** Top-down map of the schematic coloured by each column's top block. */
    private void drawPreview(Gfx g, com.blocks.world.Schematic sc, double x, double y, double size, Theme.Palette pal) {
        int gx = Math.min(40, sc.sizeX), gz = Math.min(40, sc.sizeZ);
        int[] colors = previewCache.computeIfAbsent(sc, k2 -> {
            int[] top = new int[gx * gz];
            int[] topY = new int[gx * gz];
            java.util.Arrays.fill(topY, Integer.MIN_VALUE);
            for (var e : sc.blocks.entrySet()) {
                int cx = e.getKey().getX() * gx / sc.sizeX, cz = e.getKey().getZ() * gz / sc.sizeZ;
                int i = cz * gx + cx;
                if (e.getKey().getY() >= topY[i]) {
                    topY[i] = e.getKey().getY();
                    int col = e.getValue().getBlock().defaultMapColor().col;
                    double shade = 0.65 + 0.35 * (e.getKey().getY() + 1) / Math.max(1.0, sc.sizeY);
                    int r = (int) (((col >> 16) & 0xFF) * shade), gg = (int) (((col >> 8) & 0xFF) * shade), bb = (int) ((col & 0xFF) * shade);
                    top[i] = 0xFF000000 | r << 16 | gg << 8 | bb;
                }
            }
            return top;
        });
        double cell = size / Math.max(gx, gz);
        double ox = x + (size - cell * gx) / 2, oy = y + (size - cell * gz) / 2;
        Shapes.roundRect(x - 3, y - 3, size + 6, size + 6, 6, a(0x14FFFFFF));
        for (int z = 0; z < gz; z++) for (int xx = 0; xx < gx; xx++) {
            int c = colors[z * gx + xx];
            if (c != 0) Shapes.rect(ox + xx * cell, oy + z * cell, cell + 0.05, cell + 0.05, a(c));
        }
    }

    // ------------------------------------------------------------------ preferences

    private void renderPreferences(Gfx g, double dt, Theme.Palette pal) {
        double x = insX + 12, w = insW - 24;
        double clipTop = insY + 1, clipBottom = insY + insH - 1;
        boolean custom = gui.theme.is("Custom");
        List<String> profiles = Config.profiles();

        double content = 11 + 12 + 18
                + 10 + 34 + rowHeight(g, gui.design, w) + rowHeight(g, gui.menuStyle, w) + 28 + rowHeight(g, gui.font, w) + rowHeight(g, gui.guiScale, w) + (custom ? 2 * SET_ROW : 0)
                + 6 + 10 + 6 * SET_ROW + rowHeight(g, gui.particleStyle, w)
                + 6 + 10 + (gui.notifications.get() ? 5 : 2) * SET_ROW
                + 6 + 10 + profiles.size() * SET_ROW + 4 + 18 + 12;
        paneScrollTarget = Math.max(0, Math.min(paneScrollTarget, content - insH));
        paneScroll += (paneScrollTarget - paneScroll) * (gui.animations.get() ? 1 - Math.exp(-dt * 16) : 1);

        g.scissor((int) insX, (int) clipTop, (int) (insX + insW), (int) clipBottom);
        double y = insY + 11 - paneScroll;
        label(g, "SYSTEM", x, y, Theme.TEXT_FAINT);
        y += 12;
        var pose = g.pose();
        pose.pushMatrix();
        pose.translate((float) x, (float) y);
        pose.scale(1.3f, 1.3f);
        g.textBold("Preferences", 0, 0, a(Theme.TEXT), false);
        pose.popMatrix();
        y += 18;

        // ---- Appearance
        y = section(g, "APPEARANCE", x, y);
        int count = Theme.PRESETS.length + 1;
        double step = Math.min(24, (w - 8) / (count - 1) - 0.01);
        double sx = x + 8;
        for (int i = 0; i < count; i++) {
            boolean isCustom = i == Theme.PRESETS.length;
            Theme.Palette p = isCustom ? customPalette() : Theme.PRESETS[i];
            boolean sel = gui.theme.is(p.name());
            boolean hov = over(sx - 9, y, 18, 20) && my >= clipTop && my <= clipBottom;
            double cy = y + 9;
            double s = anim("swatch/" + p.name(), sel ? 1 : hov ? 0.45 : 0, dt);
            if (s > 0.01) Shapes.ring(sx, cy, 9, 1.2, a(Theme.withAlpha(Theme.blend(p.accent(), 0xFFFFFFFF, 0.45), (int) (255 * s))));
            Shapes.circle(sx, cy, 6.5, a(p.accent2()));
            Shapes.icon("half", sx, cy, 13, a(p.accent()));
            if (isCustom) Shapes.icon("plus", sx, cy, 6, a(Theme.TEXT_ON_ACCENT));
            final String name = p.name();
            clippedHit(sx - 9, y, 18, 20, clipTop, clipBottom, b -> gui.theme.set(name));
            if (hov) hoverText = name;
            sx += step;
        }
        label(g, gui.theme.get().toUpperCase(), x, y + 23, Theme.TEXT_DIM);
        y += 34;
        y = modeRow(g, gui.design, x, y, w, clipTop, clipBottom, dt, pal);
        y = modeRow(g, gui.menuStyle, x, y, w, clipTop, clipBottom, dt, pal);
        renderSettingRow(g, gui.panelOpacity, x, y, w, 28, clipTop, clipBottom, dt, pal);
        y += 28;
        y = modeRow(g, gui.font, x, y, w, clipTop, clipBottom, dt, pal);
        y = modeRow(g, gui.guiScale, x, y, w, clipTop, clipBottom, dt, pal);
        if (custom) {
            y = rgbRow(g, "Accent", x, y, w, gui.accentR, gui.accentG, gui.accentB, clipTop, clipBottom);
            y = rgbRow(g, "Panel", x, y, w, gui.panelR, gui.panelG, gui.panelB, clipTop, clipBottom);
        }

        // ---- Effects
        y += 6;
        y = section(g, "EFFECTS", x, y);
        y = boolRow(g, gui.particles, x, y, w, clipTop, clipBottom, dt, pal);
        y = modeRow(g, gui.particleStyle, x, y, w, clipTop, clipBottom, dt, pal);
        y = boolRow(g, gui.blur, x, y, w, clipTop, clipBottom, dt, pal);
        y = boolRow(g, gui.dim, x, y, w, clipTop, clipBottom, dt, pal);
        y = boolRow(g, gui.glow, x, y, w, clipTop, clipBottom, dt, pal);
        y = boolRow(g, gui.animations, x, y, w, clipTop, clipBottom, dt, pal);
        y = boolRow(g, gui.tooltips, x, y, w, clipTop, clipBottom, dt, pal);

        // ---- HUD & alerts
        y += 6;
        y = section(g, "HUD & ALERTS", x, y);
        g.text("HUD layout", (int) x, (int) y + 6, a(Theme.TEXT_DIM), false);
        pill(g, "Edit", x + w, y + 3, true, clipTop, clipBottom, () -> {
            editHud = true;
            Hud.editing = true;
        });
        y += SET_ROW;
        y = boolRow(g, gui.notifications, x, y, w, clipTop, clipBottom, dt, pal);
        if (gui.notifications.get()) {
            y = boolRow(g, gui.toggleAlerts, x, y, w, clipTop, clipBottom, dt, pal);
            y = boolRow(g, gui.findAlerts, x, y, w, clipTop, clipBottom, dt, pal);
            y = boolRow(g, gui.notificationSound, x, y, w, clipTop, clipBottom, dt, pal);
        }

        // ---- Profiles
        y += 6;
        y = section(g, "OPERATIONS", x, y);
        for (String name : profiles) {
            boolean active = name.equals(Config.active());
            if (active) Shapes.circle(x + 3, y + 10, 2.5, a(pal.accent()));
            g.text(trim(g, name, w - 90), (int) x + (active ? 10 : 0), (int) y + 6, a(active ? Theme.TEXT : Theme.TEXT_DIM), false);
            if (active) {
                label(g, "LIVE", x + w - labelWidth(g, "LIVE"), y + 7.6, Theme.blend(pal.accent(), 0xFFFFFFFF, 0.25));
            } else {
                double dx = pill(g, "Delete", x + w, y + 3, false, clipTop, clipBottom, () -> Config.delete(name));
                pill(g, "Load", dx - 4, y + 3, true, clipTop, clipBottom, () -> Config.switchTo(name));
            }
            y += SET_ROW;
        }
        y += 4;
        double fw = w - 48;
        Shapes.roundRect(x, y, fw, 18, 6, a(Theme.withAlpha(0xFFFFFF, profileFocused ? 20 : 9)));
        Shapes.roundOutline(x, y, fw, 18, 6, 1, a(profileFocused ? Theme.withAlpha(pal.accent(), 200) : 0x12FFFFFF));
        boolean empty = newProfile.isEmpty() && !profileFocused;
        g.text(empty ? "New operation" : newProfile + caret(profileFocused), (int) x + 8, (int) y + 5,
                a(empty ? Theme.TEXT_FAINT : Theme.TEXT), false);
        clippedHit(x, y, fw, 18, clipTop, clipBottom, b -> {
            profileFocused = true;
            searchFocused = false;
        });
        pill(g, "Save", x + w, y + 2, true, clipTop, clipBottom, this::createProfile);
        g.noScissor();
    }

    private Theme.Palette customPalette() {
        int acc = 0xFF000000 | (gui.accentR.getInt() << 16) | (gui.accentG.getInt() << 8) | gui.accentB.getInt();
        int pan = 0xFF000000 | (gui.panelR.getInt() << 16) | (gui.panelG.getInt() << 8) | gui.panelB.getInt();
        return new Theme.Palette("Custom", acc, Theme.blend(acc, 0xFFFFFFFF, 0.35), pan);
    }

    private double section(Gfx g, String title, double x, double y) {
        label(g, title, x, y, Theme.TEXT_FAINT);
        return y + 10;
    }

    private double boolRow(Gfx g, BoolSetting b, double x, double y, double w, double clipTop, double clipBottom, double dt, Theme.Palette pal) {
        renderSettingRow(g, b, x, y, w, SET_ROW, clipTop, clipBottom, dt, pal);
        return y + SET_ROW;
    }

    private double modeRow(Gfx g, ModeSetting m, double x, double y, double w, double clipTop, double clipBottom, double dt, Theme.Palette pal) {
        double h = rowHeight(g, m, w);
        renderSettingRow(g, m, x, y, w, h, clipTop, clipBottom, dt, pal);
        return y + h;
    }

    private double rgbRow(Gfx g, String label, double x, double y, double w, NumSetting r, NumSetting gr, NumSetting b,
                          double clipTop, double clipBottom) {
        int color = 0xFF000000 | (r.getInt() << 16) | (gr.getInt() << 8) | b.getInt();
        Shapes.roundRect(x, y + 5, 10, 10, 3, a(color));
        Shapes.roundOutline(x, y + 5, 10, 10, 3, 0.5, a(0x3CFFFFFF));
        g.textScaled(label, x + 15, y + 7, a(Theme.TEXT_DIM), SMALL);
        double sx = x + 50, segW = (w - 50) / 3;
        NumSetting[] parts = {r, gr, b};
        int[] tints = {0xFFFF6B6B, 0xFF6BE08E, 0xFF6BA6FF};
        for (int i = 0; i < 3; i++) {
            double tx = sx + i * segW, tw = segW - 8;
            double pct = parts[i].getPercent();
            Shapes.roundRect(tx, y + 9, tw, 3, 1.5, a(0x22FFFFFF));
            Shapes.roundRect(tx, y + 9, Math.max(3, tw * pct), 3, 1.5, a(tints[i]));
            Shapes.circle(tx + tw * pct, y + 10.5, 3, a(0xFFFFFFFF));
            final NumSetting part = parts[i];
            dragHit(tx - 3, y + 2, tw + 6, 16, clipTop, clipBottom, v -> part.setPercent((v - tx) / tw));
        }
        return y + SET_ROW;
    }

    private void createProfile() {
        String name = newProfile.trim();
        if (name.isEmpty()) return;
        Config.switchTo(name);
        newProfile = "";
        profileFocused = false;
    }

    // ------------------------------------------------------------------ widgets

    private void toggleSwitch(double x, double y, boolean on, Object key, double dt) {
        Theme.Palette pal = Theme.current();
        double t = anim(key, on ? 1 : 0, dt);
        if (facet()) {
            // Facet: a lit capsule with a hexagon knob.
            Shapes.roundRect(x, y, 20, 10, 5, a(Theme.withAlpha(0xFFFFFF, (int) (34 * (1 - t)))));
            if (t > 0.01) Shapes.gradientRoundRect(x, y, 20, 10, 5, a(Theme.withAlpha(pal.accent(), (int) (240 * t))), a(Theme.withAlpha(pal.accent2(), (int) (240 * t))));
            double kx = x + 5 + 10 * t, ky = y + 5;
            if (glowOn() && t > 0.01) Shapes.hex(kx, ky, 4.4, 0.8, 4, Shapes.Layer.GLOW, a(Theme.withAlpha(0xFFFFFFFF, (int) (110 * t))));
            Shapes.hex(kx, ky, 4.4, 0.8, 0, Shapes.Layer.FILL, a(Theme.blend(0xFFBDB5C4, 0xFFFFFFFF, t)));
            return;
        }
        Shapes.roundRect(x, y, 20, 10, 5, a(Theme.blend(0x2EFFFFFF, pal.accent(), t)));
        Shapes.circle(x + 5 + 10 * t, y + 5, 3.4, a(Theme.blend(0xFFCFC8C6, 0xFFFFFFFF, t)));
    }

    private double segmentedWidth(Gfx g, ModeSetting mode) {
        double total = 4;
        for (String o : mode.options()) total += g.width(o) * 0.88 + 14;
        return total;
    }

    private void segmented(Gfx g, double rightX, double y, ModeSetting mode, double clipTop, double clipBottom, Theme.Palette pal) {
        double total = segmentedWidth(g, mode);
        double x = rightX - total;
        if (facet()) {
            // Facet: one soft track, and a highlight that glides to the chosen option.
            Shapes.roundRect(x, y, total, 14, 7, a(0x14FFFFFF));
            double ox = x + 2, selX = ox, selW = 0;
            for (String o : mode.options()) {
                double ow = g.width(o) * 0.88 + 14;
                if (mode.is(o)) {
                    selX = ox;
                    selW = ow - 4;
                }
                ox += ow - 2;
            }
            double ax = anim("segx/" + System.identityHashCode(mode), selX - x, 0.016 * 1.4), aw = anim("segw/" + System.identityHashCode(mode), selW, 0.016 * 1.4);
            Shapes.gradientRoundRect(x + ax, y + 2, aw, 10, 5, a(pal.accent()), a(Theme.blend(pal.accent(), pal.accent2(), 0.6)));
            ox = x + 2;
            for (String o : mode.options()) {
                double ow = g.width(o) * 0.88 + 14;
                boolean sel = mode.is(o);
                boolean hov = over(ox, y, ow - 2, 14) && my >= clipTop && my <= clipBottom;
                g.textScaled(o, ox + 5, y + 3.6, a(sel ? Theme.TEXT_ON_ACCENT : hov ? Theme.TEXT : Theme.TEXT_DIM), 0.88f);
                final String opt = o;
                clippedHit(ox, y, ow - 2, 14, clipTop, clipBottom, b -> mode.set(opt));
                ox += ow - 2;
            }
            return;
        }
        Shapes.roundRect(x, y, total, 14, 5, a(0x12FFFFFF));
        Shapes.roundOutline(x, y, total, 14, 5, 1, a(0x0EFFFFFF));
        double ox = x + 2;
        for (String o : mode.options()) {
            double ow = g.width(o) * 0.88 + 14;
            boolean sel = mode.is(o);
            boolean hov = over(ox, y, ow - 2, 14) && my >= clipTop && my <= clipBottom;
            if (sel) Shapes.roundRect(ox, y + 2, ow - 4, 10, 3.5, a(pal.accent()));
            else if (hov) Shapes.roundRect(ox, y + 2, ow - 4, 10, 3.5, a(0x16FFFFFF));
            g.textScaled(o, ox + 5, y + 3.6, a(sel ? Theme.TEXT_ON_ACCENT : Theme.TEXT_DIM), 0.88f);
            final String opt = o;
            clippedHit(ox, y, ow - 2, 14, clipTop, clipBottom, b -> mode.set(opt));
            ox += ow - 2;
        }
    }

    private int wrappedRows(Gfx g, ModeSetting mode, double w) {
        int rows = 1;
        double cx = 0;
        for (String o : mode.options()) {
            double ow = g.width(o) * 0.88 + 14;
            if (cx > 0 && cx + ow > w) {
                rows++;
                cx = 0;
            }
            cx += ow + 3;
        }
        return rows;
    }

    /** Options that don't fit on one line flow onto the next, as separate chips. */
    private void segmentedWrapped(Gfx g, double x, double y, double w, ModeSetting mode, double clipTop, double clipBottom, Theme.Palette pal) {
        double cx = x, cy = y;
        for (String o : mode.options()) {
            double ow = g.width(o) * 0.88 + 14;
            if (cx > x && cx + ow > x + w) {
                cx = x;
                cy += 17;
            }
            boolean sel = mode.is(o);
            boolean hov = over(cx, cy, ow, 14) && my >= clipTop && my <= clipBottom;
            Shapes.roundRect(cx, cy, ow, 14, 5, a(sel ? pal.accent() : Theme.withAlpha(0xFFFFFF, hov ? 26 : 12)));
            g.textScaled(o, cx + 7, cy + 3.6, a(sel ? Theme.TEXT_ON_ACCENT : Theme.TEXT_DIM), 0.88f);
            final String opt = o;
            clippedHit(cx, cy, ow, 14, clipTop, clipBottom, b -> mode.set(opt));
            cx += ow + 3;
        }
    }

    private void slider(Gfx g, double x, double y, double w, NumSetting num, double clipTop, double clipBottom, double dt, Theme.Palette pal) {
        double pct = anim(num, num.getPercent(), dt * 1.5);
        if (facet()) {
            Shapes.roundRect(x, y, w, 3, 1.5, a(0x22FFFFFF));
            Shapes.gradientRoundRect(x, y, Math.max(3, w * pct), 3, 1.5, a(pal.accent()), a(pal.accent2()));
            double kx = x + w * pct, ky = y + 1.5;
            if (glowOn()) Shapes.hex(kx, ky, 5, 1, 5, Shapes.Layer.GLOW, a(Theme.withAlpha(pal.accent(), 120)));
            Shapes.hex(kx, ky, 5, 1, 0, Shapes.Layer.FILL, a(0xFFFFFFFF));
            Shapes.hex(kx, ky, 2.2, 0.5, 0, Shapes.Layer.FILL, a(pal.accent()));
            dragHit(x - 5, y - 8, w + 10, 18, clipTop, clipBottom, v -> num.setPercent((v - x) / w));
            return;
        }
        Shapes.roundRect(x, y, w, 3, 1.5, a(0x24FFFFFF));
        // Tick marks every 10% like an instrument scale.
        for (int i = 1; i < 10; i++) Shapes.rect(x + w * i / 10.0, y + 5, 0.5, 2, a(0x18FFFFFF));
        Shapes.roundRect(x, y, Math.max(3, w * pct), 3, 1.5, a(pal.accent()));
        Shapes.circle(x + w * pct, y + 1.5, 4.2, a(0xFFFFFFFF));
        Shapes.circle(x + w * pct, y + 1.5, 1.8, a(pal.accent()));
        dragHit(x - 5, y - 8, w + 10, 18, clipTop, clipBottom, v -> num.setPercent((v - x) / w));
    }

    /** Right-aligned pill button. @return its left x. */
    private double pill(Gfx g, String label, double rightX, double y, boolean accent, double clipTop, double clipBottom, Runnable action) {
        double w = g.width(label) * 0.88 + 14;
        double x = rightX - w;
        boolean hov = over(x, y, w, 14) && my >= clipTop && my <= clipBottom;
        Theme.Palette pal = Theme.current();
        int fill = accent ? Theme.withAlpha(pal.accent(), hov ? 255 : 210) : Theme.withAlpha(0xFFFFFF, hov ? 28 : 14);
        Shapes.roundRect(x, y, w, 14, 5, a(fill));
        g.textScaled(label, x + 7, y + 3.6, a(accent ? Theme.TEXT_ON_ACCENT : Theme.TEXT_DIM), 0.88f);
        clippedHit(x, y, w, 14, clipTop, clipBottom, b -> action.run());
        return x;
    }

    private void renderTooltip(Gfx g) {
        String text = hoverText;
        hoverText = null;
        if (text == null && gui.tooltips.get() && hoverModule != null) {
            if (hoverModule != lastHover) {
                lastHover = hoverModule;
                hoverSince = System.currentTimeMillis();
            }
            if (System.currentTimeMillis() - hoverSince > 550) text = hoverModule.getDescription();
        } else if (hoverModule == null) {
            lastHover = null;
        }
        if (text == null) return;
        double w = g.width(text) * SMALL + 14, h = 15;
        double x = Math.min(mx + 10, W - w - 4), y = my + 14;
        Shapes.glow(x, y + 2, w, h, 6, 8, a(0x80000000));
        Shapes.roundRect(x, y, w, h, 6, a(glass(Theme.current(), 248)));
        Shapes.roundOutline(x, y, w, h, 6, 1, a(0x26FFFFFF));
        g.textScaled(text, x + 7, y + 4.2, a(Theme.TEXT), SMALL);
    }

    // ------------------------------------------------------------------ HUD editor

    private void renderHudEditor(Gfx g) {
        if (draggingEl != null) draggingEl.moveTo(mx - dragOffX, my - dragOffY, W, H);
        hud.renderAll(g, true);
        g.pose().pushMatrix();
        g.pose().scale(k, k);
        Shapes.begin(g, gui.uiScale());
        Shapes.dotGrid(0, 0, W, H, 16, 0x10FFFFFF);
        Shapes.rect(W / 2 - 0.25, 0, 0.5, H, 0x1EFFFFFF);
        Shapes.rect(0, H / 2 - 0.25, W, 0.5, 0x1EFFFFFF);
        for (HudElement e : hud.elements) {
            if (!e.visible()) continue;
            double x = e.x(W), y = e.y(H);
            boolean hov = e.contains(mx, my, W, H) || e == draggingEl;
            Shapes.cropMarks(x - 4, y - 4, e.w + 8, e.h + 8, 6, 1, hov ? Theme.withAlpha(Theme.accent(), 240) : 0x60FFFFFF);
            if (hov) g.textTracked(e.name.toUpperCase(), x - 3, y - 13, Theme.TEXT, LABEL, TRACK);
        }
        String hint = "DRAG TO REPOSITION   ESC TO CONFIRM";
        double w = g.widthTracked(hint, LABEL, TRACK) + 26;
        double x = W / 2 - w / 2;
        Shapes.roundRect(x, 12, w, 20, 6, glass(Theme.current(), 240));
        Shapes.roundOutline(x, 12, w, 20, 6, 1, Theme.withAlpha(Theme.accent(), 150));
        Shapes.circle(x + 10, 22, 2, ONLINE);
        g.textTracked(hint, x + 17, 19.6, Theme.TEXT, LABEL, TRACK);
        g.pose().popMatrix();
    }

    // ================================================================== input

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        double ux = x / k, uy = y / k;
        if (editHud) {
            for (int i = hud.elements.size() - 1; i >= 0; i--) {
                HudElement e = hud.elements.get(i);
                if (e.visible() && e.contains(ux, uy, W, H)) {
                    draggingEl = e;
                    dragOffX = ux - e.x(W);
                    dragOffY = uy - e.y(H);
                    return true;
                }
            }
            return true;
        }
        mx = ux;
        my = uy;
        boolean wasBinding = binding != null;
        searchFocused = false;
        profileFocused = false;
        textFocus = null;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.contains.test(ux, uy)) continue;
            if (wasBinding) binding = null;
            if (h.drag != null) {
                activeDrag = h.drag;
                h.drag.accept(ux);
            } else {
                h.click.accept(button);
            }
            return true;
        }
        if (wasBinding) {
            binding = null;
            return true;
        }
        // Clicked empty space: grab a HUD element if one is there, else close.
        if (view == View.DOCK) {
            for (int i = hud.elements.size() - 1; i >= 0; i--) {
                HudElement e = hud.elements.get(i);
                if (e.visible() && e.x(W) >= Hud.coveredRight && e.contains(ux, uy, W, H)) {
                    draggingEl = e;
                    dragOffX = ux - e.x(W);
                    dragOffY = uy - e.y(H);
                    return true;
                }
            }
        }
        if (view == View.MENU) switchView(View.HUB);
        else close();
        return true;
    }

    @Override
    public boolean mouseReleased(double x, double y, int button) {
        activeDrag = null;
        if (draggingEl != null && view == View.DOCK) Config.save();
        draggingEl = null;
        return true;
    }

    @Override
    public boolean mouseDragged(double x, double y, int button) {
        if (activeDrag != null) activeDrag.accept(x / k);
        return true;
    }

    @Override
    public boolean mouseScrolled(double x, double y, double amount) {
        if (view == View.HUB) return true;
        if (picker != null) {
            pickerScrollTarget -= amount * 40;
            return true;
        }
        if (view == View.DOCK) {
            double ux = x / k;
            boolean overCard = (expanded != null || dockPrefs) && ux >= cardX && ux <= cardX + cardW;
            if (overCard) paneScrollTarget -= amount * 24;
            else listScrollTarget -= amount * 36;
            return true;
        }
        if (x / k >= insX) paneScrollTarget -= amount * 24;
        else listScrollTarget -= amount * (CAP_H + CAP_GAP) * 2;
        return true;
    }

    @Override
    public boolean keyPressed(int key, int modifiers) {
        if (binding != null) {
            if (key == InputConstants.KEY_ESCAPE || key == InputConstants.KEY_BACKSPACE || key == InputConstants.KEY_DELETE) binding.setKey(-1);
            else binding.setKey(key);
            binding = null;
            return true;
        }
        if (picker != null) {
            if (key == InputConstants.KEY_BACKSPACE && !pickerSearch.isEmpty()) pickerSearch = pickerSearch.substring(0, pickerSearch.length() - 1);
            else if (key == InputConstants.KEY_ESCAPE || key == InputConstants.KEY_RETURN) picker = null;
            return true;
        }
        if (editHud) {
            if (key == InputConstants.KEY_ESCAPE) {
                editHud = false;
                Hud.editing = false;
                Config.save();
            }
            return true;
        }
        if (textFocus != null) {
            String v = textFocus.get();
            if (key == InputConstants.KEY_BACKSPACE && !v.isEmpty()) textFocus.set(v.substring(0, v.length() - 1));
            else if (key == InputConstants.KEY_RETURN || key == InputConstants.KEY_ESCAPE) {
                textFocus = null;
                Config.save();
            }
            return true;
        }
        if (profileFocused) {
            if (key == InputConstants.KEY_BACKSPACE && !newProfile.isEmpty()) newProfile = newProfile.substring(0, newProfile.length() - 1);
            else if (key == InputConstants.KEY_RETURN) createProfile();
            else if (key == InputConstants.KEY_ESCAPE) profileFocused = false;
            return true;
        }
        if (searchFocused || !search.isEmpty()) {
            if (key == InputConstants.KEY_BACKSPACE && !search.isEmpty()) {
                search = search.substring(0, search.length() - 1);
                listScroll = listScrollTarget = 0;
                return true;
            }
            if (key == InputConstants.KEY_ESCAPE) {
                search = "";
                searchFocused = false;
                return true;
            }
        }
        if (key == gui.getKey() && !searchFocused) {
            close();
            return true;
        }
        if (key == InputConstants.KEY_ESCAPE && view == View.MENU) {
            switchView(View.HUB);
            return true;
        }
        if (key == InputConstants.KEY_ESCAPE && view == View.DOCK && (dockPrefs || expanded != null)) {
            dockPrefs = false;
            expanded = null;
            return true;
        }
        return false;
    }

    @Override
    public boolean charTyped(String chars) {
        if (binding != null || editHud) return true;
        if (picker != null) {
            if (pickerSearch.length() < 32) pickerSearch += chars;
            pickerScroll = pickerScrollTarget = 0;
            return true;
        }
        if (textFocus != null) {
            if (textFocus.get().length() < 96) textFocus.set(textFocus.get() + chars);
            return true;
        }
        if (profileFocused) {
            if (newProfile.length() < 24) newProfile += chars.replaceAll("[^A-Za-z0-9 _-]", "");
            return true;
        }
        if (chars.isBlank() && search.isEmpty()) return true;
        // Typing anywhere searches.
        if (view == View.HUB) switchView(View.MENU);
        searchFocused = true;
        if (search.length() < 32) {
            search += chars;
            listScroll = listScrollTarget = 0;
        }
        return true;
    }

    @Override
    public void onClose() {
        if (view == View.DOCK) dockScroll = listScrollTarget;
        Hud.coveredRight = -1;
        Hud.editing = false;
        Config.save();
    }
}
