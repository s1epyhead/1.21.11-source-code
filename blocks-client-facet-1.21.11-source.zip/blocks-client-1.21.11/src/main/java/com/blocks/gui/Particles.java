package com.blocks.gui;

import com.blocks.render.Shapes;
import com.blocks.util.Theme;
import org.joml.Matrix3x2fStack;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/** Blocks particles for the menu background: palm trees drifting by, petals, fireflies or bubbles. */
public class Particles {
    private static class P {
        double x, y, vx, vy, rot, vr, size, phase;
    }

    private final List<P> list = new ArrayList<>();
    /** Area kept clear of particles (the Facet hub), in UI units; radius 0 = none. */
    public static double exclX, exclY, exclR;
    /** Particles fade out left of this x (behind the open panel and card); 0 = off. */
    public static double fadeLeftOf;
    /** Top / left / right face colours of real blocks. */
    private static final int[][] PALETTES = {
            {0xFF7CBF4A, 0xFF8A6642, 0xFF6E5034},  // grass
            {0xFF8FF3EC, 0xFF3FB8B0, 0xFF2E8C86},  // diamond
            {0xFFFFE15A, 0xFFE0B22E, 0xFFB88A1E},  // gold
            {0xFFCDA8FF, 0xFF9A6FE0, 0xFF7A52BC},  // amethyst
            {0xFFFF6A58, 0xFFD0362C, 0xFFA02620},  // redstone
            {0xFFB8B8B8, 0xFF8E8E8E, 0xFF6E6E6E},  // stone
            {0xFFC9A46C, 0xFF6E5432, 0xFF54402A},  // oak log
            {0xFF6BE08E, 0xFF2FAE5A, 0xFF238A46},  // emerald
    };
    static final java.util.function.Supplier<net.minecraft.world.item.ItemStack[]> BLOCKS = com.google.common.base.Suppliers.memoize(() -> {
        net.minecraft.world.item.Item[] items = {net.minecraft.world.item.Items.GRASS_BLOCK, net.minecraft.world.item.Items.DIAMOND_ORE,
                net.minecraft.world.item.Items.OAK_LOG, net.minecraft.world.item.Items.AMETHYST_BLOCK, net.minecraft.world.item.Items.GOLD_BLOCK,
                net.minecraft.world.item.Items.TNT, net.minecraft.world.item.Items.CRAFTING_TABLE, net.minecraft.world.item.Items.EMERALD_BLOCK,
                net.minecraft.world.item.Items.OBSIDIAN, net.minecraft.world.item.Items.GLASS, net.minecraft.world.item.Items.REDSTONE_BLOCK,
                net.minecraft.world.item.Items.STONE};
        net.minecraft.world.item.ItemStack[] out = new net.minecraft.world.item.ItemStack[items.length];
        for (int i = 0; i < items.length; i++) out[i] = new net.minecraft.world.item.ItemStack(items[i]);
        return out;
    });
    private final Random rand = new Random();
    private String lastStyle = "";

    public void render(Matrix3x2fStack pose, double width, double height, double dt, String style, double fade) {
        if (!style.equals(lastStyle)) {
            list.clear();
            lastStyle = style;
        }
        int target = switch (style) {
            case "Motes" -> 45;
            case "Bubbles" -> 30;
            case "Blocks" -> 14;
            default -> 60;
        };
        while (list.size() < target) list.add(spawn(width, height, style, list.size() < target && list.isEmpty() || rand.nextFloat() < 0.02));

        Theme.Palette pal = Theme.current();
        double time = System.currentTimeMillis() / 1000.0;
        Iterator<P> it = list.iterator();
        while (it.hasNext()) {
            P p = it.next();
            p.x += (p.vx + Math.sin(time * 0.8 + p.phase) * 8) * dt;
            p.y += p.vy * dt;
            p.rot += p.vr * dt;
            boolean gone = style.equals("Petals") ? p.y > height + 12 : style.equals("Blocks") ? p.y > height + 40 : p.y < -12;
            if (gone || p.x < -40 || p.x > width + 40) {
                it.remove();
                continue;
            }
            switch (style) {
                case "Motes" -> {
                    double flicker = 0.45 + 0.55 * Math.abs(Math.sin(time * 1.7 + p.phase));
                    int a = (int) (200 * flicker * fade);
                    Shapes.circleGlow(p.x, p.y, p.size * 0.45, p.size * 2, Theme.withAlpha(pal.accent2(), a / 2));
                    Shapes.circle(p.x, p.y, p.size * 0.45, Theme.withAlpha(Theme.blend(pal.accent2(), 0xFFFFFFFF, 0.6), a));
                }
                case "Blocks" -> {
                    // Little glass blocks in real block colours, tumbling slowly (drawn as shapes, so they never cover the UI).
                    if (exclR > 0 && Math.hypot(p.x - exclX, p.y - exclY) < exclR) break;
                    int[] c = PALETTES[(int) (p.phase * 1000) % PALETTES.length];
                    double al = 0.62 * fade * (fadeLeftOf > 0 ? Math.max(0, Math.min(1, (p.x - fadeLeftOf) / 40)) : 1);
                    if (al <= 0.01) break;
                    pose.pushMatrix();
                    pose.translate((float) p.x, (float) p.y);
                    pose.rotate((float) (p.rot * 0.25));
                    Shapes.isoCube(0, 0, Math.round(p.size * 0.5), Theme.withAlpha(c[0], (int) (230 * al)), Theme.withAlpha(c[1], (int) (220 * al)),
                            Theme.withAlpha(c[2], (int) (220 * al)), Theme.withAlpha(0xFFFFFFFF, (int) (90 * al)));
                    pose.popMatrix();
                }
                case "Bubbles" -> {
                    int a = (int) (120 * fade);
                    Shapes.ring(p.x, p.y, p.size, 0.6, Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.7), a));
                    Shapes.circle(p.x - p.size * 0.35, p.y - p.size * 0.35, p.size * 0.22, Theme.withAlpha(0xFFFFFF, a));
                }
                default -> {
                    int color = Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.4), (int) (170 * fade));
                    pose.pushMatrix();
                    pose.translate((float) p.x, (float) p.y);
                    pose.rotate((float) p.rot);
                    Shapes.roundRect(-p.size * 0.9, -p.size * 0.5, p.size * 1.8, p.size, p.size * 0.5, color);
                    pose.popMatrix();
                }
            }
        }
    }

    private P spawn(double w, double h, String style, boolean anywhere) {
        P p = new P();
        p.x = rand.nextDouble() * w;
        p.phase = rand.nextDouble() * Math.PI * 2;
        p.rot = rand.nextDouble() * Math.PI * 2;
        p.vr = (rand.nextDouble() - 0.5) * 2;
        switch (style) {
            case "Motes" -> {
                p.size = 1.6 + rand.nextDouble() * 2.2;
                p.vx = (rand.nextDouble() - 0.5) * 6;
                p.vy = -(4 + rand.nextDouble() * 10);
                p.y = anywhere ? rand.nextDouble() * h : h + 8;
            }
            case "Bubbles" -> {
                p.size = 2.5 + rand.nextDouble() * 4;
                p.vx = 0;
                p.vy = -(12 + rand.nextDouble() * 18);
                p.y = anywhere ? rand.nextDouble() * h : h + 8;
            }
            case "Blocks" -> {
                p.size = 10 + rand.nextDouble() * 10;
                p.vx = (rand.nextBoolean() ? 1 : -1) * (4 + rand.nextDouble() * 7);
                p.vy = 6 + rand.nextDouble() * 9;
                p.vr = (rand.nextDouble() - 0.5) * 1.2;
                p.y = anywhere ? rand.nextDouble() * h : -30;
            }
            default -> {
                p.size = 2.5 + rand.nextDouble() * 2;
                p.vx = 6 + rand.nextDouble() * 10;
                p.vy = 16 + rand.nextDouble() * 20;
                p.y = anywhere ? rand.nextDouble() * h : -8;
            }
        }
        return p;
    }

    /** Fill the screen immediately instead of waiting for particles to drift in. */
    public void prefill(double w, double h, String style) {
        list.clear();
        lastStyle = style;
        int n = style.equals("Motes") ? 45 : style.equals("Bubbles") ? 30 : style.equals("Blocks") ? 14 : 60;
        for (int i = 0; i < n; i++) list.add(spawn(w, h, style, true));
    }
}
