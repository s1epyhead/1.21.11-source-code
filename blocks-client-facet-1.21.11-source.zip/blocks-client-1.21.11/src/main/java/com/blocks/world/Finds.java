package com.blocks.world;

import com.blocks.render.Gfx;
import com.blocks.render.Projection;
import com.blocks.render.Shapes;
import com.blocks.util.Notifications;
import com.blocks.util.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.phys.Vec3;

import java.util.*;
import java.util.function.Supplier;

/** Everything the finders turned up, with toasts and floating labels. */
public final class Finds {
    public enum Kind {
        STASH("Stash", 0xFFFFB347, () -> Items.CHEST),
        SUS("Sus chunk", 0xFF7CFC6A, () -> Items.KELP),
        TUNNEL("Tunnel", 0xFF59C8FF, () -> Items.IRON_PICKAXE),
        LIGHT("Hidden light", 0xFFFFE066, () -> Items.TORCH),
        ORE("Block", 0xFFFF9F43, () -> Items.ANCIENT_DEBRIS);

        public final String title;
        public final int color;
        private final Supplier<Item> item;
        private ItemStack stack;

        Kind(String title, int color, Supplier<Item> item) {
            this.title = title;
            this.color = color;
            this.item = item;
        }

        public ItemStack icon() {
            if (stack == null) stack = new ItemStack(item.get());
            return stack;
        }
    }

    public record Find(Kind kind, ChunkPos chunk, BlockPos pos, int count, String detail, long time, ItemStack icon) {}

    private static final Minecraft mc = Minecraft.getInstance();
    private static final Map<String, Find> FINDS = new LinkedHashMap<>();
    private static final EnumSet<Kind> LABELLED = EnumSet.noneOf(Kind.class);

    private Finds() {}

    private static String key(Kind kind, ChunkPos chunk) {
        return kind.ordinal() + ":" + com.blocks.compat.Compat.chunkKey(chunk);
    }

    /** Find keyed by an extra tag (e.g. block type), with its own icon. */
    public static void report(Kind kind, String tag, ChunkPos chunk, BlockPos pos, int count, ItemStack icon,
                              String title, String detail, boolean notify) {
        String k = key(kind, chunk) + ":" + tag;
        Find old = FINDS.get(k);
        FINDS.put(k, new Find(kind, chunk, pos, count, detail, old == null ? System.currentTimeMillis() : old.time(), icon));
        if (notify && old == null) {
            Notifications.pushFind(icon, title, detail + "  \u00B7  " + distance(pos) + "m " + direction(pos), kind.color);
        }
    }

    public static void removeTagged(Kind kind, ChunkPos chunk, String tag) {
        FINDS.remove(key(kind, chunk) + ":" + tag);
    }

    /** Record a find; toasts the first time a chunk qualifies (or when it grows a lot). */
    public static void report(Kind kind, ChunkPos chunk, BlockPos pos, int count, String detail, boolean notify) {
        report(kind, chunk, pos, count, kind.title, detail, notify);
    }

    /** As above with a custom toast headline (e.g. "Grown kelp"). */
    public static void report(Kind kind, ChunkPos chunk, BlockPos pos, int count, String title, String detail, boolean notify) {
        String k = key(kind, chunk);
        Find old = FINDS.get(k);
        FINDS.put(k, new Find(kind, chunk, pos, count, detail, old == null ? System.currentTimeMillis() : old.time(), kind.icon()));
        if (notify && (old == null || count >= old.count() * 2 && count - old.count() >= 5)) {
            Notifications.pushFind(kind.icon(), title + (old == null ? "" : " +" + (count - old.count()) + " more"),
                    detail + "  ·  " + distance(pos) + "m " + direction(pos), kind.color);
        }
    }

    public static void remove(Kind kind, ChunkPos chunk) {
        String prefix = key(kind, chunk);
        FINDS.keySet().removeIf(k -> k.equals(prefix) || k.startsWith(prefix + ":"));
    }

    public static void clearKind(Kind kind) {
        FINDS.values().removeIf(f -> f.kind() == kind);
    }

    public static void clear() {
        FINDS.clear();
    }

    public static Collection<Find> all() {
        return FINDS.values();
    }

    public static void setLabels(Kind kind, boolean on) {
        if (on) LABELLED.add(kind);
        else LABELLED.remove(kind);
    }

    public static int distance(BlockPos pos) {
        if (mc.player == null) return 0;
        return (int) Math.round(Math.sqrt(mc.player.distanceToSqr(Vec3.atCenterOf(pos))));
    }

    public static String direction(BlockPos pos) {
        if (mc.player == null) return "";
        double dx = pos.getX() + 0.5 - mc.player.getX(), dz = pos.getZ() + 0.5 - mc.player.getZ();
        double deg = (Math.toDegrees(Math.atan2(dx, -dz)) + 360) % 360; // 0 = north
        String[] dirs = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
        return dirs[(int) Math.round(deg / 45) % 8];
    }

    /** Floating "icon count distance" pills above finds, drawn on the HUD. */
    public static void renderLabels(Gfx g, double uiW, double uiH, float k) {
        if (LABELLED.isEmpty() || mc.player == null) return;
        int gw = g.guiWidth(), gh = g.guiHeight();
        for (Find f : FINDS.values()) {
            if (!LABELLED.contains(f.kind())) continue;
            double[] p = Projection.toGui(Vec3.atCenterOf(f.pos()).add(0, 1.5, 0), gw, gh);
            if (p == null) continue;
            double x = p[0] / k, y = p[1] / k;
            String count = String.valueOf(f.count());
            String dist = (int) p[2] + "m";
            double w = 12 + g.width(count) + 5 + g.widthMono(dist, 0.75f) + 8, h = 13;
            double bx = x - w / 2, by = y - h / 2;
            if (com.blocks.module.visuals.Hud.coveredRight > 0 && bx < com.blocks.module.visuals.Hud.coveredRight) continue;
            Shapes.roundRect(bx, by, w, h, 6.5, Theme.withAlpha(0xFF12121A, 200));
            Shapes.roundOutline(bx, by, w, h, 6.5, 0.8, Theme.withAlpha(f.kind().color, 200));
            g.itemIcon(f.icon(), bx + 7, y, 8, Shapes.scale());
            g.text(count, (int) (bx + 13), (int) (y - 3.5), Theme.TEXT, false);
            g.textMono(dist, bx + 13 + g.width(count) + 5, y - 2.8, Theme.TEXT_DIM, 0.75f);
        }
    }
}
