package com.blocks.world;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;

import java.io.IOException;
import java.nio.file.Path;
import java.util.*;

/**
 * A loaded schematic: Litematica (.litematic), Sponge/WorldEdit (.schem) or vanilla
 * structure (.nbt). Blocks are stored relative to the schematic's minimum corner.
 */
public final class Schematic {
    public final String name;
    public final int sizeX, sizeY, sizeZ;
    /** Non-air blocks, bottom layer first. */
    public final LinkedHashMap<BlockPos, BlockState> blocks;

    private Schematic(String name, int sx, int sy, int sz, Map<BlockPos, BlockState> raw) {
        this.name = name;
        this.sizeX = sx;
        this.sizeY = sy;
        this.sizeZ = sz;
        List<Map.Entry<BlockPos, BlockState>> list = new ArrayList<>(raw.entrySet());
        list.sort(Comparator.<Map.Entry<BlockPos, BlockState>>comparingInt(e -> e.getKey().getY())
                .thenComparingInt(e -> e.getKey().getZ()).thenComparingInt(e -> e.getKey().getX()));
        this.blocks = new LinkedHashMap<>();
        for (var e : list) blocks.put(e.getKey(), e.getValue());
    }

    public static Schematic load(Path file) throws IOException {
        CompoundTag root = NbtIo.readCompressed(file, NbtAccounter.unlimitedHeap());
        String fileName = file.getFileName().toString();
        String name = fileName.contains(".") ? fileName.substring(0, fileName.lastIndexOf('.')) : fileName;
        String lower = fileName.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".litematic")) return litematic(root, name);
        if (lower.endsWith(".schem") || lower.endsWith(".schematic")) return sponge(root, name);
        return structure(root, name);
    }

    // ------------------------------------------------------------------ formats

    /** Vanilla structure block files. */
    private static Schematic structure(CompoundTag root, String name) {
        ListTag size = root.getListOrEmpty("size");
        int sx = size.getInt(0).orElse(1), sy = size.getInt(1).orElse(1), sz = size.getInt(2).orElse(1);
        ListTag paletteTag = root.getListOrEmpty("palette");
        if (paletteTag.size() == 0) {
            ListTag palettes = root.getListOrEmpty("palettes");
            if (palettes.size() > 0 && palettes.get(0) instanceof ListTag first) paletteTag = first;
        }
        List<BlockState> palette = new ArrayList<>();
        for (int i = 0; i < paletteTag.size(); i++) palette.add(state(paletteTag.getCompoundOrEmpty(i)));
        Map<BlockPos, BlockState> out = new HashMap<>();
        ListTag blocks = root.getListOrEmpty("blocks");
        for (int i = 0; i < blocks.size(); i++) {
            CompoundTag b = blocks.getCompoundOrEmpty(i);
            ListTag pos = b.getListOrEmpty("pos");
            int idx = b.getIntOr("state", 0);
            if (idx < 0 || idx >= palette.size()) continue;
            BlockState st = palette.get(idx);
            if (st.isAir() || st.is(Blocks.STRUCTURE_VOID)) continue;
            out.put(new BlockPos(pos.getInt(0).orElse(0), pos.getInt(1).orElse(0), pos.getInt(2).orElse(0)), st);
        }
        return new Schematic(name, sx, sy, sz, out);
    }

    /** Sponge schematic v2 and v3 (WorldEdit / FAWE). */
    private static Schematic sponge(CompoundTag root, String name) {
        CompoundTag tag = root.contains("Schematic") ? root.getCompoundOrEmpty("Schematic") : root;
        int w = tag.getIntOr("Width", 0) & 0xFFFF, h = tag.getIntOr("Height", 0) & 0xFFFF, l = tag.getIntOr("Length", 0) & 0xFFFF;
        if (w == 0) w = tag.getShortOr("Width", (short) 0) & 0xFFFF;
        if (h == 0) h = tag.getShortOr("Height", (short) 0) & 0xFFFF;
        if (l == 0) l = tag.getShortOr("Length", (short) 0) & 0xFFFF;
        CompoundTag paletteTag;
        byte[] data;
        if (tag.contains("Blocks")) { // v3
            CompoundTag blocks = tag.getCompoundOrEmpty("Blocks");
            paletteTag = blocks.getCompoundOrEmpty("Palette");
            data = blocks.getByteArray("Data").orElse(new byte[0]);
        } else { // v2
            paletteTag = tag.getCompoundOrEmpty("Palette");
            data = tag.getByteArray("BlockData").orElse(new byte[0]);
        }
        Map<Integer, BlockState> palette = new HashMap<>();
        for (String key : paletteTag.keySet()) palette.put(paletteTag.getIntOr(key, 0), parseStateString(key));
        Map<BlockPos, BlockState> out = new HashMap<>();
        int i = 0, index = 0;
        while (i < data.length) {
            int value = 0, shift = 0;
            byte b;
            do {
                b = data[i++];
                value |= (b & 0x7F) << shift;
                shift += 7;
            } while ((b & 0x80) != 0 && i < data.length);
            BlockState st = palette.get(value);
            if (st != null && !st.isAir()) {
                int y = index / (w * l), rem = index % (w * l), z = rem / w, x = rem % w;
                out.put(new BlockPos(x, y, z), st);
            }
            index++;
        }
        return new Schematic(name, w, h, l, out);
    }

    /** Litematica: every region merged into one, packed long-array block states. */
    private static Schematic litematic(CompoundTag root, String name) {
        CompoundTag regions = root.getCompoundOrEmpty("Regions");
        Map<BlockPos, BlockState> out = new HashMap<>();
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        for (String regionName : regions.keySet()) {
            CompoundTag r = regions.getCompoundOrEmpty(regionName);
            CompoundTag posTag = r.getCompoundOrEmpty("Position"), sizeTag = r.getCompoundOrEmpty("Size");
            int px = posTag.getIntOr("x", 0), py = posTag.getIntOr("y", 0), pz = posTag.getIntOr("z", 0);
            int sx = sizeTag.getIntOr("x", 1), sy = sizeTag.getIntOr("y", 1), sz = sizeTag.getIntOr("z", 1);
            // Negative sizes mean the region extends backwards from its position.
            int ox = sx < 0 ? px + sx + 1 : px, oy = sy < 0 ? py + sy + 1 : py, oz = sz < 0 ? pz + sz + 1 : pz;
            int ax = Math.abs(sx), ay = Math.abs(sy), az = Math.abs(sz);
            ListTag paletteTag = r.getListOrEmpty("BlockStatePalette");
            List<BlockState> palette = new ArrayList<>();
            for (int i = 0; i < paletteTag.size(); i++) palette.add(state(paletteTag.getCompoundOrEmpty(i)));
            long[] packed = r.getLongArray("BlockStates").orElse(new long[0]);
            int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(Math.max(1, palette.size() - 1)));
            long mask = (1L << bits) - 1;
            long volume = (long) ax * ay * az;
            for (long index = 0; index < volume; index++) {
                long startBit = index * bits;
                int startLong = (int) (startBit >> 6), endLong = (int) (((index + 1) * bits - 1) >> 6);
                if (endLong >= packed.length) break;
                int offset = (int) (startBit & 63);
                long value = startLong == endLong ? (packed[startLong] >>> offset) & mask
                        : ((packed[startLong] >>> offset) | (packed[endLong] << (64 - offset))) & mask;
                if (value >= palette.size()) continue;
                BlockState st = palette.get((int) value);
                if (st.isAir()) continue;
                int x = (int) (index % ax), z = (int) ((index / ax) % az), y = (int) (index / ((long) ax * az));
                BlockPos p = new BlockPos(ox + x, oy + y, oz + z);
                out.put(p, st);
                minX = Math.min(minX, p.getX()); minY = Math.min(minY, p.getY()); minZ = Math.min(minZ, p.getZ());
                maxX = Math.max(maxX, p.getX()); maxY = Math.max(maxY, p.getY()); maxZ = Math.max(maxZ, p.getZ());
            }
        }
        if (out.isEmpty()) return new Schematic(name, 1, 1, 1, out);
        Map<BlockPos, BlockState> shifted = new HashMap<>();
        for (var e : out.entrySet()) shifted.put(e.getKey().offset(-minX, -minY, -minZ), e.getValue());
        return new Schematic(name, maxX - minX + 1, maxY - minY + 1, maxZ - minZ + 1, shifted);
    }

    // ------------------------------------------------------------------ helpers

    /** {Name, Properties} to a block state, parsed directly so it behaves the same on every version. */
    private static BlockState state(CompoundTag tag) {
        net.minecraft.resources.Identifier id = net.minecraft.resources.Identifier.tryParse(tag.getStringOr("Name", "minecraft:air"));
        if (id == null) return Blocks.AIR.defaultBlockState();
        var block = BuiltInRegistries.BLOCK.getOptional(id);
        if (block.isEmpty()) return Blocks.AIR.defaultBlockState();
        BlockState st = block.get().defaultBlockState();
        CompoundTag props = tag.getCompoundOrEmpty("Properties");
        for (String key : props.keySet()) {
            var prop = block.get().getStateDefinition().getProperty(key);
            if (prop != null) st = with(st, prop, props.getStringOr(key, ""));
        }
        return st;
    }

    private static <T extends Comparable<T>> BlockState with(BlockState st, net.minecraft.world.level.block.state.properties.Property<T> prop, String value) {
        return prop.getValue(value).map(v -> st.setValue(prop, v)).orElse(st);
    }

    /** "minecraft:oak_stairs[facing=east,half=bottom]" to a block state. */
    static BlockState parseStateString(String s) {
        CompoundTag tag = new CompoundTag();
        int br = s.indexOf('[');
        tag.putString("Name", br < 0 ? s : s.substring(0, br));
        if (br >= 0 && s.endsWith("]")) {
            CompoundTag props = new CompoundTag();
            for (String kv : s.substring(br + 1, s.length() - 1).split(",")) {
                int eq = kv.indexOf('=');
                if (eq > 0) props.putString(kv.substring(0, eq).trim(), kv.substring(eq + 1).trim());
            }
            tag.put("Properties", props);
        }
        return state(tag);
    }

    /** Where a relative block lands for a given origin and rotation (around the schematic's corner). */
    public BlockPos place(BlockPos rel, BlockPos origin, Rotation rot) {
        int x = rel.getX(), z = rel.getZ();
        int rx, rz;
        switch (rot) {
            case CLOCKWISE_90 -> { rx = sizeZ - 1 - z; rz = x; }
            case CLOCKWISE_180 -> { rx = sizeX - 1 - x; rz = sizeZ - 1 - z; }
            case COUNTERCLOCKWISE_90 -> { rx = z; rz = sizeX - 1 - x; }
            default -> { rx = x; rz = z; }
        }
        return origin.offset(rx, rel.getY(), rz);
    }

    /** Item counts needed to build it. */
    public Map<net.minecraft.world.item.Item, Integer> materials() {
        Map<net.minecraft.world.item.Item, Integer> m = new LinkedHashMap<>();
        for (BlockState st : blocks.values()) {
            var item = st.getBlock().asItem();
            if (item == net.minecraft.world.item.Items.AIR) continue;
            m.merge(item, 1, Integer::sum);
        }
        List<Map.Entry<net.minecraft.world.item.Item, Integer>> list = new ArrayList<>(m.entrySet());
        list.sort((a, b) -> b.getValue() - a.getValue());
        LinkedHashMap<net.minecraft.world.item.Item, Integer> sorted = new LinkedHashMap<>();
        for (var e : list) sorted.put(e.getKey(), e.getValue());
        return sorted;
    }
}
