package com.blocks.world;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.LevelChunk;

import java.util.*;

/**
 * Feeds loaded chunks to the finder modules a few at a time (time-budgeted per
 * tick, nearest first) so base hunting never stalls your frame rate.
 */
public final class ChunkScanner {
    public interface Scanner {
        boolean active();

        void scan(LevelChunk chunk);

        void forget(ChunkPos pos);

        default void clear() {}
    }

    private static final Minecraft mc = Minecraft.getInstance();
    private static final List<Scanner> SCANNERS = new ArrayList<>();
    private static final LinkedHashSet<Long> QUEUE = new LinkedHashSet<>();
    private static final long BUDGET_NANOS = 2_500_000L;
    private static ClientLevel lastLevel;
    private static final Set<Scanner> REPORTED = new HashSet<>();
    private static final LinkedHashSet<Long> DIRTY = new LinkedHashSet<>();

    private ChunkScanner() {}

    public static void register(Scanner s) {
        SCANNERS.add(s);
    }

    public static void init() {
        ClientChunkEvents.CHUNK_LOAD.register((level, chunk) -> {
            if (anyActive()) QUEUE.add(com.blocks.compat.Compat.chunkKey(chunk.getPos()));
        });
        ClientChunkEvents.CHUNK_UNLOAD.register((level, chunk) -> {
            QUEUE.remove(com.blocks.compat.Compat.chunkKey(chunk.getPos()));
            for (Scanner s : SCANNERS) s.forget(chunk.getPos());
        });
    }

    /** A block changed (placed, mined, or revealed by the server's anti-xray): rescan its chunk next tick. */
    public static void blockChanged(net.minecraft.core.BlockPos pos) {
        if (!anyActive()) return;
        DIRTY.add(com.blocks.compat.Compat.chunkKey(pos.getX() >> 4, pos.getZ() >> 4));
    }

    private static boolean anyActive() {
        for (Scanner s : SCANNERS) if (s.active()) return true;
        return false;
    }

    /** Re-queue every loaded chunk around the player, nearest first (used when a finder is switched on). */
    public static void rescan() {
        if (mc.player == null || mc.level == null) return;
        int r = mc.options.renderDistance().get() + 1;
        int px = com.blocks.compat.Compat.chunkX(mc.player.chunkPosition()), pz = com.blocks.compat.Compat.chunkZ(mc.player.chunkPosition());
        List<long[]> list = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                if (mc.level.hasChunk(px + dx, pz + dz)) list.add(new long[]{com.blocks.compat.Compat.chunkKey(px + dx, pz + dz), dx * dx + dz * dz});
            }
        }
        list.sort(Comparator.comparingLong(a -> a[1]));
        // Nearest chunks go to the front, even if they were already queued further back.
        LinkedHashSet<Long> rest = new LinkedHashSet<>(QUEUE);
        QUEUE.clear();
        for (long[] e : list) QUEUE.add(e[0]);
        QUEUE.addAll(rest);
    }

    public static void tick() {
        if (mc.level != lastLevel) {
            lastLevel = mc.level;
            QUEUE.clear();
            DIRTY.clear();
            for (Scanner s : SCANNERS) s.clear();
            Finds.clear();
            if (mc.level != null) rescan();
        }
        if (mc.level == null) return;
        if (!DIRTY.isEmpty()) {
            // Block changes from the last tick: rescan just those chunks (deduplicated).
            LinkedHashSet<Long> rest = new LinkedHashSet<>(QUEUE);
            rest.removeAll(DIRTY);
            QUEUE.clear();
            QUEUE.addAll(DIRTY);
            QUEUE.addAll(rest);
            DIRTY.clear();
        }
        if (QUEUE.isEmpty()) return;
        List<Scanner> active = new ArrayList<>();
        for (Scanner s : SCANNERS) if (s.active()) active.add(s);
        if (active.isEmpty()) {
            QUEUE.clear();
            return;
        }
        long start = System.nanoTime();
        Iterator<Long> it = QUEUE.iterator();
        while (it.hasNext() && System.nanoTime() - start < BUDGET_NANOS) {
            long key = it.next();
            it.remove();
            int x = (int) key, z = (int) (key >>> 32);
            if (!mc.level.hasChunk(x, z)) continue;
            LevelChunk chunk = mc.level.getChunk(x, z);
            for (Scanner s : active) {
                try {
                    s.scan(chunk);
                } catch (Exception e) {
                    if (REPORTED.add(s)) com.blocks.BlocksClient.LOG.error("Chunk scan failed in {}", s.getClass().getSimpleName(), e);
                }
            }
        }
    }
}
