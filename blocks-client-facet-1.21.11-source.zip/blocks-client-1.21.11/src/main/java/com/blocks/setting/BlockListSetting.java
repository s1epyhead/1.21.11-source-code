package com.blocks.setting;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Block;

import java.util.LinkedHashSet;
import java.util.Set;

/** A set of blocks, edited with the block picker in the menu. */
public class BlockListSetting extends Setting {
    private final Set<Block> blocks = new LinkedHashSet<>();
    private int version;

    public BlockListSetting(String name, Block... defaults) {
        super(name);
        for (Block b : defaults) blocks.add(b);
    }

    public Set<Block> get() {
        return blocks;
    }

    public boolean contains(Block b) {
        return blocks.contains(b);
    }

    public void toggle(Block b) {
        if (!blocks.remove(b)) blocks.add(b);
        version++;
    }

    public void clear() {
        blocks.clear();
        version++;
    }

    /** Bumped on every change so scanners know to re-scan. */
    public int version() {
        return version;
    }

    @Override
    public JsonElement toJson() {
        JsonArray arr = new JsonArray();
        for (Block b : blocks) arr.add(BuiltInRegistries.BLOCK.getKey(b).toString());
        return arr;
    }

    @Override
    public void fromJson(JsonElement json) {
        if (!json.isJsonArray()) return;
        blocks.clear();
        for (JsonElement e : json.getAsJsonArray()) {
            Identifier id = Identifier.tryParse(e.getAsString());
            if (id == null) continue;
            BuiltInRegistries.BLOCK.getOptional(id).ifPresent(blocks::add);
        }
        version++;
    }
}
