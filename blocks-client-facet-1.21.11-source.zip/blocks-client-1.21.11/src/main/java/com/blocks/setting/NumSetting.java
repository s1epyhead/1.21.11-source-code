package com.blocks.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class NumSetting extends Setting {
    private final double min, max, step;
    private double value;

    public NumSetting(String name, double value, double min, double max, double step) {
        super(name);
        this.min = min;
        this.max = max;
        this.step = step;
        set(value);
    }

    public double get() {
        return value;
    }

    public int getInt() {
        return (int) Math.round(value);
    }

    public float getFloat() {
        return (float) value;
    }

    public void set(double v) {
        v = Math.max(min, Math.min(max, v));
        v = Math.round(v / step) * step;
        // Trim floating point noise like 4.499999999.
        value = Math.round(v * 1000.0) / 1000.0;
    }

    /** Sets the value from a 0..1 slider position. */
    public void setPercent(double pct) {
        set(min + (max - min) * Math.max(0, Math.min(1, pct)));
    }

    public double getPercent() {
        return (value - min) / (max - min);
    }

    public String display() {
        if (step >= 1) return String.valueOf(getInt());
        if (step >= 0.1) return String.format("%.1f", value);
        return String.format("%.2f", value);
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(value);
    }

    @Override
    public void fromJson(JsonElement json) {
        if (json.isJsonPrimitive()) set(json.getAsDouble());
    }
}
