package com.blocks.setting;

import com.google.gson.JsonElement;

import java.util.function.BooleanSupplier;

public abstract class Setting {
    private final String name;
    private BooleanSupplier visible = () -> true;

    protected Setting(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    /** Hide this setting in the GUI unless the condition holds (e.g. only show in one mode). */
    @SuppressWarnings("unchecked")
    public <T extends Setting> T visibleWhen(BooleanSupplier condition) {
        this.visible = condition;
        return (T) this;
    }

    public boolean isVisible() {
        return visible.getAsBoolean();
    }

    public abstract JsonElement toJson();

    public abstract void fromJson(JsonElement json);
}
