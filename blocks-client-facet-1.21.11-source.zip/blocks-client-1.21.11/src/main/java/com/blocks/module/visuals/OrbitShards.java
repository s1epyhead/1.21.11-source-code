package com.blocks.module.visuals;

import com.blocks.BlocksClient;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.render.World3D;
import com.blocks.setting.NumSetting;
import com.blocks.util.Theme;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Glowing ice-crystal shards circling your target, bobbing and spinning. Blatant; off by default. */
public class OrbitShards extends Module {
    private final NumSetting count = add(new NumSetting("Shards", 4, 2, 8, 1));
    private final NumSetting size = add(new NumSetting("Size", 1.0, 0.4, 2, 0.05));
    private final NumSetting speed = add(new NumSetting("Speed", 1.0, 0.2, 3, 0.1));

    public OrbitShards() {
        super("Orbit Shards", "Ice crystal shards circling your target (blatant)", Category.VISUALS);
    }

    @Override
    public void onWorldRender() {
        Player t = BlocksClient.getTarget();
        if (t == null || !t.isAlive()) return;
        Vec3 base = World3D.lerpPos(t);
        double time = System.currentTimeMillis() / 1000.0 * speed.get();
        int n = count.getInt();
        for (int i = 0; i < n; i++) {
            double a = time * 0.9 + Math.PI * 2 * i / n;
            double y = t.getBbHeight() * 0.55 + Math.sin(time * 1.6 + i * 2.1) * 0.35;
            Vec3 c = base.add(Math.cos(a) * 1.15, y, Math.sin(a) * 1.15);
            shard(c, 0.42 * size.get(), 0.13 * size.get(), time * 1.4 + i);
        }
    }

    /** An elongated octahedron: two pyramids back to back. */
    private void shard(Vec3 c, double half, double r, double spin) {
        Vec3 top = c.add(0, half, 0), bot = c.add(0, -half, 0);
        Vec3[] eq = new Vec3[4];
        for (int k = 0; k < 4; k++) eq[k] = c.add(Math.cos(spin + k * Math.PI / 2) * r, 0, Math.sin(spin + k * Math.PI / 2) * r);
        int fillTop = Theme.withAlpha(0xFFBFEFFF, 120), fillBot = Theme.withAlpha(Theme.blend(Theme.current().accent(), 0xFF7FD4FF, 0.6), 90);
        int edge = Theme.withAlpha(0xFFFFFFFF, 220);
        for (int k = 0; k < 4; k++) {
            Vec3 a = eq[k], b = eq[(k + 1) % 4];
            World3D.quad(top, top, b, a, fillTop, fillTop, fillBot, fillBot);
            World3D.quad(a, b, top, top, fillBot, fillBot, fillTop, fillTop);
            World3D.quad(bot, bot, a, b, fillBot, fillBot, fillBot, fillBot);
            World3D.quad(b, a, bot, bot, fillBot, fillBot, fillBot, fillBot);
            World3D.line(top, a, edge, edge, 1.4f);
            World3D.line(bot, a, edge, edge, 1.4f);
            World3D.line(a, b, edge, edge, 1.4f);
        }
    }
}
