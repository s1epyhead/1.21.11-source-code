package com.blocks.module.combat;

import com.blocks.mixin.MinecraftAccessor;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.ModeSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.InvUtil;
import com.blocks.util.Theme;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Surround keeps obsidian around your feet (and re-places it when blown up);
 * Platform and Wall build once and switch off.
 */
public class Surround extends Module {
    private final ModeSetting shape = add(new ModeSetting("Shape", "Surround", "Surround", "Platform", "Wall"));
    private final ModeSetting block = add(new ModeSetting("Block", "Obsidian", "Obsidian", "Cobblestone", "Held"));
    private final NumSetting perTick = add(new NumSetting("Blocks Per Tick", 2, 1, 6, 1));
    private final BoolSetting disableOnMove = add(new BoolSetting("Stop When You Move", true)).visibleWhen(() -> shape.is("Surround"));

    private BlockPos anchor;
    private Direction facing;
    private int idle;

    public Surround() {
        super("Surround", "Obsidian around your feet, or a quick platform or wall", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        anchor = mc.player.blockPosition();
        facing = mc.player.getDirection();
        idle = 0;
    }

    @Override
    public String getSuffix() {
        return shape.get();
    }

    private List<BlockPos> targets() {
        List<BlockPos> list = new ArrayList<>();
        switch (shape.get()) {
            case "Surround" -> {
                if (mc.level.getBlockState(anchor.below()).canBeReplaced()) list.add(anchor.below());
                for (Direction d : Direction.Plane.HORIZONTAL) list.add(anchor.relative(d));
            }
            case "Platform" -> {
                for (int x = -2; x <= 2; x++) for (int z = -2; z <= 2; z++) list.add(anchor.offset(x, -1, z));
            }
            default -> {
                BlockPos centre = anchor.relative(facing, 2);
                Direction side = facing.getClockWise();
                for (int y = 0; y < 3; y++) for (int s = -2; s <= 2; s++) list.add(centre.relative(side, s).above(y));
            }
        }
        // Bottom up and nearest first, so every block has something to stand on.
        list.sort(Comparator.<BlockPos>comparingInt(BlockPos::getY).thenComparingDouble(p -> p.distSqr(anchor)));
        return list;
    }

    private int blockSlot() {
        return switch (block.get()) {
            case "Obsidian" -> InvUtil.findHotbar(s -> s.is(Items.OBSIDIAN));
            case "Cobblestone" -> InvUtil.findHotbar(s -> s.is(Items.COBBLESTONE) || s.is(Items.COBBLED_DEEPSLATE));
            default -> mc.player.getMainHandItem().getItem() instanceof BlockItem ? InvUtil.selected() : -1;
        };
    }

    @Override
    public void onTick() {
        if (shape.is("Surround") && disableOnMove.get() && !mc.player.blockPosition().equals(anchor)) {
            setEnabled(false);
            return;
        }
        int slot = blockSlot();
        if (slot == -1) {
            setEnabled(false);
            return;
        }
        int placed = 0, missing = 0;
        int prev = InvUtil.selected();
        for (BlockPos p : targets()) {
            if (!mc.level.getBlockState(p).canBeReplaced()) continue;
            missing++;
            if (placed >= perTick.getInt()) continue;
            if (!mc.level.getEntitiesOfClass(net.minecraft.world.entity.LivingEntity.class, new AABB(p)).isEmpty()) continue;
            BlockHitResult hit = against(p);
            if (hit == null) continue;
            InvUtil.select(slot);
            InvUtil.useOn(hit, InteractionHand.MAIN_HAND);
            placed++;
        }
        if (placed > 0) {
            ((MinecraftAccessor) mc).blocks$setRightClickDelay(2);
            InvUtil.select(prev);
            idle = 0;
        } else if (!shape.is("Surround") && (missing == 0 || ++idle > 20)) {
            setEnabled(false);
        }
    }

    private BlockHitResult against(BlockPos target) {
        for (Direction d : new Direction[]{Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP}) {
            BlockPos support = target.relative(d);
            if (mc.level.getBlockState(support).canBeReplaced()) continue;
            Direction face = d.getOpposite();
            Vec3 v = Vec3.atCenterOf(support).add(face.getStepX() * 0.5, face.getStepY() * 0.5, face.getStepZ() * 0.5);
            if (mc.player.getEyePosition().distanceTo(v) > 5) continue;
            return new BlockHitResult(v, face, support, false);
        }
        return null;
    }

    @Override
    public void onWorldRender() {
        if (anchor == null) return;
        for (BlockPos p : targets()) {
            if (!mc.level.getBlockState(p).canBeReplaced()) continue;
            World3D.boxLines(new AABB(p).deflate(0.05), Theme.withAlpha(Theme.accent(), 150), 1.5f);
        }
    }
}
