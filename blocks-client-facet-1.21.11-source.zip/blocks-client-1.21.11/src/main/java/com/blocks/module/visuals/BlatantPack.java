package com.blocks.module.visuals;

import com.blocks.BlocksClient;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.ModeSetting;
import com.blocks.setting.Setting;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * One switch for the full blatant look: glass chams, aura spikes, orbit shards, the rune
 * circle with orbit arc and hitbox, a China hat on your target, trails, jump ripples and
 * the sleek status bars. Turning it off puts everything back exactly how it was.
 */
public class BlatantPack extends Module {
    private final Map<Module, Boolean> before = new HashMap<>();
    private final Map<Setting, String> beforeSettings = new HashMap<>();

    public BlatantPack() {
        super("Blatant Pack", "Turns on the full blatant PvP look in one go (and back off)", Category.VISUALS);
    }

    private static final List<Class<? extends Module>> PACK = List.of(Chams.class, AuraSpikes.class, OrbitShards.class,
            TargetEsp.class, SunHat.class, Trails.class, JumpCircles.class, StatusBars.class, HitParticles.class, Nametags.class, TargetHud.class);

    @Override
    protected void onEnable() {
        before.clear();
        beforeSettings.clear();
        for (Class<? extends Module> c : PACK) {
            Module m = BlocksClient.modules.get(c);
            before.put(m, m.isEnabled());
            if (!m.isEnabled()) m.setEnabled(true);
        }
        set(TargetEsp.class, "Style", "Both");
        set(TargetEsp.class, "Orbit Arc", "true");
        set(TargetEsp.class, "Hitbox", "true");
        set(SunHat.class, "Style", "China");
        set(SunHat.class, "Wearers", "You + Target");
        set(Trails.class, "Who", "You + Target");
        set(HitParticles.class, "Style", "Hearts");
        set(Chams.class, "Glass", "true");
    }

    private void set(Class<? extends Module> c, String name, String value) {
        for (Setting s : BlocksClient.modules.get(c).getSettings()) {
            if (!s.getName().equals(name)) continue;
            if (s instanceof ModeSetting m) {
                beforeSettings.put(s, m.get());
                m.set(value);
            } else if (s instanceof BoolSetting b) {
                beforeSettings.put(s, String.valueOf(b.get()));
                b.set(Boolean.parseBoolean(value));
            }
        }
    }

    @Override
    protected void onDisable() {
        for (var e : beforeSettings.entrySet()) {
            if (e.getKey() instanceof ModeSetting m) m.set(e.getValue());
            else if (e.getKey() instanceof BoolSetting b) b.set(Boolean.parseBoolean(e.getValue()));
        }
        for (var e : before.entrySet()) if (!e.getValue() && e.getKey().isEnabled()) e.getKey().setEnabled(false);
        before.clear();
        beforeSettings.clear();
    }
}
