package com.blocks.module.combat;

import com.blocks.module.Category;
import com.blocks.module.Module;

/** Jumps the tick you take a hit, which cuts the knockback you receive. */
public class AutoJumpReset extends Module {
    public AutoJumpReset() {
        super("Auto Jump Reset", "Jumps on hit to reduce knockback", Category.COMBAT);
    }

    @Override
    public void onTick() {
        // hurtTime is set to 10 when damaged and counts down each tick.
        if (mc.player.hurtTime == 9 && mc.player.onGround() && !mc.player.isInWater()) {
            mc.player.jumpFromGround();
        }
    }
}
