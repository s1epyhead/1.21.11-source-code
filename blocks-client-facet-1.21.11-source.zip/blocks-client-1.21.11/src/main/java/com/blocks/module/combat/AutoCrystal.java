package com.blocks.module.combat;

import com.blocks.compat.Compat;
import com.blocks.mixin.MinecraftAccessor;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.CombatUtil;
import com.blocks.util.InvUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

import java.util.List;

/**
 * Hold right click with crystals: places on the obsidian/bedrock you look at and
 * breaks the crystal you look at (or the one sitting on that block), each on its
 * own delay.
 */
public class AutoCrystal extends Module {
    private final NumSetting placeDelay = add(new NumSetting("Place Delay", 50, 0, 500, 25));
    private final NumSetting breakDelay = add(new NumSetting("Break Delay", 50, 0, 500, 25));
    private final BoolSetting holdRightClick = add(new BoolSetting("Hold Right Click", true));
    private final BoolSetting place = add(new BoolSetting("Place", true));
    private final BoolSetting breakCrystals = add(new BoolSetting("Break", true));
    private final BoolSetting antiSuicide = add(new BoolSetting("Anti Suicide", false));

    private long lastPlace, lastBreak;

    public AutoCrystal() {
        super("Auto Crystal", "Hold right click: places and breaks crystals where you look", Category.COMBAT);
    }

    private InteractionHand crystalHand() {
        if (mc.player.getMainHandItem().is(Items.END_CRYSTAL)) return InteractionHand.MAIN_HAND;
        if (mc.player.getOffhandItem().is(Items.END_CRYSTAL)) return InteractionHand.OFF_HAND;
        return null;
    }

    @Override
    public void onTick() {
        if (Compat.screen() != null) return;
        InteractionHand hand = crystalHand();
        if (hand == null) return;
        if (holdRightClick.get() && !mc.options.keyUse.isDown()) return;
        // Keep vanilla's own right click from double-placing while we drive it.
        ((MinecraftAccessor) mc).blocks$setRightClickDelay(4);

        long now = System.currentTimeMillis();
        HitResult hit = mc.hitResult;
        EndCrystal crystal = null;
        BlockHitResult blockHit = null;
        if (hit instanceof EntityHitResult ehr && ehr.getEntity() instanceof EndCrystal c) {
            crystal = c;
        } else if (hit instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
            blockHit = bhr;
            crystal = crystalOn(bhr.getBlockPos());
        }

        if (crystal != null) {
            if (breakCrystals.get() && now - lastBreak >= breakDelay.get() && !suicidal(crystal)) {
                InvUtil.attack(crystal);
                lastBreak = now;
            }
            return;
        }
        if (blockHit != null && place.get() && now - lastPlace >= placeDelay.get()
                && CombatUtil.canPlaceCrystal(blockHit.getBlockPos())) {
            InvUtil.useOn(blockHit, hand);
            lastPlace = now;
        }
    }

    private EndCrystal crystalOn(BlockPos base) {
        BlockPos up = base.above();
        List<EndCrystal> list = mc.level.getEntitiesOfClass(EndCrystal.class,
                new AABB(up.getX(), up.getY(), up.getZ(), up.getX() + 1, up.getY() + 2, up.getZ() + 1));
        return list.isEmpty() ? null : list.get(0);
    }

    private boolean suicidal(EndCrystal crystal) {
        return antiSuicide.get() && CombatUtil.crystalDamage(crystal.position(), mc.player) >= CombatUtil.health(mc.player);
    }

    @Override
    public String getSuffix() {
        return placeDelay.getInt() + "/" + breakDelay.getInt() + "ms";
    }
}
