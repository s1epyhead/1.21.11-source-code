package com.blocks.module.world;

import com.blocks.BlocksClient;
import com.blocks.compat.Compat;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.module.client.ClickGui;
import com.blocks.render.Gfx;
import com.blocks.render.Shapes;
import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.ModeSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.InvUtil;
import com.blocks.util.Notifications;
import com.blocks.util.Theme;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;

/**
 * Area miner and tunneller, built to run while you're away.
 *
 * Regions are bounds, iterated lazily. Mining goes layer by layer from the top, sweeping
 * each layer in a serpentine from one corner, so the floor under you is always intact.
 * One block at a time: aim at it, break it with vanilla's own progress (tool, Efficiency
 * and Haste all count), then the next. Fluids are plugged, skipped or stop the job, and
 * the fastest safe tool is picked for every block.
 *
 * Travel mode digs a 1x2 tunnel (with stairs) to a target, used by Base Hunter.
 */
public class AutoMine extends Module {
    private final ModeSetting mode = add(new ModeSetting("Mode", "Strip", "Strip", "Layers", "Corners", "Radius", "Mine To Y", "Tunnel", "Travel"));
    // Strip: rows of a 2-high tunnel, mined bottom block then top block, snaking back and forth.
    private final NumSetting stripLength = add(new NumSetting("Row Length", 16, 2, 128, 1)).visibleWhen(() -> mode.is("Strip"));
    private final NumSetting stripRows = add(new NumSetting("Rows", 4, 1, 64, 1)).visibleWhen(() -> mode.is("Strip"));
    private final NumSetting stripGap = add(new NumSetting("Row Spacing", 1, 1, 6, 1)).visibleWhen(() -> mode.is("Strip"));
    private final ModeSetting stripSide = add(new ModeSetting("Rows Go", "Right", "Right", "Left")).visibleWhen(() -> mode.is("Strip"));
    private final NumSetting stripDelay = add(new NumSetting("Step Delay", 2, 0, 20, 1)).visibleWhen(() -> mode.is("Strip"));
    private final BoolSetting sneakWalk = add(new BoolSetting("Sneak While Walking", true)).visibleWhen(() -> mode.is("Strip"));
    private final NumSetting width = add(new NumSetting("Width", 16, 2, 64, 1)).visibleWhen(() -> mode.is("Layers"));
    private final NumSetting length = add(new NumSetting("Length", 16, 2, 64, 1)).visibleWhen(() -> mode.is("Layers"));
    private final NumSetting depth = add(new NumSetting("Depth", 4, 1, 64, 1)).visibleWhen(() -> mode.is("Layers") || mode.is("Radius"));
    private final NumSetting radius = add(new NumSetting("Radius", 6, 1, 32, 1)).visibleWhen(() -> mode.is("Radius") || mode.is("Mine To Y"));
    private final NumSetting targetY = add(new NumSetting("Target Y", -50, -64, 320, 1)).visibleWhen(() -> mode.is("Mine To Y"));
    private final ModeSetting tunnel = add(new ModeSetting("Tunnel Size", "1x2", "1x2", "3x3")).visibleWhen(() -> mode.is("Tunnel"));
    private final NumSetting reach = add(new NumSetting("Reach", 4.5, 3, 5, 0.1));
    private final BoolSetting walk = add(new BoolSetting("Walk", true));
    private final ModeSetting fluids = add(new ModeSetting("Fluids", "Plug", "Plug", "Skip", "Stop"));
    private final ModeSetting ores = add(new ModeSetting("Ores", "Mine", "Mine", "Skip"));
    private final BoolSetting skipObsidian = add(new BoolSetting("Skip Obsidian", true));
    private final BoolSetting skipDebris = add(new BoolSetting("Skip Debris", false));
    private final BoolSetting autoTool = add(new BoolSetting("Auto Tool", true));
    private final NumSetting saveTools = add(new NumSetting("Save Tools At", 12, 0, 100, 1));
    private final ModeSetting whenFull = add(new ModeSetting("When Full", "Drop Junk", "Drop Junk", "Stop"));
    private final NumSetting minHealth = add(new NumSetting("Min Health", 8, 1, 20, 1));

    public BlockPos corner1, corner2;
    private Direction forward = Direction.NORTH;
    private int minX, maxX, minY, maxY, minZ, maxZ;
    private int layerY, total, mined;
    private boolean sweptOnce;
    private BlockPos target, travelTarget;
    private BlockState targetState;
    private final Set<BlockPos> skipped = new HashSet<>();
    private long startedAt;
    private String status = "";
    private boolean mining;
    private int stuckTicks, detourTicks;
    private final java.util.List<BlockPos> path = new java.util.ArrayList<>();
    private int pathIdx, stepWait, walkTicks;
    private Direction detour;

    public AutoMine() {
        super("Auto Mine", "Clears a region top-down or tunnels to a target, safely", Category.WORLD);
    }

    // ------------------------------------------------------------------ region selection

    private BlockPos lookedAt() {
        return mc.hitResult instanceof BlockHitResult b && mc.hitResult.getType() == net.minecraft.world.phys.HitResult.Type.BLOCK
                ? b.getBlockPos() : mc.player == null ? null : mc.player.blockPosition().below();
    }

    public void setCorner1() {
        corner1 = lookedAt();
        mode.set("Corners");
    }

    public void setCorner2() {
        corner2 = lookedAt();
        mode.set("Corners");
    }

    public void clearCorners() {
        corner1 = corner2 = null;
    }

    public String regionText() {
        if (corner1 == null && corner2 == null) return "No corners set";
        String a = corner1 == null ? "?" : corner1.getX() + " " + corner1.getY() + " " + corner1.getZ();
        String b = corner2 == null ? "?" : corner2.getX() + " " + corner2.getY() + " " + corner2.getZ();
        if (corner1 != null && corner2 != null) {
            int n = (Math.abs(corner1.getX() - corner2.getX()) + 1) * (Math.abs(corner1.getY() - corner2.getY()) + 1) * (Math.abs(corner1.getZ() - corner2.getZ()) + 1);
            return a + "  ->  " + b + "  (" + n + ")";
        }
        return a + "  ->  " + b;
    }

    /** Starts a tunnel to a target (Base Hunter). */
    public void travelTo(BlockPos pos) {
        travelTarget = pos;
        mode.set("Travel");
        if (isEnabled()) onEnable();
        else setEnabled(true);
    }

    public BlockPos travelTarget() {
        return travelTarget;
    }

    public boolean isMining() {
        return isEnabled() && mining;
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onEnable() {
        forward = mc.player.getDirection();
        BlockPos s = mc.player.blockPosition();
        mined = 0;
        startedAt = System.currentTimeMillis();
        target = null;
        skipped.clear();
        sweptOnce = false;
        stuckTicks = detourTicks = 0;
        status = "Starting";
        path.clear();
        pathIdx = 0;
        stepWait = 0;
        walkTicks = 0;
        switch (mode.get()) {
            case "Strip" -> {
                // Cells (feet positions) in order: row after row, alternating direction, joined at the ends.
                Direction side = stripSide.is("Left") ? forward.getCounterClockWise() : forward.getClockWise();
                int len = stripLength.getInt(), rows = stripRows.getInt(), gap = stripGap.getInt();
                for (int row = 0; row < rows; row++) {
                    BlockPos rowStart = s.relative(side, row * gap);
                    boolean fwd = row % 2 == 0;
                    for (int i = 0; i < len; i++) path.add(rowStart.relative(forward, fwd ? i : len - 1 - i).immutable());
                    if (row < rows - 1) {
                        BlockPos end = rowStart.relative(forward, fwd ? len - 1 : 0);
                        for (int j = 1; j < gap; j++) path.add(end.relative(side, j).immutable());
                    }
                }
                total = path.size() * 2;
                int x0 = Integer.MAX_VALUE, x1 = Integer.MIN_VALUE, z0 = Integer.MAX_VALUE, z1 = Integer.MIN_VALUE;
                for (BlockPos c : path) {
                    x0 = Math.min(x0, c.getX());
                    x1 = Math.max(x1, c.getX());
                    z0 = Math.min(z0, c.getZ());
                    z1 = Math.max(z1, c.getZ());
                }
                bounds(x0, x1, s.getY(), s.getY() + 1, z0, z1);
            }
            case "Layers" -> {
                Direction right = forward.getClockWise();
                BlockPos far = s.relative(forward, length.getInt() - 1).relative(right, width.getInt() - 1);
                bounds(s.getX(), far.getX(), s.getY() + 1 - depth.getInt() + 1, s.getY() + 1, s.getZ(), far.getZ());
            }
            case "Corners" -> {
                if (corner1 == null || corner2 == null) {
                    stop("Set both corners first (in Auto Mine's settings)");
                    return;
                }
                bounds(corner1.getX(), corner2.getX(), Math.min(corner1.getY(), corner2.getY()), Math.max(corner1.getY(), corner2.getY()), corner1.getZ(), corner2.getZ());
            }
            case "Radius" -> {
                int r = radius.getInt();
                bounds(s.getX() - r, s.getX() + r, s.getY() + 1 - depth.getInt() + 1, s.getY() + 1, s.getZ() - r, s.getZ() + r);
            }
            case "Mine To Y" -> {
                int r = radius.getInt();
                bounds(s.getX() - r, s.getX() + r, Math.min(targetY.getInt(), s.getY()), s.getY() + 1, s.getZ() - r, s.getZ() + r);
            }
            case "Travel" -> {
                if (travelTarget == null) {
                    stop("No target: use Base Hunter to pick one");
                    return;
                }
            }
            default -> {
            }
        }
        layerY = maxY;
        total = 0;
        if (!mode.is("Tunnel") && !mode.is("Travel") && !mode.is("Strip")) {
            for (BlockPos p : BlockPos.betweenClosed(minX, minY, minZ, maxX, maxY, maxZ)) if (mineable(p)) total++;
        }
    }

    private void bounds(int x0, int x1, int y0, int y1, int z0, int z1) {
        minX = Math.min(x0, x1);
        maxX = Math.max(x0, x1);
        minY = Math.max(mc.level.getMinY(), Math.min(y0, y1));
        maxY = Math.max(y0, y1);
        minZ = Math.min(z0, z1);
        maxZ = Math.max(z0, z1);
    }

    @Override
    protected void onDisable() {
        mc.options.keyUp.setDown(false);
        mc.options.keyJump.setDown(false);
        mc.options.keyShift.setDown(false);
        mining = false;
        if (mc.gameMode != null) mc.gameMode.stopDestroyBlock();
        target = null;
    }

    private void stop(String reason) {
        Notifications.push("Auto Mine", reason, false);
        setEnabled(false);
    }

    // ------------------------------------------------------------------ filters

    private boolean mineable(BlockPos p) {
        BlockState s = mc.level.getBlockState(p);
        if (s.isAir() || !s.getFluidState().isEmpty() || s.is(Blocks.BEDROCK) || s.getDestroySpeed(mc.level, p) < 0) return false;
        if (skipObsidian.get() && (s.is(Blocks.OBSIDIAN) || s.is(Blocks.CRYING_OBSIDIAN))) return false;
        if (skipDebris.get() && s.is(Blocks.ANCIENT_DEBRIS)) return false;
        if (ores.is("Skip") && isOre(s)) return false;
        return !skipped.contains(p);
    }

    private static boolean isOre(BlockState s) {
        String id = net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(s.getBlock()).getPath();
        return id.endsWith("_ore") || id.equals("ancient_debris");
    }

    private boolean isFluid(BlockPos p) {
        return !mc.level.getFluidState(p).isEmpty();
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void onTick() {
        mining = false;
        if (mc.player.getHealth() <= minHealth.get()) {
            stop("Stopped: health low");
            return;
        }
        if (mc.player.getInventory().getFreeSlot() == -1 && !handleFull()) return;
        switch (mode.get()) {
            case "Strip" -> tickStrip();
            case "Tunnel" -> tickTunnel(forward, 0);
            case "Travel" -> tickTravel();
            default -> tickRegion();
        }
    }

    /** @return true to keep going */
    private boolean handleFull() {
        if (whenFull.is("Stop")) {
            stop("Stopped: inventory full");
            return false;
        }
        for (int i = 9; i < 36; i++) {
            ItemStack st = mc.player.getInventory().getItem(i);
            if (isJunk(st)) {
                Compat.dropSlot(mc.player.inventoryMenu.containerId, InvUtil.toMenuSlot(i));
                return true;
            }
        }
        for (int i = 0; i < 9; i++) {
            ItemStack st = mc.player.getInventory().getItem(i);
            if (isJunk(st) && i != InvUtil.selected()) {
                Compat.dropSlot(mc.player.inventoryMenu.containerId, InvUtil.toMenuSlot(i));
                return true;
            }
        }
        stop("Stopped: inventory full of things worth keeping");
        return false;
    }

    private static final Set<Item> JUNK = Set.of(Items.COBBLESTONE, Items.COBBLED_DEEPSLATE, Items.STONE, Items.DIRT, Items.GRAVEL,
            Items.NETHERRACK, Items.DIORITE, Items.ANDESITE, Items.GRANITE, Items.TUFF, Items.DEEPSLATE, Items.BLACKSTONE,
            Items.BASALT, Items.SAND, Items.SANDSTONE, Items.CALCITE, Items.SOUL_SAND, Items.SOUL_SOIL, Items.FLINT);

    private static boolean isJunk(ItemStack st) {
        return !st.isEmpty() && JUNK.contains(st.getItem());
    }

    // ------------------------------------------------------------------ strip (bottom block, top block, step)

    private void tickStrip() {
        if (pathIdx >= path.size()) {
            stop("Done: " + mined + " blocks mined");
            return;
        }
        if (stepWait > 0) {
            stepWait--;
            mc.options.keyUp.setDown(false);
            return;
        }
        BlockPos cell = path.get(pathIdx);
        BlockPos bottom = cell, top = cell.above();
        // Something to stand on first: fill a hole with junk, or stop.
        BlockPos floor = cell.below();
        if (pathIdx > 0 && mc.level.getBlockState(floor).getCollisionShape(mc.level, floor).isEmpty()) {
            mc.options.keyUp.setDown(false);
            if (!bridge(floor)) stop("Stopped: hole in the floor and nothing to fill it with");
            return;
        }
        // Bottom block, then top block (gravel that falls in gets mined again).
        for (BlockPos b : new BlockPos[]{bottom, top}) {
            if (!mineable(b)) continue;
            mc.options.keyUp.setDown(false);
            mc.options.keyShift.setDown(false);
            if (hazard(b)) {
                if (skipped.contains(b)) stop("Stopped: fluid next to the strip");
                return;
            }
            mineBlock(b);
            walkTicks = 0;
            return;
        }
        // Both clear: step into the cell, slowly.
        Vec3 c = Vec3.atBottomCenterOf(cell);
        double dx = c.x - mc.player.getX(), dz = c.z - mc.player.getZ();
        if (Math.hypot(dx, dz) > 0.28) {
            lookAt(new Vec3(c.x, mc.player.getEyeY(), c.z), 0.5f);
            mc.player.setXRot(20);
            mc.options.keyUp.setDown(true);
            mc.options.keyShift.setDown(sneakWalk.get());
            status = "Walking  ·  row " + rowOf(pathIdx) + "/" + stripRows.getInt();
            if (++walkTicks > 100) {
                // Can't get there (something solid we can't break): skip this cell.
                walkTicks = 0;
                pathIdx++;
            }
            return;
        }
        mc.options.keyUp.setDown(false);
        mc.options.keyShift.setDown(false);
        walkTicks = 0;
        pathIdx++;
        stepWait = stripDelay.getInt();
    }

    private int rowOf(int idx) {
        int len = stripLength.getInt(), gap = stripGap.getInt();
        int per = len + Math.max(0, gap - 1);
        return Math.min(stripRows.getInt(), idx / Math.max(1, per) + 1);
    }

    // ------------------------------------------------------------------ region (top-down, serpentine)

    private void tickRegion() {
        Vec3 eye = mc.player.getEyePosition();
        double r2 = reach.get() * reach.get();
        while (layerY >= minY) {
            BlockPos inReach = null, firstLeft = null;
            boolean flip = false;
            // Serpentine: rows along X, alternating direction for each Z.
            for (int z = minZ; z <= maxZ && inReach == null; z++) {
                for (int i = 0; i <= maxX - minX; i++) {
                    int x = flip ? maxX - i : minX + i;
                    BlockPos p = new BlockPos(x, layerY, z);
                    if (!mineable(p)) continue;
                    if (firstLeft == null) firstLeft = p;
                    if (eye.distanceToSqr(Vec3.atCenterOf(p)) <= r2) {
                        inReach = p;
                        break;
                    }
                }
                flip = !flip;
            }
            if (inReach != null) {
                mc.options.keyUp.setDown(false);
                mc.options.keyJump.setDown(false);
                if (hazard(inReach)) return;
                mineBlock(inReach);
                return;
            }
            if (firstLeft != null) {
                walkTo(firstLeft);
                return;
            }
            layerY--; // layer done
        }
        // One more sweep from the top catches gravel and sand that fell in.
        if (!sweptOnce) {
            sweptOnce = true;
            layerY = maxY;
            return;
        }
        stop("Done: " + mined + " blocks mined");
    }

    private void walkTo(BlockPos p) {
        if (!walk.get()) {
            status = "Out of reach";
            mc.options.keyUp.setDown(false);
            return;
        }
        Vec3 eye = mc.player.getEyePosition(), to = Vec3.atCenterOf(p);
        lookAt(new Vec3(to.x, eye.y, to.z), 0.35f);
        mc.options.keyUp.setDown(true);
        mc.options.keyJump.setDown(mc.player.horizontalCollision && mc.player.onGround());
        status = "Walking";
    }

    // ------------------------------------------------------------------ hazards

    /** Fluids next to the block: plug them, skip the block, or stop. @return true if this tick was used. */
    private boolean hazard(BlockPos p) {
        for (Direction d : Direction.values()) {
            if (d == Direction.DOWN && !isFluid(p.below())) continue;
            BlockPos n = p.relative(d);
            if (!isFluid(n)) continue;
            switch (fluids.get()) {
                case "Stop" -> {
                    stop("Stopped: " + (mc.level.getFluidState(n).is(net.minecraft.tags.FluidTags.LAVA) ? "lava" : "water") + " next to the area");
                    return true;
                }
                case "Skip" -> {
                    skipped.add(p);
                    return true;
                }
                default -> {
                    if (plug(p, d)) return true;
                    skipped.add(p); // nothing to plug with: leave it standing
                    return true;
                }
            }
        }
        return false;
    }

    /** Places a filler block into the fluid next to {@code solid}, clicking solid's face. */
    private boolean plug(BlockPos solid, Direction toward) {
        int slot = InvUtil.findHotbar(AutoMine::isJunk);
        if (slot == -1) {
            int inv = InvUtil.findMain(AutoMine::isJunk);
            if (inv == -1) return false;
            InvUtil.moveToHotbar(inv, 8);
            slot = 8;
        }
        Vec3 hit = Vec3.atCenterOf(solid).add(toward.getStepX() * 0.5, toward.getStepY() * 0.5, toward.getStepZ() * 0.5);
        if (mc.player.getEyePosition().distanceToSqr(hit) > reach.get() * reach.get()) return false;
        InvUtil.select(slot);
        lookAt(hit, 1f);
        InvUtil.useOn(new BlockHitResult(hit, toward, solid, false), InteractionHand.MAIN_HAND);
        status = "Plugging fluid";
        return true;
    }

    // ------------------------------------------------------------------ travel (Base Hunter)

    private void tickTravel() {
        BlockPos me = mc.player.blockPosition();
        int dx = travelTarget.getX() - me.getX(), dz = travelTarget.getZ() - me.getZ(), dy = travelTarget.getY() - me.getY();
        if (Math.abs(dx) <= 2 && Math.abs(dz) <= 2 && Math.abs(dy) <= 2) {
            stop("Arrived at the target");
            travelTarget = null;
            return;
        }
        Direction dir;
        if (detourTicks > 0 && detour != null) {
            dir = detour;
            detourTicks--;
        } else if (Math.abs(dx) >= Math.abs(dz)) {
            dir = dx > 0 ? Direction.EAST : Direction.WEST;
        } else {
            dir = dz > 0 ? Direction.SOUTH : Direction.NORTH;
        }
        if (Math.abs(dx) <= 1 && Math.abs(dz) <= 1) dir = forward; // straight above or below: stairs along the last heading
        int vertical = dy < -1 ? -1 : dy > 1 ? 1 : 0;
        forward = dir;
        tickTunnel(dir, vertical);
    }

    // ------------------------------------------------------------------ tunnel

    /**
     * One step of a 1x2 (or 3x3) tunnel along {@code dir}. vertical -1 digs stairs down,
     * +1 stairs up. Fluids in the way are plugged (or trigger a detour), drops are bridged.
     */
    private void tickTunnel(Direction dir, int vertical) {
        BlockPos feet = mc.player.blockPosition();
        BlockPos front = feet.relative(dir).above(vertical > 0 ? 1 : vertical < 0 ? -1 : 0);
        BlockPos[] clear;
        if (tunnel.is("3x3") && mode.is("Tunnel")) {
            Direction side = dir.getClockWise();
            clear = new BlockPos[9];
            int n = 0;
            for (int up = 2; up >= 0; up--) for (int s = -1; s <= 1; s++) clear[n++] = front.relative(side, s).above(up);
        } else if (vertical > 0) {
            clear = new BlockPos[]{feet.above(2), front.above(1), front};
        } else if (vertical < 0) {
            // Stepping down: the block at head height ahead has to go too, or we bump into it.
            clear = new BlockPos[]{front.above(2), front.above(1), front};
        } else {
            clear = new BlockPos[]{front.above(1), front};
        }
        for (BlockPos p : clear) {
            if (!mineable(p) && !(skipped.contains(p))) continue;
            if (isFluid(p) || skipped.contains(p)) {
                startDetour(dir);
                return;
            }
            if (hazardInTunnel(p, dir)) return;
            mc.options.keyUp.setDown(false);
            mineBlock(p);
            return;
        }
        // Path is open: make sure there's floor, then step in.
        BlockPos floor = front.below();
        if (mc.level.getBlockState(floor).getCollisionShape(mc.level, floor).isEmpty()) {
            if (isFluid(floor) || mc.level.getBlockState(floor.below()).isAir()) {
                if (!bridge(floor)) {
                    if (mode.is("Travel")) startDetour(dir);
                    else stop("Stopped: drop ahead");
                    return;
                }
                return;
            }
        }
        mc.player.setYRot(dir.toYRot());
        mc.player.setXRot(vertical < 0 ? 35 : vertical > 0 ? -20 : 10);
        mc.options.keyUp.setDown(true);
        mc.options.keyJump.setDown(vertical > 0 && mc.player.onGround());
        status = vertical < 0 ? "Stairs down" : vertical > 0 ? "Stairs up" : "Tunnelling";
        if (mc.player.horizontalCollision) {
            if (++stuckTicks > 40) {
                startDetour(dir);
                stuckTicks = 0;
            }
        } else {
            stuckTicks = 0;
        }
    }

    private boolean hazardInTunnel(BlockPos p, Direction dir) {
        for (Direction d : Direction.values()) {
            if (d == dir.getOpposite()) continue;
            BlockPos n = p.relative(d);
            if (!isFluid(n)) continue;
            if (fluids.is("Stop")) {
                stop("Stopped: fluid ahead");
                return true;
            }
            if (fluids.is("Plug") && plug(p, d)) return true;
            startDetour(dir);
            return true;
        }
        // Gravel or sand overhead: mine it first from below so it drops in front of us, not on us.
        BlockState above = mc.level.getBlockState(p.above());
        if (above.getBlock() instanceof FallingBlock && !p.above().equals(mc.player.blockPosition().above(2))) status = "Clearing falling blocks";
        return false;
    }

    private void startDetour(Direction dir) {
        Direction side = (mc.player.tickCount / 200) % 2 == 0 ? dir.getClockWise() : dir.getCounterClockWise();
        detour = side;
        detourTicks = 60;
        status = "Going around a hazard";
        if (!mode.is("Travel")) stop("Stopped: hazard ahead");
    }

    private boolean bridge(BlockPos air) {
        int slot = InvUtil.findHotbar(AutoMine::isJunk);
        if (slot == -1) return false;
        for (Direction d : Direction.values()) {
            BlockPos n = air.relative(d);
            BlockState st = mc.level.getBlockState(n);
            if (st.isAir() || !st.getFluidState().isEmpty()) continue;
            Vec3 hit = Vec3.atCenterOf(n).add(-d.getStepX() * 0.5, -d.getStepY() * 0.5, -d.getStepZ() * 0.5);
            if (mc.player.getEyePosition().distanceToSqr(hit) > reach.get() * reach.get()) continue;
            InvUtil.select(slot);
            lookAt(hit, 1f);
            mc.options.keyShift.setDown(true);
            InvUtil.useOn(new BlockHitResult(hit, d.getOpposite(), n, false), InteractionHand.MAIN_HAND);
            mc.options.keyShift.setDown(false);
            status = "Bridging a gap";
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ mining one block

    private void lookAt(Vec3 point, float speed) {
        Vec3 eye = mc.player.getEyePosition();
        double dx = point.x - eye.x, dy = point.y - eye.y, dz = point.z - eye.z;
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        mc.player.setYRot(mc.player.getYRot() + Mth.wrapDegrees(yaw - mc.player.getYRot()) * speed);
        mc.player.setXRot(Mth.clamp(mc.player.getXRot() + (pitch - mc.player.getXRot()) * speed, -90, 90));
    }

    private void mineBlock(BlockPos pos) {
        BlockState state = mc.level.getBlockState(pos);
        if (autoTool.get() && !selectTool(state)) return;
        mining = true;
        Vec3 eye = mc.player.getEyePosition();
        Vec3 c = Vec3.atCenterOf(pos);
        Direction face = Direction.getApproximateNearest(eye.x - c.x, eye.y - c.y, eye.z - c.z);
        lookAt(c.add(face.getStepX() * 0.5, face.getStepY() * 0.5, face.getStepZ() * 0.5), 0.6f);
        if (!pos.equals(target) || !mc.gameMode.isDestroying()) {
            if (target != null && !pos.equals(target) && !mineable(target) && !skipped.contains(target)) mined++;
            target = pos;
            targetState = state;
            mc.gameMode.startDestroyBlock(pos, face);
        } else {
            mc.gameMode.continueDestroyBlock(pos, face);
        }
        Compat.swing(InteractionHand.MAIN_HAND, true);
        status = "Mining " + state.getBlock().getName().getString();
    }

    /** Fastest tool that won't break; stops if the block needs a tool we don't have. */
    private boolean selectTool(BlockState state) {
        int best = -1;
        float bestSpeed = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack st = mc.player.getInventory().getItem(i);
            if (st.isDamageableItem() && st.getMaxDamage() - st.getDamageValue() <= saveTools.getInt()) continue;
            float sp = st.getDestroySpeed(state);
            if (state.requiresCorrectToolForDrops() && !st.isCorrectToolForDrops(state)) sp = Math.min(sp, 0.5f);
            if (sp > bestSpeed) {
                bestSpeed = sp;
                best = i;
            }
        }
        if (state.requiresCorrectToolForDrops()) {
            boolean ok = best != -1 && mc.player.getInventory().getItem(best).isCorrectToolForDrops(state);
            if (!ok) {
                // Pull one from the inventory if there is one, else stop instead of chewing stone with a sword.
                int inv = InvUtil.findMain(st -> st.isCorrectToolForDrops(state)
                        && (!st.isDamageableItem() || st.getMaxDamage() - st.getDamageValue() > saveTools.getInt()));
                if (inv != -1) {
                    InvUtil.moveToHotbar(inv, 7);
                    InvUtil.select(7);
                    return true;
                }
                stop("Stopped: no tool can mine " + state.getBlock().getName().getString());
                return false;
            }
        }
        if (best != -1) InvUtil.select(best);
        return true;
    }

    // ------------------------------------------------------------------ rendering

    @Override
    public void onWorldRender() {
        int c = Theme.accent();
        if (mode.is("Strip") && isEnabled() && !path.isEmpty()) {
            corners(new AABB(minX, minY, minZ, maxX + 1, maxY + 1, maxZ + 1), Theme.withAlpha(c, 220));
            // The next few cells along the path.
            for (int i = pathIdx; i < Math.min(path.size(), pathIdx + 6); i++) {
                BlockPos p = path.get(i);
                int a = 150 - (i - pathIdx) * 22;
                World3D.boxLines(new AABB(p.getX() + 0.1, p.getY(), p.getZ() + 0.1, p.getX() + 0.9, p.getY() + 0.02, p.getZ() + 0.9), Theme.withAlpha(c, a), 1.5f);
            }
        } else if (!mode.is("Tunnel") && !mode.is("Travel") && !mode.is("Strip") && maxX >= minX) {
            corners(new AABB(minX, minY, minZ, maxX + 1, maxY + 1, maxZ + 1), Theme.withAlpha(c, 230));
            if (layerY >= minY) {
                AABB layer = new AABB(minX, layerY, minZ, maxX + 1, layerY + 1, maxZ + 1);
                World3D.boxLines(layer, Theme.withAlpha(c, 90), 1.5f);
            }
        } else if (!isEnabled() && corner1 != null) {
            World3D.boxLines(new AABB(corner1).inflate(0.02), Theme.withAlpha(c, 220), 2f);
        }
        if (corner1 != null && corner2 != null && !isEnabled()) {
            corners(new AABB(Math.min(corner1.getX(), corner2.getX()), Math.min(corner1.getY(), corner2.getY()), Math.min(corner1.getZ(), corner2.getZ()),
                    Math.max(corner1.getX(), corner2.getX()) + 1, Math.max(corner1.getY(), corner2.getY()) + 1, Math.max(corner1.getZ(), corner2.getZ()) + 1), Theme.withAlpha(c, 160));
        }
        if (target != null) {
            AABB t = new AABB(target).inflate(0.01);
            World3D.boxFill(t, Theme.withAlpha(c, 60));
            World3D.boxLines(t, Theme.withAlpha(c, 255), 2.5f);
        }
        if (mode.is("Travel") && travelTarget != null) {
            World3D.beam(Vec3.atBottomCenterOf(travelTarget), 40, 0.6, Theme.withAlpha(Theme.current().accent2(), 70));
            World3D.tracer(Vec3.atCenterOf(travelTarget), Theme.withAlpha(Theme.current().accent2(), 180), 1.5f);
        }
    }

    /** Corner brackets instead of a full cage, so the area reads without clutter. */
    private static void corners(AABB b, int color) {
        double l = Math.min(2.5, Math.min(b.getXsize(), b.getZsize()) / 4);
        double[] xs = {b.minX, b.maxX}, ys = {b.minY, b.maxY}, zs = {b.minZ, b.maxZ};
        for (double x : xs) for (double y : ys) for (double z : zs) {
            double sx = x == b.minX ? 1 : -1, sy = y == b.minY ? 1 : -1, sz = z == b.minZ ? 1 : -1;
            World3D.boxLines(new AABB(x, y, z, x + sx * l, y, z), color, 2.5f);
            World3D.boxLines(new AABB(x, y, z, x, y + sy * Math.min(l, b.getYsize() / 2), z), color, 2.5f);
            World3D.boxLines(new AABB(x, y, z, x, y, z + sz * l), color, 2.5f);
        }
    }

    @Override
    public void onFrame(Gfx g) {
        ClickGui gui = BlocksClient.modules.get(ClickGui.class);
        float k = com.blocks.module.visuals.Hud.scaleFactor();
        g.pose().pushMatrix();
        g.pose().scale(k, k);
        Shapes.begin(g, gui.uiScale());
        double sw = g.guiWidth() / k;
        double mins = Math.max(1 / 60.0, (System.currentTimeMillis() - startedAt) / 60000.0);
        int rate = (int) (mined / mins);
        boolean strip = mode.is("Strip");
        boolean region = !mode.is("Tunnel") && !mode.is("Travel") && !strip;
        int pct = strip ? (path.isEmpty() ? 0 : 100 * pathIdx / path.size()) : region && total > 0 ? Math.min(100, 100 * mined / total) : -1;
        String title;
        if (mode.is("Travel") && travelTarget != null) {
            int dist = (int) Math.sqrt(mc.player.blockPosition().distSqr(travelTarget));
            title = "Auto Mine  ·  to " + travelTarget.getX() + " " + travelTarget.getY() + " " + travelTarget.getZ() + "  ·  " + dist + "m";
        } else if (strip) {
            title = "Auto Mine  ·  strip " + stripRows.getInt() + " x " + stripLength.getInt();
        } else if (region) {
            title = "Auto Mine  ·  " + (maxX - minX + 1) + " x " + (maxZ - minZ + 1) + " x " + (maxY - minY + 1);
        } else {
            title = "Auto Mine  ·  tunnel " + tunnel.get() + " " + forward.getName();
        }
        String eta = region && rate > 0 ? AutoBuilder.fmt(Math.max(0, total - mined) / (double) rate * 60) : "--";
        String line = status + "  ·  " + (region ? "layer " + (maxY - layerY + 1) + "/" + (maxY - minY + 1) + "  ·  " : "") + rate + "/min"
                + (region ? "  ·  ETA " + eta : "  ·  " + mined + " blocks");
        double w = Math.max(Math.max(g.widthBold(title) + 40, g.width(line) * 0.84 + 24), 170), h = 32;
        double x = sw / 2 - w / 2, y = 22;
        Shapes.roundRect(x, y, w, h, 9, Theme.withAlpha(0xFF101015, 200));
        Shapes.roundOutline(x, y, w, h, 9, 0.8, Theme.withAlpha(Theme.accent(), 160));
        g.textBold(title, (int) x + 12, (int) y + 6, Theme.TEXT, false);
        if (pct >= 0) {
            String p = pct + "%";
            g.textMono(p, x + w - 12 - g.widthMono(p, 0.8f), y + 7, Theme.accent(), 0.8f);
            Shapes.roundRect(x + 10, y + h - 3.5, w - 20, 1.4, 0.7, Theme.withAlpha(0xFFFFFF, 30));
            Shapes.roundRect(x + 10, y + h - 3.5, (w - 20) * pct / 100.0, 1.4, 0.7, Theme.accent());
        }
        g.textScaled(line, x + 12, y + 18, Theme.TEXT_DIM, 0.84f);
        g.pose().popMatrix();
    }

    @Override
    public String getSuffix() {
        return mode.get();
    }
}
