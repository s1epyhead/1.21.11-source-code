package com.blocks.module.visuals;

import com.blocks.mixin.KeyMappingAccessor;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.NumSetting;
import net.minecraft.client.KeyMapping;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/**
 * Detaches the camera so you can fly it around while your player stays put.
 * WASD moves, Space and Shift go up and down, Sprint goes faster. The mouse turns
 * the camera, not your player.
 */
public class Freecam extends Module {
    private final NumSetting speed = add(new NumSetting("Speed", 1.0, 0.1, 5, 0.1));

    private double x, y, z, px, py, pz;
    private float yaw, pitch;

    public Freecam() {
        super("Freecam", "Fly the camera around while your player stays still", Category.VISUALS);
    }

    @Override
    protected void onEnable() {
        Vec3 c = com.blocks.compat.Compat.camera().position();
        x = px = c.x;
        y = py = c.y;
        z = pz = c.z;
        yaw = mc.player.getYRot();
        pitch = mc.player.getXRot();
    }

    public boolean active() {
        return isEnabled() && mc.player != null;
    }

    /** Movement keys are held back from the player while the camera is free. */
    public boolean blocks(KeyMapping k) {
        if (!active()) return false;
        var o = mc.options;
        return k == o.keyUp || k == o.keyDown || k == o.keyLeft || k == o.keyRight || k == o.keyJump || k == o.keyShift || k == o.keySprint;
    }

    private static boolean down(KeyMapping k) {
        return ((KeyMappingAccessor) k).blocks$isDown();
    }

    public void turn(double dYaw, double dPitch) {
        yaw += (float) dYaw * 0.15f;
        pitch = Mth.clamp(pitch + (float) dPitch * 0.15f, -90, 90);
    }

    @Override
    public void onTick() {
        if (mc.player.isDeadOrDying()) {
            setEnabled(false);
            return;
        }
        px = x;
        py = y;
        pz = z;
        var o = mc.options;
        double f = (down(o.keyUp) ? 1 : 0) - (down(o.keyDown) ? 1 : 0);
        double s = (down(o.keyLeft) ? 1 : 0) - (down(o.keyRight) ? 1 : 0);
        double v = (down(o.keyJump) ? 1 : 0) - (down(o.keyShift) ? 1 : 0);
        double sp = speed.get() * (down(o.keySprint) ? 2.2 : 1);
        double rad = Math.toRadians(yaw);
        double sin = Math.sin(rad), cos = Math.cos(rad);
        double mx = (-sin * f + cos * s), mz = (cos * f + sin * s);
        double len = Math.hypot(mx, mz);
        if (len > 1) {
            mx /= len;
            mz /= len;
        }
        x += mx * sp;
        z += mz * sp;
        y += v * sp;
    }

    public double x(float pt) { return px + (x - px) * pt; }
    public double y(float pt) { return py + (y - py) * pt; }
    public double z(float pt) { return pz + (z - pz) * pt; }
    public float yaw() { return yaw; }
    public float pitch() { return pitch; }
}
