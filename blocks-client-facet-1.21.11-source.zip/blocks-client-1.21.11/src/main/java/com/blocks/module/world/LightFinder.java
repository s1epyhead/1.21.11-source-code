package com.blocks.module.world;

import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.ModeSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.Theme;
import com.blocks.world.Finds;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Underground torches, lanterns and other placed lights: hidden bases glow. */
public class LightFinder extends FinderModule {
    private final NumSetting maxY = add(new NumSetting("Max Y", 40, -60, 120, 4));
    private final NumSetting range = add(new NumSetting("Range", 128, 32, 256, 8));
    private final ModeSetting style = add(new ModeSetting("Style", "Glow", "Glow", "Boxes"));
    private final BoolSetting tracers = add(new BoolSetting("Tracers", false));
    private final BoolSetting labels = add(new BoolSetting("Labels", true));
    private final BoolSetting notify = add(new BoolSetting("Notify", true));

    public LightFinder() {
        super("Light Finder", "Finds placed lights deep underground");
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        Finds.clearKind(Finds.Kind.LIGHT);
        Finds.setLabels(Finds.Kind.LIGHT, false);
    }

    static boolean placedLight(BlockState s) {
        Block b = s.getBlock();
        return b instanceof TorchBlock || b instanceof LanternBlock || b instanceof CampfireBlock
                || b == Blocks.GLOWSTONE || b == Blocks.SEA_LANTERN || b == Blocks.JACK_O_LANTERN
                || b == Blocks.REDSTONE_LAMP || b == Blocks.END_ROD || b == Blocks.SHROOMLIGHT || b instanceof CandleBlock;
    }

    @Override
    public void scan(LevelChunk chunk) {
        List<BlockPos> list = new ArrayList<>();
        forEachBlock(chunk, chunk.getMinY(), maxY.getInt(), LightFinder::placedLight, (pos, st) -> list.add(pos.immutable()));
        long key = com.blocks.compat.Compat.chunkKey(chunk.getPos());
        if (list.isEmpty()) {
            hits.remove(key);
            Finds.remove(Finds.Kind.LIGHT, chunk.getPos());
            return;
        }
        hits.put(key, list);
        Finds.report(Finds.Kind.LIGHT, chunk.getPos(), list.get(0), list.size(), "Hidden light", list.size() + " lights below Y " + maxY.getInt(), notify.get());
    }

    @Override
    public void onTick() {
        Finds.setLabels(Finds.Kind.LIGHT, labels.get());
    }

    @Override
    public void onWorldRender() {
        int c = Finds.Kind.LIGHT.color;
        boolean glow = style.is("Glow");
        forEachLive(range.get(), p -> placedLight(mc.level.getBlockState(p)), p -> {
            AABB box = new AABB(p).deflate(0.2);
            if (glow) {
                World3D.boxFill(box.inflate(0.12), Theme.withAlpha(c, 26));
                World3D.boxFill(box, Theme.withAlpha(c, 70));
            } else {
                World3D.boxFill(box, Theme.withAlpha(c, 40));
                World3D.boxLines(box, Theme.withAlpha(c, 220), 2f);
            }
            if (tracers.get()) World3D.tracer(Vec3.atCenterOf(p), Theme.withAlpha(c, 140), 1.5f);
        }, 400);
    }

    @Override
    public String getSuffix() {
        return String.valueOf(totalHits());
    }
}
