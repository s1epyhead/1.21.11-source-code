package com.blocks.module.combat;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.InvUtil;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;

/** While falling onto a target under your crosshair, switches to the mace and smashes. */
public class AutoMace extends Module {
    private final NumSetting minFall = add(new NumSetting("Min Fall", 3, 1.5, 20, 0.5));
    private final BoolSetting playersOnly = add(new BoolSetting("Players Only", true));
    private final BoolSetting switchBack = add(new BoolSetting("Switch Back", true));

    private int prevSlot = -1, restoreIn;

    public AutoMace() {
        super("Auto Mace", "Smash attacks with the mace while falling", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (restoreIn > 0 && --restoreIn == 0 && prevSlot != -1) {
            InvUtil.select(prevSlot);
            prevSlot = -1;
        }
        if (mc.player.onGround() || mc.player.fallDistance < minFall.get()) return;
        if (!(mc.hitResult instanceof EntityHitResult ehr) || !(ehr.getEntity() instanceof LivingEntity target)) return;
        if (playersOnly.get() && !(target instanceof Player)) return;
        int mace = InvUtil.findHotbar(s -> s.is(Items.MACE));
        if (mace == -1) return;
        if (InvUtil.selected() != mace) {
            prevSlot = InvUtil.selected();
            InvUtil.select(mace);
        }
        InvUtil.attack(target);
        if (switchBack.get() && prevSlot != -1) restoreIn = 2;
    }
}
