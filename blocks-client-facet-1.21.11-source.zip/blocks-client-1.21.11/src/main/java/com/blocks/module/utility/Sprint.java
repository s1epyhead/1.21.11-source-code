package com.blocks.module.utility;

import com.blocks.module.Category;
import com.blocks.module.Module;

/** Holds the sprint key for you. */
public class Sprint extends Module {
    public Sprint() {
        super("Sprint", "Always sprint when moving forward", Category.UTILITY);
    }

    @Override
    public void onTick() {
        mc.options.keySprint.setDown(true);
    }

    @Override
    protected void onDisable() {
        mc.options.keySprint.setDown(false);
    }
}
