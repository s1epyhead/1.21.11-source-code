package com.blocks.module.combat;

import com.blocks.mixin.MinecraftAccessor;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.CombatUtil;
import com.blocks.util.InvUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Right-click a block with a sword: places obsidian, then a crystal on it. */
public class AutoHitCrystal extends Module {
    private final NumSetting delay = add(new NumSetting("Delay", 1, 0, 5, 1));
    private final BoolSetting swordOnly = add(new BoolSetting("Sword Only", true));
    private final BoolSetting switchBack = add(new BoolSetting("Switch Back", true));

    private int stage, timer, prevSlot = -1;
    private BlockPos obsidianPos;

    public AutoHitCrystal() {
        super("Auto Hit Crystal", "Obsidian then crystal from your sword", Category.COMBAT);
    }

    @Override
    protected void onDisable() {
        stage = 0;
    }

    @Override
    public void onTick() {
        // Switch back a few ticks after the crystal goes down so the break hit can land first.
        if (restoreLater > 0 && --restoreLater == 0) restore();
        if (stage == 0) start();
        else if (++timer > delay.getInt()) finish();
    }

    private void start() {
        if (!mc.options.keyUse.isDown()) return;
        if (swordOnly.get() && !mc.player.getMainHandItem().is(ItemTags.SWORDS)) return;
        if (!(mc.hitResult instanceof BlockHitResult bhr) || bhr.getType() != HitResult.Type.BLOCK) return;

        BlockState state = mc.level.getBlockState(bhr.getBlockPos());
        prevSlot = InvUtil.selected();
        if (state.is(Blocks.OBSIDIAN) || state.is(Blocks.BEDROCK)) {
            obsidianPos = bhr.getBlockPos();
            stage = 1;
            timer = delay.getInt() + 1;
            finish();
            return;
        }
        int obsidian = InvUtil.findHotbar(s -> s.is(Items.OBSIDIAN));
        if (obsidian == -1) return;
        InvUtil.select(obsidian);
        InvUtil.useOn(bhr, InteractionHand.MAIN_HAND);
        obsidianPos = bhr.getBlockPos().relative(bhr.getDirection());
        stage = 1;
        timer = 0;
        ((MinecraftAccessor) mc).blocks$setRightClickDelay(4);
    }

    private void finish() {
        stage = 0;
        if (obsidianPos == null || !CombatUtil.canPlaceCrystal(obsidianPos)) {
            restore();
            return;
        }
        int crystal = InvUtil.findHotbar(s -> s.is(Items.END_CRYSTAL));
        if (crystal == -1) {
            restore();
            return;
        }
        InvUtil.select(crystal);
        InvUtil.useOn(new BlockHitResult(Vec3.atCenterOf(obsidianPos).add(0, 0.5, 0), Direction.UP, obsidianPos, false), InteractionHand.MAIN_HAND);
        ((MinecraftAccessor) mc).blocks$setRightClickDelay(4);
        // Leave the crystal in hand so you (or Auto Crystal) can break it; Switch Back returns to the sword after.
        if (switchBack.get()) restoreLater = 3;
    }

    private int restoreLater;

    private void restore() {
        if (switchBack.get() && prevSlot != -1) InvUtil.select(prevSlot);
        prevSlot = -1;
    }
}
