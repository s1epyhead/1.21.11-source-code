package com.blocks.module.combat;

import com.blocks.compat.Compat;
import com.blocks.mixin.ContainerScreenAccessor;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.NumSetting;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Items;

/** Hover a totem in your inventory to swap it into the offhand (then a hotbar slot). */
public class HoverTotem extends Module {
    private final NumSetting delay = add(new NumSetting("Delay", 1, 0, 10, 1));
    private final NumSetting hotbarSlot = add(new NumSetting("Hotbar Slot", 9, 0, 9, 1));

    private int timer;

    public HoverTotem() {
        super("Hover Totem", "Swaps totems you hover over", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (!(Compat.screen() instanceof InventoryScreen screen)) return;
        if (timer++ < delay.getInt()) return;
        Slot slot = ((ContainerScreenAccessor) screen).blocks$getHoveredSlot();
        if (slot == null || !slot.getItem().is(Items.TOTEM_OF_UNDYING)) return;
        int syncId = mc.player.inventoryMenu.containerId;

        if (!mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
            Compat.swapSlot(syncId, slot.index, 40);
            timer = 0;
            return;
        }
        int hb = hotbarSlot.getInt();
        if (hb > 0 && slot.getContainerSlot() != hb - 1
                && !mc.player.getInventory().getItem(hb - 1).is(Items.TOTEM_OF_UNDYING)) {
            Compat.swapSlot(syncId, slot.index, hb - 1);
            timer = 0;
        }
    }
}
