package com.blocks.module.visuals;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.CombatUtil;
import com.blocks.util.Theme;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Crystal visuals: a glowing box on every block a crystal sits on (fading in, and
 * lingering briefly after it pops), plus a preview where your crystal would land.
 */
public class CrystalRender extends Module {
    private final NumSetting range = add(new NumSetting("Range", 16, 4, 48, 1));
    private final BoolSetting baseBoxes = add(new BoolSetting("Base Boxes", true));
    private final BoolSetting preview = add(new BoolSetting("Place Preview", true));
    private final BoolSetting glowCrystals = add(new BoolSetting("Glow Crystals", true));
    private final NumSetting fadeMs = add(new NumSetting("Fade Time", 400, 0, 1500, 50));

    private final Map<BlockPos, Long> lastSeen = new HashMap<>();

    public CrystalRender() {
        super("Crystal Render", "Glowing boxes under crystals and a place preview", Category.VISUALS);
    }

    public boolean glowCrystals() {
        return isEnabled() && glowCrystals.get();
    }

    @Override
    public void onWorldRender() {
        long now = System.currentTimeMillis();
        int c = Theme.current().accent2(), line = Theme.current().accent();
        if (baseBoxes.get()) {
            double r2 = range.get() * range.get();
            for (Entity e : mc.level.entitiesForRendering()) {
                if (!(e instanceof EndCrystal) || e.distanceToSqr(mc.player) > r2) continue;
                lastSeen.put(e.blockPosition().below(), now);
            }
            Iterator<Map.Entry<BlockPos, Long>> it = lastSeen.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<BlockPos, Long> e = it.next();
                double age = now - e.getValue();
                if (age > fadeMs.get() + 60) {
                    it.remove();
                    continue;
                }
                double a = age < 60 ? 1 : 1 - (age - 60) / Math.max(1, fadeMs.get());
                AABB box = new AABB(e.getKey()).inflate(0.004);
                World3D.boxFill(box, Theme.withAlpha(c, (int) (70 * a)));
                World3D.boxLines(box, Theme.withAlpha(line, (int) (240 * a)), 2.5f);
                World3D.boxFill(box.inflate(0.06), Theme.withAlpha(c, (int) (18 * a)));
            }
        }
        if (preview.get() && mc.player.getMainHandItem().is(Items.END_CRYSTAL)
                && mc.hitResult instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK
                && CombatUtil.canPlaceCrystal(bhr.getBlockPos())) {
            AABB box = new AABB(bhr.getBlockPos()).inflate(0.004);
            World3D.boxLines(box, Theme.withAlpha(line, 150), 1.5f);
            World3D.boxFill(box, Theme.withAlpha(c, 28));
        }
    }
}
