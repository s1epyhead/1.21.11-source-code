package com.blocks.module.utility;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;
import com.blocks.util.InvUtil;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;

/** Bind it: one press throws an ender pearl from your hotbar and swaps back. */
public class KeyPearl extends Module {
    private final BoolSetting switchBack = add(new BoolSetting("Switch Back", true));

    public KeyPearl() {
        super("Key Pearl", "Throws a pearl on keypress", Category.UTILITY);
    }

    @Override
    protected boolean showsToggleNotification() {
        return false;
    }

    @Override
    public boolean hiddenInArraylist() {
        return true;
    }

    @Override
    protected void onEnable() {
        int pearl = InvUtil.findHotbar(s -> s.is(Items.ENDER_PEARL));
        if (pearl != -1 && !mc.player.getCooldowns().isOnCooldown(mc.player.getInventory().getItem(pearl))) {
            int prev = InvUtil.selected();
            InvUtil.select(pearl);
            InvUtil.useItem(InteractionHand.MAIN_HAND);
            if (switchBack.get()) InvUtil.select(prev);
        }
        setEnabled(false);
    }
}
