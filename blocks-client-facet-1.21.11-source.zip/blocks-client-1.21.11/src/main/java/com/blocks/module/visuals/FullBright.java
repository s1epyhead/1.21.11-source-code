package com.blocks.module.visuals;

import com.blocks.module.Category;
import com.blocks.module.Module;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Lights up everything by applying night vision on your client only. */
public class FullBright extends Module {
    public FullBright() {
        super("Full Bright", "See in the dark", Category.VISUALS);
    }

    @Override
    public void onTick() {
        MobEffectInstance cur = mc.player.getEffect(MobEffects.NIGHT_VISION);
        if (cur == null || cur.getDuration() < 400) {
            mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1200, 0, false, false, false));
        }
    }

    @Override
    protected void onDisable() {
        mc.player.removeEffect(MobEffects.NIGHT_VISION);
    }
}
