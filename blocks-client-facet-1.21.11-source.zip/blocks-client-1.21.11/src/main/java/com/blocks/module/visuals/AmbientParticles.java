package com.blocks.module.visuals;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.ModeSetting;
import com.blocks.setting.NumSetting;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;

/** Weather for your eyes only: snow, sun motes, petals or ash drifting around you. */
public class AmbientParticles extends Module {
    private final ModeSetting style = add(new ModeSetting("Style", "Snow", "Snow", "Motes", "Petals", "Ash"));
    private final NumSetting density = add(new NumSetting("Density", 6, 1, 30, 1));
    private final NumSetting radius = add(new NumSetting("Radius", 14, 6, 32, 1));

    public AmbientParticles() {
        super("Ambient Particles", "Client-side snow, motes or petals around you", Category.VISUALS);
    }

    private ParticleOptions particle() {
        return switch (style.get()) {
            case "Motes" -> ParticleTypes.END_ROD;
            case "Petals" -> ParticleTypes.CHERRY_LEAVES;
            case "Ash" -> ParticleTypes.WHITE_ASH;
            default -> ParticleTypes.SNOWFLAKE;
        };
    }

    @Override
    public void onTick() {
        var rand = mc.level.getRandom();
        double r = radius.get();
        boolean motes = style.is("Motes");
        for (int i = 0; i < density.getInt(); i++) {
            double x = mc.player.getX() + (rand.nextDouble() * 2 - 1) * r;
            double y = mc.player.getY() + rand.nextDouble() * 10 - 2;
            double z = mc.player.getZ() + (rand.nextDouble() * 2 - 1) * r;
            double vy = motes ? 0.01 : -0.05;
            mc.level.addParticle(particle(), x, y, z, (rand.nextDouble() - 0.5) * 0.02, vy, (rand.nextDouble() - 0.5) * 0.02);
        }
    }
}
