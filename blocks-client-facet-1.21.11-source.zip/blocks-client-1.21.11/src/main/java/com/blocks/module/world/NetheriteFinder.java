package com.blocks.module.world;

import com.blocks.setting.BlockListSetting;
import com.blocks.util.Notifications;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.LevelChunk;

import java.util.List;

/**
 * Block ESP preset for ancient debris. Servers with anti-xray only send debris once
 * it's exposed to air (mined next to, or blown open), so on those servers it finds
 * exposed debris only. It notices that case and tells you, rather than looking broken.
 */
public class NetheriteFinder extends BlockEsp {
    private final BlockListSetting debris = new BlockListSetting("Debris", Blocks.ANCIENT_DEBRIS);
    private int netherChunks, buried;
    private boolean warned;
    private Level warnedFor;

    public NetheriteFinder() {
        super("Netherite Finder", "Highlights ancient debris through walls, with tracers");
        getSettings().remove(blocks);
    }

    @Override
    protected BlockListSetting list() {
        return debris;
    }

    @Override
    public void scan(LevelChunk chunk) {
        super.scan(chunk);
        if (mc.level == null || mc.level.dimension() != Level.NETHER) return;
        if (warnedFor != mc.level) {
            warnedFor = mc.level;
            warned = false;
            netherChunks = buried = 0;
        }
        netherChunks++;
        List<BlockPos> list = hits.get(com.blocks.compat.Compat.chunkKey(chunk.getPos()));
        if (list != null) for (BlockPos p : list) if (enclosed(p)) buried++;
        // Real terrain has more than one buried debris per chunk on average; zero across
        // dozens of chunks means the server is hiding it.
        if (!warned && netherChunks >= 48 && buried == 0) {
            warned = true;
            Notifications.push("Netherite Finder", "This server hides buried ores (anti-xray). Only exposed debris can show.", false);
        }
    }

    private boolean enclosed(BlockPos p) {
        for (Direction d : Direction.values()) {
            var st = mc.level.getBlockState(p.relative(d));
            if (st.isAir() || !st.getFluidState().isEmpty()) return false;
        }
        return true;
    }

    @Override
    public String getSuffix() {
        return warned ? totalHits() + " exposed" : super.getSuffix();
    }
}
