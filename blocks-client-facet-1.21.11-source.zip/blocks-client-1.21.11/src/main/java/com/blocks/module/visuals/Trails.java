package com.blocks.module.visuals;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.render.World3D;
import com.blocks.setting.NumSetting;
import com.blocks.util.Theme;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** A ribbon that follows you around, sunset coloured, fading at the tail. */
public class Trails extends Module {
    private final NumSetting length = add(new NumSetting("Length", 30, 8, 100, 1));
    private final NumSetting height = add(new NumSetting("Height", 0.35, 0.05, 1.8, 0.05));
    private final com.blocks.setting.ModeSetting who = add(new com.blocks.setting.ModeSetting("Who", "You", "You", "You + Target", "Everyone"));

    private final ArrayDeque<Vec3> points = new ArrayDeque<>();
    private final java.util.Map<Integer, ArrayDeque<Vec3>> others = new java.util.HashMap<>();

    public Trails() {
        super("Trails", "A sunset ribbon trailing behind you", Category.VISUALS);
    }

    @Override
    protected void onEnable() {
        points.clear();
    }

    @Override
    public void onTick() {
        record(points, mc.player.position());
        java.util.Set<Integer> seen = new java.util.HashSet<>();
        if (!who.is("You")) {
            for (net.minecraft.world.entity.player.Player p : mc.level.players()) {
                if (p == mc.player || p.distanceToSqr(mc.player) > 48 * 48) continue;
                if (who.is("You + Target") && p != com.blocks.BlocksClient.getTarget()) continue;
                seen.add(p.getId());
                record(others.computeIfAbsent(p.getId(), k -> new ArrayDeque<>()), p.position());
            }
        }
        others.keySet().retainAll(seen);
    }

    private void record(ArrayDeque<Vec3> q, Vec3 p) {
        if (q.isEmpty() || q.peekLast().distanceToSqr(p) > 0.01) q.addLast(p);
        while (q.size() > length.getInt()) q.removeFirst();
    }

    @Override
    public void onWorldRender() {
        ribbon(points, mc.player);
        for (var e : others.entrySet()) {
            var ent = mc.level.getEntity(e.getKey());
            if (ent != null) ribbon(e.getValue(), ent);
        }
    }

    private void ribbon(ArrayDeque<Vec3> source, net.minecraft.world.entity.Entity owner) {
        if (source.size() < 2) return;
        List<Vec3> pts = new ArrayList<>(source);
        pts.add(World3D.lerpPos(owner));
        Theme.Palette pal = Theme.current();
        double h = height.get();
        int n = pts.size();
        for (int i = 0; i < n - 1; i++) {
            double t0 = i / (double) (n - 1), t1 = (i + 1) / (double) (n - 1);
            int c0 = Theme.blend(pal.accent2(), pal.accent(), t0), c1 = Theme.blend(pal.accent2(), pal.accent(), t1);
            int a0 = (int) (170 * t0), a1 = (int) (170 * t1);
            Vec3 p0 = pts.get(i), p1 = pts.get(i + 1);
            Vec3 q0 = p0.add(0, h, 0), q1 = p1.add(0, h, 0);
            // Two-sided: draw both windings so it reads from either side.
            World3D.quad(p0, p1, q1, q0, Theme.withAlpha(c0, a0 / 3), Theme.withAlpha(c1, a1 / 3), Theme.withAlpha(c1, a1), Theme.withAlpha(c0, a0));
            World3D.quad(q0, q1, p1, p0, Theme.withAlpha(c0, a0), Theme.withAlpha(c1, a1), Theme.withAlpha(c1, a1 / 3), Theme.withAlpha(c0, a0 / 3));
            World3D.line(q0, q1, Theme.withAlpha(c0, a0 + 40), Theme.withAlpha(c1, a1 + 40), 2f);
        }
    }
}
