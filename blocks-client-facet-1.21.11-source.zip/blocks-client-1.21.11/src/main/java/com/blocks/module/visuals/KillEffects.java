package com.blocks.module.visuals;

import com.blocks.BlocksClient;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.ModeSetting;
import com.blocks.util.Theme;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** When someone you were fighting dies: fireworks, a totem burst or a sunset shockwave. */
public class KillEffects extends Module {
    private final ModeSetting effect = add(new ModeSetting("Effect", "Fireworks", "Fireworks", "Totem", "Shockwave"));
    private final BoolSetting sound = add(new BoolSetting("Sound", true));

    private record Wave(Vec3 pos, long start) {}

    private final List<Wave> waves = new ArrayList<>();
    private final Random rand = new Random();
    private Player watching;
    private boolean fired;

    public KillEffects() {
        super("Kill Effects", "Fireworks, totems or a shockwave when your target dies", Category.VISUALS);
    }

    @Override
    public void onTick() {
        Player t = BlocksClient.getTarget();
        if (t != null && t != watching) {
            watching = t;
            fired = false;
        }
        if (watching == null || fired) return;
        if (watching.isDeadOrDying() || watching.getHealth() <= 0) {
            fired = true;
            play(watching.position());
        } else if (watching.isRemoved() || watching.distanceToSqr(mc.player) > 64 * 64) {
            watching = null;
        }
    }

    private void play(Vec3 at) {
        switch (effect.get()) {
            case "Totem" -> {
                for (int i = 0; i < 60; i++) {
                    double a = rand.nextDouble() * Math.PI * 2, sp = 0.2 + rand.nextDouble() * 0.5;
                    mc.level.addParticle(ParticleTypes.TOTEM_OF_UNDYING, at.x, at.y + 1, at.z, Math.cos(a) * sp, 0.3 + rand.nextDouble() * 0.6, Math.sin(a) * sp);
                }
                if (sound.get()) mc.level.playLocalSound(at.x, at.y, at.z, SoundEvents.TOTEM_USE, SoundSource.PLAYERS, 0.7f, 1.2f, false);
            }
            case "Shockwave" -> {
                waves.add(new Wave(at.add(0, 0.05, 0), System.currentTimeMillis()));
                if (sound.get()) mc.level.playLocalSound(at.x, at.y, at.z, SoundEvents.GENERIC_EXPLODE.value(), SoundSource.PLAYERS, 0.5f, 1.4f, false);
            }
            default -> {
                for (int i = 0; i < 80; i++) {
                    double a = rand.nextDouble() * Math.PI * 2, b = rand.nextDouble() * Math.PI, sp = 0.15 + rand.nextDouble() * 0.25;
                    mc.level.addParticle(ParticleTypes.FIREWORK, at.x, at.y + 1.6, at.z,
                            Math.cos(a) * Math.sin(b) * sp, Math.cos(b) * sp, Math.sin(a) * Math.sin(b) * sp);
                }
                waves.add(new Wave(at.add(0, 0.05, 0), System.currentTimeMillis()));
                if (sound.get()) mc.level.playLocalSound(at.x, at.y, at.z, SoundEvents.FIREWORK_ROCKET_LARGE_BLAST, SoundSource.PLAYERS, 1f, 1f, false);
            }
        }
    }

    @Override
    public void onWorldRender() {
        long now = System.currentTimeMillis();
        waves.removeIf(w -> now - w.start > 1400);
        Theme.Palette pal = Theme.current();
        for (Wave w : waves) {
            double t = (now - w.start) / 1400.0, e = 1 - Math.pow(1 - t, 3);
            int a = (int) (230 * (1 - t));
            World3D.ring(w.pos, 0.3 + e * 4.5, 0.6 * (1 - t), Theme.withAlpha(pal.accent(), a), 64);
            World3D.ring(w.pos, 0.2 + e * 3.0, 0.3 * (1 - t), Theme.withAlpha(pal.accent2(), a), 48);
        }
    }
}
