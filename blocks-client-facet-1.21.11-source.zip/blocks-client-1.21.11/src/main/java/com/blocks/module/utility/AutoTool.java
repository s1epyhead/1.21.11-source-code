package com.blocks.module.utility;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;
import com.blocks.util.InvUtil;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/** Switches to the fastest hotbar tool for the block you are mining. */
public class AutoTool extends Module {
    private final BoolSetting switchBack = add(new BoolSetting("Switch Back", true));

    private int prevSlot = -1;

    public AutoTool() {
        super("Auto Tool", "Picks the best tool while mining", Category.UTILITY);
    }

    @Override
    public void onTick() {
        boolean mining = mc.options.keyAttack.isDown()
                && mc.hitResult instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK;
        if (!mining) {
            if (switchBack.get() && prevSlot != -1) InvUtil.select(prevSlot);
            prevSlot = -1;
            return;
        }
        BlockState state = mc.level.getBlockState(((BlockHitResult) mc.hitResult).getBlockPos());
        if (state.isAir()) return;
        int best = InvUtil.selected();
        float bestSpeed = mc.player.getInventory().getItem(best).getDestroySpeed(state);
        for (int i = 0; i < 9; i++) {
            float speed = mc.player.getInventory().getItem(i).getDestroySpeed(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                best = i;
            }
        }
        if (best != InvUtil.selected()) {
            if (prevSlot == -1) prevSlot = InvUtil.selected();
            InvUtil.select(best);
        }
    }
}
