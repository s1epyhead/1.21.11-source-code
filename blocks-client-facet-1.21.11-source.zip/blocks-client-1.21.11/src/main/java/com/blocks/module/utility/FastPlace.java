package com.blocks.module.utility;

import com.blocks.mixin.MinecraftAccessor;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Removes (or shortens) the 4-tick right-click delay. */
public class FastPlace extends Module {
    private final NumSetting delay = add(new NumSetting("Delay", 0, 0, 3, 1));
    private final BoolSetting crystals = add(new BoolSetting("Crystals", true));
    private final BoolSetting blocks = add(new BoolSetting("Blocks", false));
    private final BoolSetting xp = add(new BoolSetting("XP Bottles", true));
    private final BoolSetting other = add(new BoolSetting("Everything Else", false));

    public FastPlace() {
        super("Fast Place", "Faster right clicks", Category.UTILITY);
    }

    @Override
    public void onTick() {
        if (!applies(mc.player.getMainHandItem()) && !applies(mc.player.getOffhandItem())) return;
        MinecraftAccessor acc = (MinecraftAccessor) mc;
        if (acc.blocks$getRightClickDelay() > delay.getInt()) acc.blocks$setRightClickDelay(delay.getInt());
    }

    private boolean applies(ItemStack s) {
        if (s.isEmpty()) return false;
        if (s.is(Items.END_CRYSTAL)) return crystals.get();
        if (s.is(Items.EXPERIENCE_BOTTLE)) return xp.get();
        if (s.getItem() instanceof BlockItem) return blocks.get();
        return other.get();
    }
}
