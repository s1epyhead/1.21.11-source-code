package com.blocks.module.visuals;

import com.blocks.BlocksClient;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.ModeSetting;
import com.blocks.util.Theme;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Tints player models a solid colour (ice blue by default), so they pop from anywhere. Blatant; off by default. */
public class Chams extends Module {
    private final ModeSetting color = add(new ModeSetting("Color", "Ice", "Ice", "Theme", "Rose", "Mint"));
    private final BoolSetting onlyTarget = add(new BoolSetting("Only Target", false));
    private final BoolSetting self = add(new BoolSetting("Self", false));
    private final BoolSetting glass = add(new BoolSetting("Glass", true));

    /** Set while the menu draws your head, so it keeps its real skin. */
    public static boolean paused;

    public Chams() {
        super("Chams", "Tints players a solid colour (blatant)", Category.VISUALS);
    }

    private static boolean near(LivingEntityRenderState s, Vec3 p) {
        return Math.abs(s.x - p.x) < 0.05 && Math.abs(s.y - p.y) < 0.05 && Math.abs(s.z - p.z) < 0.05;
    }

    /** Whether this player should be drawn as see-through glass. */
    public boolean glassFor(LivingEntityRenderState s) {
        return glass.get() && tintFor(s) != 0;
    }

    /** ARGB tint for this render state, or 0 to leave it alone. */
    public int tintFor(LivingEntityRenderState s) {
        if (!isEnabled() || paused || mc.player == null || s.entityType == null) return 0;
        if (!"player".equals(BuiltInRegistries.ENTITY_TYPE.getKey(s.entityType).getPath())) return 0;
        boolean isSelf = near(s, World3D.lerpPos(mc.player));
        if (isSelf && !self.get()) return 0;
        if (onlyTarget.get() && !isSelf) {
            Player t = BlocksClient.getTarget();
            if (t == null || !near(s, World3D.lerpPos(t))) return 0;
        }
        int c = switch (color.get()) {
            case "Theme" -> 0xFF000000 | Theme.blend(Theme.accent(), 0xFFFFFFFF, 0.35);
            case "Rose" -> 0xFFFF8FB8;
            case "Mint" -> 0xFF8FFFD0;
            default -> 0xFF8FD8FF;
        };
        return glass.get() ? Theme.withAlpha(c, 0xB4) : c;
    }
}
