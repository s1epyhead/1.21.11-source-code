package com.blocks.module.combat;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.NumSetting;
import com.blocks.util.InvUtil;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Items;

/** When you hit something while falling, the hit is made with your mace, then you swap back. */
public class MaceSwap extends Module {
    private final NumSetting minFall = add(new NumSetting("Min Fall", 2, 1.5, 20, 0.5));

    private int prevSlot = -1, restoreIn;

    public MaceSwap() {
        super("Mace Swap", "Swaps to the mace for falling hits", Category.COMBAT);
    }

    /** Called from the attack mixin before the attack packet is sent. */
    public void beforeAttack(Entity target) {
        if (!isEnabled() || !(target instanceof LivingEntity)) return;
        if (mc.player.onGround() || mc.player.fallDistance < minFall.get()) return;
        if (mc.player.getMainHandItem().is(Items.MACE)) return;
        int mace = InvUtil.findHotbar(s -> s.is(Items.MACE));
        if (mace == -1) return;
        prevSlot = InvUtil.selected();
        InvUtil.select(mace);
        restoreIn = 2;
    }

    @Override
    public void onTick() {
        if (restoreIn > 0 && --restoreIn == 0 && prevSlot != -1) {
            InvUtil.select(prevSlot);
            prevSlot = -1;
        }
    }
}
