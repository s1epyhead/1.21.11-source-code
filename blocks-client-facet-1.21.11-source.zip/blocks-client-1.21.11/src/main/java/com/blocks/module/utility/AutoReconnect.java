package com.blocks.module.utility;

import com.blocks.BlocksClient;
import com.blocks.compat.Compat;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.module.world.AutoBuilder;
import com.blocks.module.world.AutoMine;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.setting.StringSetting;
import com.blocks.util.Notifications;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.DisconnectedScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.network.chat.Component;

import java.util.Locale;
import java.util.Random;

/**
 * Reconnects after a disconnect (with backoff and a little jitter), and picks Auto Mine
 * or Auto Builder back up once you're in. Won't reconnect when the kick reason contains
 * one of your words, and stops if the server keeps kicking you right after joining.
 */
public class AutoReconnect extends Module {
    private final NumSetting delay = add(new NumSetting("Delay (s)", 5, 1, 60, 1));
    private final NumSetting maxDelay = add(new NumSetting("Max Delay (s)", 60, 5, 300, 5));
    private final NumSetting maxAttempts = add(new NumSetting("Max Attempts", 10, 1, 50, 1));
    private final BoolSetting jitter = add(new BoolSetting("Random Jitter", true));
    private final StringSetting dontIf = add(new StringSetting("Don't Reconnect If", "banned,x-ray,nuker,invalid move"));
    private final BoolSetting resumeMine = add(new BoolSetting("Resume Auto Mine", true));
    private final BoolSetting resumeBuilder = add(new BoolSetting("Resume Builder", true));
    private final NumSetting resumeAfter = add(new NumSetting("Resume After (s)", 8, 0, 60, 1));
    private final BoolSetting kickLoopGuard = add(new BoolSetting("Kick Loop Guard", true));

    private final Random rand = new Random();
    private ServerData lastServer;
    private int attempts, quickKicks;
    private long nextAt = -1, joinedAt, resumeAt = -1;
    private boolean wasMining, wasBuilding, blocked;
    private Button button;

    public AutoReconnect() {
        super("Auto Reconnect", "Reconnects after a disconnect and picks the miner or builder back up", Category.UTILITY);
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> onJoin());
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> onDisconnect());
        ClientTickEvents.END_CLIENT_TICK.register(c -> tick());
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (!(screen instanceof DisconnectedScreen) || !isEnabled() || lastServer == null) return;
            button = Button.builder(Component.literal("Auto Reconnect"), b -> {
                blocked = true;
                b.setMessage(Component.literal("Auto Reconnect cancelled"));
                b.active = false;
            }).bounds(w / 2 - 100, h - 32, 200, 20).build();
            Compat.addWidget(screen, button);
        });
    }

    private void onJoin() {
        lastServer = mc.getCurrentServer();
        joinedAt = System.currentTimeMillis();
        if (wasMining || wasBuilding) resumeAt = joinedAt + (long) (resumeAfter.get() * 1000);
    }

    private void onDisconnect() {
        if (!isEnabled()) return;
        wasMining = resumeMine.get() && BlocksClient.modules.get(AutoMine.class).isEnabled();
        AutoBuilder b = BlocksClient.modules.get(AutoBuilder.class);
        wasBuilding = resumeBuilder.get() && b.building;
        quickKicks = System.currentTimeMillis() - joinedAt < 20_000 ? quickKicks + 1 : 0;
    }

    private void tick() {
        long now = System.currentTimeMillis();
        if (mc.player != null && now - joinedAt > 60_000) attempts = 0; // stayed on: the streak is over
        if (resumeAt > 0 && now >= resumeAt && mc.player != null) {
            resumeAt = -1;
            if (wasMining) BlocksClient.modules.get(AutoMine.class).setEnabled(true);
            AutoBuilder b = BlocksClient.modules.get(AutoBuilder.class);
            if (wasBuilding && b.schematic != null && !b.building) b.toggleBuilding();
            if (wasMining || wasBuilding) Notifications.push("Auto Reconnect", "Picked " + (wasMining ? "Auto Mine" : "the build") + " back up", true);
            wasMining = wasBuilding = false;
        }
        if (!isEnabled() || lastServer == null) return;
        if (!(Compat.screen() instanceof DisconnectedScreen ds)) {
            if (!(Compat.screen() instanceof ConnectScreen)) {
                nextAt = -1;
                blocked = false;
            }
            return;
        }
        if (blocked) return;
        if (nextAt < 0) {
            String reason = ds.getNarrationMessage().getString().toLowerCase(Locale.ROOT);
            for (String word : dontIf.get().toLowerCase(Locale.ROOT).split(",")) {
                if (!word.isBlank() && reason.contains(word.trim())) {
                    stopWith("Not reconnecting: kicked for \"" + word.trim() + "\"");
                    return;
                }
            }
            if (kickLoopGuard.get() && quickKicks >= 3) {
                stopWith("Kicked 3 times right after joining, stopped");
                return;
            }
            if (attempts >= maxAttempts.getInt()) {
                stopWith("Gave up after " + attempts + " attempts");
                return;
            }
            attempts++;
            double secs = Math.min(maxDelay.get(), delay.get() * Math.pow(2, attempts - 1));
            if (jitter.get()) secs *= 0.85 + rand.nextDouble() * 0.3;
            nextAt = now + (long) (secs * 1000);
        }
        long left = Math.max(0, nextAt - now);
        if (button != null && button.active) {
            button.setMessage(Component.literal("Reconnecting in " + (left / 1000 + 1) + "s  (attempt " + attempts + ")  -  cancel"));
        }
        if (left == 0) {
            nextAt = Long.MAX_VALUE;
            ConnectScreen.startConnecting(new TitleScreen(), mc, ServerAddress.parseString(lastServer.ip), lastServer, false, null);
        }
    }

    private void stopWith(String why) {
        blocked = true;
        if (button != null) {
            button.setMessage(Component.literal(why));
            button.active = false;
        }
        BlocksClient.LOG.info("Auto Reconnect: {}", why);
    }

    @Override
    public String getSuffix() {
        return attempts > 0 ? attempts + "/" + maxAttempts.getInt() : null;
    }
}
