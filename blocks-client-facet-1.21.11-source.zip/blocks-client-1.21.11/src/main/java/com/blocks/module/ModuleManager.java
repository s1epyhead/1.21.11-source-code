package com.blocks.module;

import com.blocks.BlocksClient;
import com.blocks.compat.Compat;
import com.blocks.module.client.ClickGui;
import com.blocks.module.combat.*;
import com.blocks.module.utility.*;
import com.blocks.module.visuals.*;
import com.blocks.module.world.*;
import com.blocks.render.Gfx;
import com.blocks.util.Notifications;
import net.minecraft.client.Minecraft;

import java.util.*;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    private final Map<Class<?>, Module> byClass = new HashMap<>();
    private final Map<Module, Boolean> keyWasDown = new HashMap<>();

    public ModuleManager() {
        // Combat
        add(new AutoCrystal());
        add(new AutoHitCrystal());
        add(new CrystalOptimizer());
        add(new CrystalAura());
        add(new AnchorMacro());
        add(new SafeAnchor());
        add(new Surround());
        add(new DoubleAnchor());
        add(new AutoInventoryTotem());
        add(new HoverTotem());
        add(new AutoDoubleHand());
        add(new TotemOffhand());
        add(new TriggerBot());
        add(new AimAssist());
        add(new AutoMace());
        add(new MaceSwap());
        add(new TotemHit());
        add(new ShieldDisabler());
        add(new AutoJumpReset());
        add(new AutoPot());
        // Visuals
        add(new Hud());
        add(new TargetHud());
        add(new Esp());
        add(new CrystalRender());
        add(new TargetEsp());
        add(new HitParticles());
        add(new AmbientParticles());
        add(new ChatPlus());
        add(new Crosshair());
        add(new BetterCamera());
        add(new Freecam());
        add(new FullBright());
        add(new Nametags());
        add(new Trails());
        add(new JumpCircles());
        add(new SunHat());
        add(new BlockHighlight());
        add(new DamageNumbers());
        add(new KillEffects());
        add(new Chams());
        add(new AuraSpikes());
        add(new OrbitShards());
        add(new StatusBars());
        add(new Companion());
        add(new BlatantPack());
        // World (base hunting)
        add(new StorageEsp());
        add(new StashFinder());
        add(new SusChunkFinder());
        add(new TunnelFinder());
        add(new LightFinder());
        add(new BlockEsp());
        add(new NetheriteFinder());
        add(new AutoMine());
        add(new BaseHunter());
        add(new AutoBuilder());
        // Utility
        add(new Sprint());
        add(new FastPlace());
        add(new KeyPearl());
        add(new XpManager());
        add(new AutoTool());
        add(new NoJumpDelay());
        add(new AutoReconnect());
        // Client
        add(new ClickGui());
    }

    private void add(Module module) {
        modules.add(module);
        byClass.put(module.getClass(), module);
    }

    public List<Module> all() {
        return modules;
    }

    public List<Module> inCategory(Category category) {
        List<Module> list = new ArrayList<>();
        for (Module m : modules) if (m.getCategory() == category) list.add(m);
        // Favourites float to the top, like Bloom's starred modules.
        list.sort(Comparator.comparing((Module m) -> !m.isFavorite()));
        return list;
    }

    public Module byName(String name) {
        for (Module m : modules) if (m.getName().equalsIgnoreCase(name)) return m;
        return null;
    }

    public <T extends Module> T get(Class<T> type) {
        Module m = byClass.get(type);
        if (m == null) throw new IllegalArgumentException("No module " + type.getSimpleName());
        return type.cast(m);
    }

    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;

        // Keybinds only fire while no screen is open, like vanilla keys.
        if (Compat.screen() == null) {
            for (Module m : modules) {
                if (m.getKey() <= 0) continue;
                boolean down = Compat.isKeyDown(m.getKey());
                if (down && !keyWasDown.getOrDefault(m, false)) m.toggle();
                keyWasDown.put(m, down);
            }
        } else {
            keyWasDown.clear();
        }

        com.blocks.world.ChunkScanner.tick();
        for (Module m : modules) {
            if (!m.isEnabled()) continue;
            try {
                m.onTick();
            } catch (Exception e) {
                BlocksClient.LOG.error("Error ticking {}", m.getName(), e);
            }
        }
    }

    public void onWorldRender() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        for (Module m : modules) {
            if (!m.isEnabled()) continue;
            // Finders draw through walls; combat visuals stay depth-tested.
            com.blocks.render.World3D.xray(m instanceof com.blocks.module.world.FinderModule);
            try {
                m.onWorldRender();
            } catch (Exception e) {
                if (renderErrors.add(m)) BlocksClient.LOG.error("Error in world render for {}", m.getName(), e);
            }
        }
        com.blocks.render.World3D.xray(false);
    }

    private final java.util.Set<Module> renderErrors = new java.util.HashSet<>();

    public void onFrame(Gfx g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        for (Module m : modules) {
            if (!m.isEnabled()) continue;
            try {
                m.onFrame(g);
            } catch (Exception e) {
                BlocksClient.LOG.error("Error rendering {}", m.getName(), e);
            }
        }
        Notifications.render(g);
    }
}
