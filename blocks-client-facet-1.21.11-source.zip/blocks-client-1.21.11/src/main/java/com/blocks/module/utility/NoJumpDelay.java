package com.blocks.module.utility;

import com.blocks.mixin.LivingEntityAccessor;
import com.blocks.module.Category;
import com.blocks.module.Module;

/** Removes the short cooldown between jumps while holding space. */
public class NoJumpDelay extends Module {
    public NoJumpDelay() {
        super("No Jump Delay", "Jump again instantly", Category.UTILITY);
    }

    @Override
    public void onTick() {
        ((LivingEntityAccessor) mc.player).blocks$setNoJumpDelay(0);
    }
}
