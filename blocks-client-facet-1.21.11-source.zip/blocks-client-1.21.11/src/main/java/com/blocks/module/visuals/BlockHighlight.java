package com.blocks.module.visuals;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.util.Theme;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/** The block you're looking at gets a soft glowing box that glides from block to block. */
public class BlockHighlight extends Module {
    private final BoolSetting fill = add(new BoolSetting("Fill", true));
    private final BoolSetting glide = add(new BoolSetting("Glide", true));

    private AABB shown;

    public BlockHighlight() {
        super("Block Highlight", "A glowing box that glides to the block you look at", Category.VISUALS);
    }

    @Override
    public void onWorldRender() {
        if (!(mc.hitResult instanceof BlockHitResult hit) || mc.hitResult.getType() != HitResult.Type.BLOCK) {
            shown = null;
            return;
        }
        BlockPos pos = hit.getBlockPos();
        var shape = mc.level.getBlockState(pos).getShape(mc.level, pos);
        AABB target = (shape.isEmpty() ? new AABB(pos) : shape.bounds().move(pos)).inflate(0.004);
        if (shown == null || !glide.get()) shown = target;
        else {
            double k = 0.35;
            shown = new AABB(shown.minX + (target.minX - shown.minX) * k, shown.minY + (target.minY - shown.minY) * k, shown.minZ + (target.minZ - shown.minZ) * k,
                    shown.maxX + (target.maxX - shown.maxX) * k, shown.maxY + (target.maxY - shown.maxY) * k, shown.maxZ + (target.maxZ - shown.maxZ) * k);
        }
        Theme.Palette pal = Theme.current();
        double pulse = 0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 300.0);
        if (fill.get()) World3D.boxFill(shown, Theme.withAlpha(pal.accent(), (int) (34 + 24 * pulse)));
        World3D.boxLines(shown, Theme.withAlpha(Theme.blend(pal.accent(), pal.accent2(), pulse), 235), 2.2f);
    }
}
