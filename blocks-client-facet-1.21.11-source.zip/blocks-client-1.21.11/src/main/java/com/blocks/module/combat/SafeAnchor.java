package com.blocks.module.combat;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.util.InvUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Works with Anchor Macro and Double Anchor: before a charged anchor is detonated,
 * puts a glowstone block between you and it so the blast is shielded.
 */
public class SafeAnchor extends Module {
    public SafeAnchor() {
        super("Safe Anchor", "Glowstone shield between you and the anchor before it blows", Category.COMBAT);
    }

    /** @return true if a shield block was placed this tick (detonate on a later tick). */
    public boolean tryShield(BlockPos anchor) {
        double dx = mc.player.getX() - (anchor.getX() + 0.5);
        double dz = mc.player.getZ() - (anchor.getZ() + 0.5);
        if (dx * dx + dz * dz < 1.2) return false; // standing on top of it, nothing to put between
        Direction dir = Math.abs(dx) > Math.abs(dz) ? (dx > 0 ? Direction.EAST : Direction.WEST) : (dz > 0 ? Direction.SOUTH : Direction.NORTH);
        BlockPos shield = anchor.relative(dir);
        if (!mc.level.getBlockState(shield).canBeReplaced()) return false; // already covered
        if (mc.player.getBoundingBox().intersects(new AABB(shield))) return false; // you are standing there
        int glowstone = InvUtil.findHotbar(s -> s.is(Items.GLOWSTONE));
        if (glowstone == -1) return false;
        BlockHitResult hit = placeAgainst(shield);
        if (hit == null) return false;
        InvUtil.select(glowstone);
        InvUtil.useOn(hit, InteractionHand.MAIN_HAND);
        return true;
    }

    /** Finds a solid neighbour to click so a block lands at {@code target}. Prefers the floor. */
    private static BlockHitResult placeAgainst(BlockPos target) {
        Direction[] order = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP};
        for (Direction d : order) {
            BlockPos support = target.relative(d);
            var state = mc.level.getBlockState(support);
            if (state.isAir() || state.canBeReplaced() || state.is(net.minecraft.world.level.block.Blocks.RESPAWN_ANCHOR)) continue;
            Direction face = d.getOpposite();
            Vec3 hitVec = Vec3.atCenterOf(support).add(face.getStepX() * 0.5, face.getStepY() * 0.5, face.getStepZ() * 0.5);
            return new BlockHitResult(hitVec, face, support, false);
        }
        return null;
    }
}
