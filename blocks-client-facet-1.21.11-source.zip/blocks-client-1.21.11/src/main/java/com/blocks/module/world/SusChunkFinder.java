package com.blocks.module.world;

import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.Theme;
import com.blocks.world.Finds;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;

import java.util.*;

/**
 * Chunks where players have spent time. World generation only creates kelp tops at
 * age 20-23; kelp at 24+ has grown, which only happens while a player keeps the
 * chunk loaded. Player-made blocks give bases away too.
 */
public class SusChunkFinder extends FinderModule {
    private final NumSetting minKelp = add(new NumSetting("Min Grown Kelp", 6, 1, 64, 1));
    private final BoolSetting playerBlocks = add(new BoolSetting("Player Blocks", true));
    private final NumSetting minBlocks = add(new NumSetting("Min Player Blocks", 4, 1, 40, 1)).visibleWhen(playerBlocks::get);
    private final NumSetting range = add(new NumSetting("Render Range", 256, 64, 512, 16));
    private final BoolSetting labels = add(new BoolSetting("Labels", true));
    private final BoolSetting notify = add(new BoolSetting("Notify", true));

    /** Worldgen kelp tops are age 20-23, so 24+ means it grew in a loaded chunk. */
    private static final int GROWN_AGE = 24;

    private record Sus(int kelp, int blocks, int y) {}

    private final Map<Long, Sus> chunks = new HashMap<>();

    public SusChunkFinder() {
        super("Sus Chunk Finder", "Grown kelp and player blocks mark chunks people lived in");
    }

    @Override
    public void clear() {
        super.clear();
        chunks.clear();
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        Finds.clearKind(Finds.Kind.SUS);
        Finds.setLabels(Finds.Kind.SUS, false);
    }

    @Override
    public void forget(net.minecraft.world.level.ChunkPos pos) {
        super.forget(pos);
        chunks.remove(com.blocks.compat.Compat.chunkKey(pos));
    }

    private static boolean playerBlock(BlockState s) {
        Block b = s.getBlock();
        return b instanceof CraftingTableBlock || b instanceof AbstractFurnaceBlock || b instanceof BedBlock
                || b instanceof ShulkerBoxBlock || b instanceof EnderChestBlock || b instanceof AnvilBlock
                || b instanceof EnchantingTableBlock || b instanceof BeaconBlock || b instanceof RespawnAnchorBlock
                || b == Blocks.TORCH || b == Blocks.WALL_TORCH || b == Blocks.REDSTONE_BLOCK || b == Blocks.NETHERITE_BLOCK
                || b == Blocks.DIAMOND_BLOCK || b == Blocks.EMERALD_BLOCK;
    }

    @Override
    public void scan(LevelChunk chunk) {
        int[] kelp = {0}, blocks = {0}, topY = {Integer.MIN_VALUE};
        int min = chunk.getMinY(), max = min + chunk.getHeight() - 1;
        forEachBlock(chunk, min, max, st -> st.is(Blocks.KELP), (pos, st) -> {
            if (st.getValue(GrowingPlantHeadBlock.AGE) >= GROWN_AGE) {
                kelp[0]++;
                topY[0] = Math.max(topY[0], pos.getY());
            }
        });
        if (playerBlocks.get()) {
            forEachBlock(chunk, min, max, SusChunkFinder::playerBlock, (pos, st) -> {
                blocks[0]++;
                topY[0] = Math.max(topY[0], pos.getY());
            });
        }
        boolean sus = kelp[0] >= minKelp.get() || playerBlocks.get() && blocks[0] >= minBlocks.get();
        long key = com.blocks.compat.Compat.chunkKey(chunk.getPos());
        if (!sus) {
            chunks.remove(key);
            Finds.remove(Finds.Kind.SUS, chunk.getPos());
            return;
        }
        int y = topY[0] == Integer.MIN_VALUE ? 62 : topY[0] + 1;
        chunks.put(key, new Sus(kelp[0], blocks[0], y));
        BlockPos centre = new BlockPos((com.blocks.compat.Compat.chunkX(chunk.getPos()) << 4) + 8, y, (com.blocks.compat.Compat.chunkZ(chunk.getPos()) << 4) + 8);
        boolean byKelp = kelp[0] >= minKelp.get();
        String title = byKelp ? "Grown kelp" : "Player blocks";
        String detail = byKelp ? kelp[0] + " plants" : blocks[0] + " blocks";
        Finds.report(Finds.Kind.SUS, chunk.getPos(), centre, byKelp ? kelp[0] : blocks[0], title, detail, notify.get());
    }

    @Override
    public void onTick() {
        Finds.setLabels(Finds.Kind.SUS, labels.get());
    }

    @Override
    public void onWorldRender() {
        double r2 = range.get() * range.get();
        for (Map.Entry<Long, Sus> e : chunks.entrySet()) {
            int cx = (int) (long) e.getKey(), cz = (int) (e.getKey() >>> 32);
            double dx = (cx << 4) + 8 - mc.player.getX(), dz = (cz << 4) + 8 - mc.player.getZ();
            if (dx * dx + dz * dz > r2) continue;
            int c = Finds.Kind.SUS.color;
            World3D.chunkOutline(cx, cz, e.getValue().y(), Theme.withAlpha(c, 230), Theme.withAlpha(c, 34));
        }
    }

    @Override
    public String getSuffix() {
        return String.valueOf(chunks.size());
    }
}
