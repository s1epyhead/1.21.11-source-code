package com.blocks.module.combat;

import com.blocks.BlocksClient;
import com.blocks.compat.Compat;
import com.blocks.mixin.MinecraftAccessor;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.InvUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Hold right click on a respawn anchor: charges it, shields you (with Safe Anchor),
 * then detonates. Remembers the anchor so the shield block can't block the click.
 */
public class AnchorMacro extends Module {
    private final NumSetting delay = add(new NumSetting("Delay", 50, 0, 500, 25));
    private final BoolSetting onRightClick = add(new BoolSetting("Hold Right Click", true));
    private final NumSetting explodeSlot = add(new NumSetting("Explode Slot", 0, 0, 9, 1));
    private final BoolSetting switchBack = add(new BoolSetting("Switch Back", true));

    private BlockPos anchor;
    private long last;
    private int prevSlot = -1, restoreIn;

    public AnchorMacro() {
        super("Anchor Macro", "Hold right click on an anchor to charge and blow it", Category.COMBAT);
    }

    @Override
    protected void onDisable() {
        anchor = null;
    }

    @Override
    public void onTick() {
        if (restoreIn > 0 && --restoreIn == 0 && prevSlot != -1) {
            InvUtil.select(prevSlot);
            prevSlot = -1;
        }
        if (Compat.screen() != null) return;
        if (mc.level.dimension() == Level.NETHER) return; // anchors only explode outside the Nether

        BlockPos looked = lookedAnchor();
        if (looked != null) anchor = looked;
        if (anchor != null && (!isAnchor(anchor) || mc.player.getEyePosition().distanceTo(Vec3.atCenterOf(anchor)) > 5.5)) {
            anchor = null;
        }
        if (anchor == null) return;
        if (onRightClick.get() && !mc.options.keyUse.isDown()) {
            anchor = null;
            return;
        }
        ((MinecraftAccessor) mc).blocks$setRightClickDelay(4);
        long now = System.currentTimeMillis();
        if (now - last < delay.get()) return;

        if (prevSlot == -1) prevSlot = InvUtil.selected();
        int charge = mc.level.getBlockState(anchor).getValue(RespawnAnchorBlock.CHARGE);
        if (charge == 0) {
            int glowstone = InvUtil.findHotbar(s -> s.is(Items.GLOWSTONE));
            if (glowstone == -1) return;
            InvUtil.select(glowstone);
            InvUtil.useOn(topHit(anchor), InteractionHand.MAIN_HAND);
            last = now;
            return;
        }
        SafeAnchor safe = BlocksClient.modules.get(SafeAnchor.class);
        if (safe.isEnabled() && safe.tryShield(anchor)) {
            last = now;
            return;
        }
        int slot = explodeSlot(explodeSlot.getInt());
        if (slot == -1) return;
        InvUtil.select(slot);
        InvUtil.useOn(topHit(anchor), InteractionHand.MAIN_HAND);
        last = now;
        anchor = null;
        if (switchBack.get()) restoreIn = 2;
    }

    private BlockPos lookedAnchor() {
        if (mc.hitResult instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK && isAnchor(bhr.getBlockPos())) {
            return bhr.getBlockPos();
        }
        return null;
    }

    private static boolean isAnchor(BlockPos pos) {
        BlockState state = mc.level.getBlockState(pos);
        return state.is(Blocks.RESPAWN_ANCHOR);
    }

    static BlockHitResult topHit(BlockPos pos) {
        return new BlockHitResult(Vec3.atCenterOf(pos).add(0, 0.5, 0), Direction.UP, pos, false);
    }

    /** Any slot that is not glowstone works; prefers the configured slot, then a totem. */
    static int explodeSlot(int configured) {
        if (configured > 0 && !mc.player.getInventory().getItem(configured - 1).is(Items.GLOWSTONE)) return configured - 1;
        int totem = InvUtil.findHotbar(s -> s.is(Items.TOTEM_OF_UNDYING));
        if (totem != -1) return totem;
        return InvUtil.findHotbar(s -> !s.is(Items.GLOWSTONE));
    }
}
