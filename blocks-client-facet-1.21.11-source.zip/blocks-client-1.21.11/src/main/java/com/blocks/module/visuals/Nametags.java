package com.blocks.module.visuals;

import com.blocks.BlocksClient;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.module.client.ClickGui;
import com.blocks.render.Gfx;
import com.blocks.render.Projection;
import com.blocks.render.Shapes;
import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.Theme;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Clean glass nametags for players: name, health, ping, distance and their gear. */
public class Nametags extends Module {
    private final NumSetting range = add(new NumSetting("Range", 64, 8, 256, 8));
    private final BoolSetting armor = add(new BoolSetting("Armor", true));
    private final BoolSetting ping = add(new BoolSetting("Ping", true));
    private final BoolSetting distance = add(new BoolSetting("Distance", true));
    private final NumSetting scale = add(new NumSetting("Scale", 1.0, 0.6, 1.6, 0.05));

    private static final EquipmentSlot[] GEAR = {EquipmentSlot.MAINHAND, EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.OFFHAND};

    public Nametags() {
        super("Nametags", "Glass nametags with health, ping and gear", Category.VISUALS);
    }

    /** Vanilla's own tags are hidden while this is on (see the renderer mixin). */
    public boolean hidesVanilla(Object entity) {
        return isEnabled() && entity instanceof Player && entity != mc.player;
    }

    @Override
    public void onFrame(Gfx g) {
        ClickGui gui = BlocksClient.modules.get(ClickGui.class);
        float k = Hud.scaleFactor();
        List<Player> players = new ArrayList<>();
        for (Player p : mc.level.players()) if (p != mc.player && p.distanceTo(mc.player) <= range.get()) players.add(p);
        if (players.isEmpty()) return;
        players.sort(Comparator.comparingDouble(p -> -p.distanceToSqr(mc.player))); // far first, near on top
        g.pose().pushMatrix();
        g.pose().scale(k, k);
        Shapes.begin(g, gui.uiScale());
        Theme.Palette pal = Theme.current();
        for (Player p : players) {
            double[] s = Projection.toGui(World3D.lerpPos(p).add(0, p.getBbHeight() + 0.45, 0), g.guiWidth(), g.guiHeight());
            if (s == null) continue;
            float sc = (float) (scale.get() * Math.max(0.55, Math.min(1.0, 14 / Math.max(1, s[2]))));
            g.pose().pushMatrix();
            g.pose().translate((float) (s[0] / k), (float) (s[1] / k));
            g.pose().scale(sc, sc);
            float hp = p.getHealth() + p.getAbsorptionAmount();
            String name = p.getName().getString();
            String hpTxt = String.format(hp >= 10 ? "%.0f" : "%.1f", hp);
            StringBuilder extra = new StringBuilder();
            if (ping.get()) {
                PlayerInfo info = mc.getConnection() == null ? null : mc.getConnection().getPlayerInfo(p.getUUID());
                if (info != null) extra.append(info.getLatency()).append("ms");
            }
            if (distance.get()) extra.append(extra.isEmpty() ? "" : "  ").append((int) p.distanceTo(mc.player)).append("m");
            double w = g.widthBold(name) + 8 + g.widthMono(hpTxt, 0.8f) + (extra.isEmpty() ? 0 : 8 + g.widthMono(extra.toString(), 0.7f)) + 16;
            double h = 16, x = -w / 2, y = -h;
            boolean target = p == BlocksClient.getTarget();
            Shapes.roundRect(x, y, w, h, 8, Theme.withAlpha(0xFF0E0E14, 190));
            Shapes.roundOutline(x, y, w, h, 8, 0.8, target ? Theme.withAlpha(pal.accent(), 230) : Theme.withAlpha(0xFFFFFF, 30));
            double pct = Math.min(1, hp / p.getMaxHealth());
            Shapes.roundRect(x + 6, y + h - 3, (w - 12) * pct, 1.4, 0.7, Theme.health((float) pct));
            g.textBold(name, (int) (x + 8), (int) (y + 4), Theme.TEXT, false);
            double tx = x + 8 + g.widthBold(name) + 8;
            g.textMono(hpTxt, tx, y + 4.6, Theme.health((float) pct), 0.8f);
            tx += g.widthMono(hpTxt, 0.8f) + 8;
            if (!extra.isEmpty()) g.textMono(extra.toString(), tx, y + 5.2, Theme.TEXT_FAINT, 0.7f);
            if (armor.get()) {
                double ix = -(GEAR.length * 15) / 2.0 + 7.5;
                for (EquipmentSlot slot : GEAR) {
                    ItemStack st = p.getItemBySlot(slot);
                    if (!st.isEmpty()) {
                        g.itemIcon(st, ix, y - 10, 12, Shapes.scale());
                        if (st.isDamageableItem()) {
                            double d = 1 - st.getDamageValue() / (double) st.getMaxDamage();
                            Shapes.rect(ix - 5, y - 2.5, 10 * d, 1, Theme.health((float) d));
                        }
                    }
                    ix += 15;
                }
            }
            g.pose().popMatrix();
        }
        g.pose().popMatrix();
    }
}
