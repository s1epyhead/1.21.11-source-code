package com.blocks.module.world;

import com.blocks.BlocksClient;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.ModeSetting;
import com.blocks.util.Notifications;
import com.blocks.world.Finds;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

/**
 * Bind it to a key. When the finders have turned up a base, press the key to lock on
 * (the one nearest your crosshair, or the nearest overall) and Auto Mine tunnels there:
 * 1x2 with stairs, plugging or going around lava and water and bridging drops.
 * Press it again to stop.
 */
public class BaseHunter extends Module {
    private final ModeSetting targets = add(new ModeSetting("Targets", "Stashes", "Stashes", "Any Find"));
    private final ModeSetting pick = add(new ModeSetting("Pick", "Crosshair", "Crosshair", "Nearest"));

    private BlockPos target;

    public BaseHunter() {
        super("Base Hunter", "Press its key to tunnel to the stash you're looking at", Category.WORLD);
    }

    @Override
    protected void onEnable() {
        Finds.Find best = choose();
        if (best == null) {
            Notifications.push("Base Hunter", targets.is("Stashes") ? "No stash found yet. Turn on Stash Finder and look around." : "Nothing found yet", false);
            setEnabled(false);
            return;
        }
        target = best.pos();
        int dist = (int) Math.sqrt(mc.player.blockPosition().distSqr(target));
        Notifications.push("Base Hunter", "Heading to " + best.detail() + " at " + target.getX() + ", " + target.getZ() + "  (" + dist + "m)", true);
        BlocksClient.modules.get(AutoMine.class).travelTo(target);
    }

    private Finds.Find choose() {
        Vec3 eye = mc.player.getEyePosition(), look = mc.player.getLookAngle();
        Finds.Find best = null;
        double bestScore = Double.MAX_VALUE;
        for (Finds.Find f : Finds.all()) {
            boolean stash = f.kind() == Finds.Kind.STASH;
            if (targets.is("Stashes") && !stash) continue;
            Vec3 to = Vec3.atCenterOf(f.pos()).subtract(eye);
            double dist = to.length();
            double score;
            if (pick.is("Crosshair")) {
                double angle = Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, to.normalize().dot(look)))));
                score = angle * 10 + dist * 0.05; // where you're looking matters most
            } else {
                score = dist;
            }
            if (stash) score -= Math.min(200, f.count() * 4); // bigger stashes first
            if (score < bestScore) {
                bestScore = score;
                best = f;
            }
        }
        return best;
    }

    @Override
    protected void onDisable() {
        AutoMine mine = BlocksClient.modules.get(AutoMine.class);
        if (mine.isEnabled() && target != null && target.equals(mine.travelTarget())) mine.setEnabled(false);
        target = null;
    }

    @Override
    public void onTick() {
        // Auto Mine finished (arrived) or stopped for a hazard: we're done too.
        if (!BlocksClient.modules.get(AutoMine.class).isEnabled()) setEnabled(false);
    }

    @Override
    public String getSuffix() {
        if (target == null || mc.player == null) return null;
        return (int) Math.sqrt(mc.player.blockPosition().distSqr(target)) + "m";
    }
}
