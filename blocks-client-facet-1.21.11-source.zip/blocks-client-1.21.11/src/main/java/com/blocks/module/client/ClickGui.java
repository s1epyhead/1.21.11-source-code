package com.blocks.module.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.blocks.compat.Compat;
import com.blocks.gui.BlocksScreen;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.ModeSetting;
import com.blocks.setting.NumSetting;

/**
 * Opens the Blocks menu. Its settings are the "GUI Settings" panel, so every
 * visual effect (particles, blur, dim, glow, animations) can be switched off.
 */
public class ClickGui extends Module {
    // Interface
    public final ModeSetting design = add(new ModeSetting("Menu Design", "Facet", "Facet", "Classic"));
    public final ModeSetting menuStyle = add(new ModeSetting("Menu Style", "Hub + Panel", "Hub + Panel", "Panel Only"));
    public final NumSetting panelOpacity = add(new NumSetting("Panel Opacity", 72, 30, 100, 2));
    public final BoolSetting particles = add(new BoolSetting("Particles", true));
    public final ModeSetting particleStyle = add(new ModeSetting("Particle Style", "Blocks", "Blocks", "Motes", "Petals", "Bubbles"));
    public final BoolSetting dim = add(new BoolSetting("Background Dim", true));
    public final BoolSetting blur = add(new BoolSetting("Background Blur", true));
    public final BoolSetting glow = add(new BoolSetting("Glow", true));
    public final BoolSetting animations = add(new BoolSetting("Animations", true));
    public final BoolSetting tooltips = add(new BoolSetting("Tooltips", true));
    // HUD & alerts
    public final BoolSetting notifications = add(new BoolSetting("Notifications", true));
    public final BoolSetting toggleAlerts = add(new BoolSetting("Toggle Alerts", true));
    public final BoolSetting findAlerts = add(new BoolSetting("Find Alerts", true));
    public final BoolSetting notificationSound = add(new BoolSetting("Notification Sound", true));
    // Appearance
    public final ModeSetting theme = add(new ModeSetting("Theme", "Amethyst",
            "Amethyst", "Diamond", "Emerald", "Redstone", "Gold", "Lapis", "Netherite", "Grass", "Custom"));
    public final ModeSetting font = add(new ModeSetting("Font", "Manrope", "Manrope", "Minecraft"));
    public final ModeSetting guiScale = add(new ModeSetting("GUI Scale", "2x", "1x", "2x", "3x"));
    public final NumSetting accentR = add(new NumSetting("Accent R", 255, 0, 255, 1));
    public final NumSetting accentG = add(new NumSetting("Accent G", 140, 0, 255, 1));
    public final NumSetting accentB = add(new NumSetting("Accent B", 90, 0, 255, 1));
    public final NumSetting panelR = add(new NumSetting("Panel R", 24, 0, 255, 1));
    public final NumSetting panelG = add(new NumSetting("Panel G", 16, 0, 255, 1));
    public final NumSetting panelB = add(new NumSetting("Panel B", 20, 0, 255, 1));

    public ClickGui() {
        super("Click GUI", "Opens the Blocks menu", Category.CLIENT, InputConstants.KEY_RSHIFT);
    }

    @Override
    public void toggle() {
        if (mc.player == null) return;
        Compat.openUi(BlocksScreen.open());
    }

    @Override
    protected boolean showsToggleNotification() {
        return false;
    }

    @Override
    public boolean hiddenInArraylist() {
        return true;
    }

    public float uiScale() {
        return switch (guiScale.get()) {
            case "1x" -> 1f;
            case "3x" -> 3f;
            default -> 2f;
        };
    }
}
