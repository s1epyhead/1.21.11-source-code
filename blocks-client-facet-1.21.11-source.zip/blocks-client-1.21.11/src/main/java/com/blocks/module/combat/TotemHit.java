package com.blocks.module.combat;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.ModeSetting;
import com.blocks.util.InvUtil;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Hold a totem and still hit with your sword.
 *
 * Aim (default): the sword comes out while your crosshair is on a target in reach and the
 * totem goes back the moment you look away, so hits are full, charged sword hits.
 * Instant: flicks to the sword only for the hit itself. Vanilla servers apply a held item's
 * damage on their next tick, so an instant swap lands totem base damage plus the sword's
 * enchantments (knockback, fire aspect, sharpness).
 */
public class TotemHit extends Module {
    private final ModeSetting mode = add(new ModeSetting("Mode", "Aim", "Aim", "Instant"));
    private final ModeSetting weapon = add(new ModeSetting("Weapon", "Best", "Best", "Sword", "Axe"));
    private final BoolSetting playersOnly = add(new BoolSetting("Players Only", true));

    private int back = -1;

    public TotemHit() {
        super("Totem Hit", "Hits with your sword while you hold a totem, swapping back instantly", Category.COMBAT);
    }

    /** From the attack mixin, before the attack packet goes out. */
    public void beforeAttack(Entity target) {
        if (!isEnabled() || !mode.is("Instant") || !valid(target)) return;
        if (!mc.player.getMainHandItem().is(Items.TOTEM_OF_UNDYING)) return;
        int slot = weaponSlot();
        if (slot == -1) return;
        back = InvUtil.selected();
        InvUtil.select(slot); // the attack's own carried-item sync sends this before the hit
    }

    private boolean valid(Entity target) {
        return target instanceof LivingEntity le && le.isAlive() && (!playersOnly.get() || target instanceof Player);
    }

    private int aimBack = -1, lostFor, seenFor, swappedTo = -1;

    /**
     * Aim mode, steady: a target counts when it's in reach and roughly in front of you
     * (not only under the exact crosshair), the sword comes out after it's been there for
     * two ticks, and goes back only after half a second without one. No swapping while
     * you eat, use an item or have a screen open, and if you change slot yourself it
     * leaves your hotbar alone.
     */
    @Override
    public void onTick() {
        if (!mode.is("Aim")) return;
        if (aimBack != -1 && InvUtil.selected() != swappedTo) {
            aimBack = -1; // you switched slot yourself
            swappedTo = -1;
        }
        boolean busy = mc.player.isUsingItem() || com.blocks.compat.Compat.screen() != null;
        boolean target = !busy && targetInFront();
        if (target) {
            lostFor = 0;
            if (aimBack == -1 && ++seenFor >= 2 && mc.player.getMainHandItem().is(Items.TOTEM_OF_UNDYING)) {
                int slot = weaponSlot();
                if (slot != -1) {
                    aimBack = InvUtil.selected();
                    InvUtil.select(slot);
                    swappedTo = slot;
                }
            }
        } else {
            seenFor = 0;
            if (aimBack != -1 && ++lostFor >= 10 && !busy) {
                InvUtil.select(aimBack);
                aimBack = -1;
                swappedTo = -1;
            }
        }
    }

    private boolean targetInFront() {
        net.minecraft.world.phys.Vec3 eye = mc.player.getEyePosition(), look = mc.player.getLookAngle();
        for (Entity e : mc.level.entitiesForRendering()) {
            if (e == mc.player || !valid(e)) continue;
            net.minecraft.world.phys.Vec3 to = e.getBoundingBox().getCenter().subtract(eye);
            if (to.length() > 4.5) continue;
            if (to.normalize().dot(look) > Math.cos(Math.toRadians(40))) return true;
        }
        return false;
    }

    @Override
    protected void onDisable() {
        if (aimBack != -1 && mc.player != null) InvUtil.select(aimBack);
        aimBack = -1;
        swappedTo = -1;
    }

    private int weaponSlot() {
        int slot = -1;
        double best = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack st = mc.player.getInventory().getItem(i);
            boolean sword = st.is(net.minecraft.tags.ItemTags.SWORDS), axe = st.is(net.minecraft.tags.ItemTags.AXES);
            if (weapon.is("Sword") && !sword || weapon.is("Axe") && !axe || !sword && !axe) continue;
            double score = (sword ? 10 : 9) + st.getMaxDamage() / 1000.0;
            if (score > best) {
                best = score;
                slot = i;
            }
        }
        return slot;
    }

    /** From the attack mixin, right after the hit. */
    public void afterAttack() {
        if (back != -1) {
            InvUtil.select(back);
            back = -1;
        }
    }
}
