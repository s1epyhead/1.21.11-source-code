package com.blocks.module.combat;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.NumSetting;
import com.blocks.util.InvUtil;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.item.Items;

/** While your inventory is open, fills the offhand (and a hotbar slot) with totems. */
public class AutoInventoryTotem extends Module {
    private final NumSetting delay = add(new NumSetting("Delay", 2, 0, 10, 1));
    private final NumSetting hotbarSlot = add(new NumSetting("Hotbar Slot", 9, 0, 9, 1));

    private int timer;

    public AutoInventoryTotem() {
        super("Auto Inventory Totem", "Refills totems when you open your inventory", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (!(com.blocks.compat.Compat.screen() instanceof InventoryScreen)) {
            timer = 0;
            return;
        }
        if (timer++ < delay.getInt()) return;

        if (!mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
            int slot = InvUtil.findMain(s -> s.is(Items.TOTEM_OF_UNDYING));
            if (slot == -1) slot = InvUtil.findHotbar(s -> s.is(Items.TOTEM_OF_UNDYING));
            if (slot != -1) {
                InvUtil.moveToOffhand(slot);
                timer = 0;
            }
            return;
        }
        int hb = hotbarSlot.getInt();
        if (hb > 0 && !mc.player.getInventory().getItem(hb - 1).is(Items.TOTEM_OF_UNDYING)) {
            int slot = InvUtil.findMain(s -> s.is(Items.TOTEM_OF_UNDYING));
            if (slot != -1) {
                InvUtil.moveToHotbar(slot, hb - 1);
                timer = 0;
            }
        }
    }
}
