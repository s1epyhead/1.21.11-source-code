package com.blocks.module.visuals;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.ModeSetting;
import com.blocks.setting.NumSetting;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.Entity;

/** Extra sparkle when you land a hit or pop a crystal. */
public class HitParticles extends Module {
    private final ModeSetting style = add(new ModeSetting("Style", "Sparks", "Sparks", "Stars", "Crits", "Totem", "Hearts"));
    private final NumSetting amount = add(new NumSetting("Amount", 14, 2, 60, 1));

    public HitParticles() {
        super("Hit Particles", "Sparkles on every hit", Category.VISUALS);
    }

    private ParticleOptions particle() {
        return switch (style.get()) {
            case "Hearts" -> net.minecraft.core.particles.ParticleTypes.HEART;
            case "Stars" -> ParticleTypes.END_ROD;
            case "Crits" -> ParticleTypes.ENCHANTED_HIT;
            case "Totem" -> ParticleTypes.TOTEM_OF_UNDYING;
            default -> ParticleTypes.ELECTRIC_SPARK;
        };
    }

    public void onHit(Entity target) {
        if (!isEnabled() || mc.level == null) return;
        var rand = mc.level.getRandom();
        double h = target.getBbHeight();
        for (int i = 0; i < amount.getInt(); i++) {
            double x = target.getX() + (rand.nextDouble() - 0.5) * target.getBbWidth() * 1.4;
            double y = target.getY() + rand.nextDouble() * h;
            double z = target.getZ() + (rand.nextDouble() - 0.5) * target.getBbWidth() * 1.4;
            mc.level.addParticle(particle(), x, y, z, (rand.nextDouble() - 0.5) * 0.25, rand.nextDouble() * 0.2, (rand.nextDouble() - 0.5) * 0.25);
        }
    }
}
