package com.blocks.module.combat;

import com.blocks.module.Category;
import com.blocks.module.Module;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;

/**
 * Removes a crystal on your screen the moment you hit it instead of waiting for
 * the server, so the next crystal can go down without ping delay (Walksy-style).
 */
public class CrystalOptimizer extends Module {
    public CrystalOptimizer() {
        super("Crystal Optimizer", "Removes hit crystals instantly client-side", Category.COMBAT);
    }

    public void onAttack(Entity target) {
        if (!isEnabled() || !(target instanceof EndCrystal)) return;
        // With weakness and no strength the hit may not break it.
        if (mc.player.hasEffect(MobEffects.WEAKNESS) && !mc.player.hasEffect(MobEffects.STRENGTH)) return;
        mc.level.removeEntity(target.getId(), Entity.RemovalReason.KILLED);
    }
}
