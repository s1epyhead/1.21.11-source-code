package com.blocks.module.world;

import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.Theme;
import com.blocks.world.Finds;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Flags chunks packed with containers (stashes) with a beam, a label and a toast. */
public class StashFinder extends FinderModule {
    private final NumSetting minContainers = add(new NumSetting("Min Containers", 10, 3, 80, 1));
    private final BoolSetting shulkersCountDouble = add(new BoolSetting("Shulkers Count x3", true));
    private final BoolSetting beams = add(new BoolSetting("Beams", true));
    private final BoolSetting labels = add(new BoolSetting("Labels", true));
    private final BoolSetting notify = add(new BoolSetting("Notify", true));

    public StashFinder() {
        super("Stash Finder", "Finds chunks full of chests and shulkers");
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        Finds.clearKind(Finds.Kind.STASH);
        Finds.setLabels(Finds.Kind.STASH, false);
    }

    @Override
    public void scan(LevelChunk chunk) {
        int score = 0, n = 0;
        long sx = 0, sy = 0, sz = 0;
        List<BlockPos> list = new ArrayList<>();
        for (BlockEntity be : chunk.getBlockEntities().values()) {
            boolean shulker = be instanceof ShulkerBoxBlockEntity;
            if (!(be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || shulker)) continue;
            score += shulker && shulkersCountDouble.get() ? 3 : 1;
            BlockPos p = be.getBlockPos();
            sx += p.getX();
            sy += p.getY();
            sz += p.getZ();
            n++;
            list.add(p.immutable());
        }
        if (score < minContainers.get()) {
            hits.remove(com.blocks.compat.Compat.chunkKey(chunk.getPos()));
            Finds.remove(Finds.Kind.STASH, chunk.getPos());
            return;
        }
        hits.put(com.blocks.compat.Compat.chunkKey(chunk.getPos()), list);
        BlockPos centre = new BlockPos((int) (sx / n), (int) (sy / n), (int) (sz / n));
        Finds.report(Finds.Kind.STASH, chunk.getPos(), centre, n, n + " containers", notify.get());
    }

    @Override
    public void onTick() {
        Finds.setLabels(Finds.Kind.STASH, labels.get());
    }

    @Override
    public void onWorldRender() {
        if (!beams.get()) return;
        for (Finds.Find f : Finds.all()) {
            if (f.kind() != Finds.Kind.STASH) continue;
            Vec3 base = Vec3.atBottomCenterOf(f.pos());
            World3D.beam(base, 120, 0.6, Theme.withAlpha(f.kind().color, 60));
        }
    }

    @Override
    public String getSuffix() {
        return String.valueOf(hits.size());
    }
}
