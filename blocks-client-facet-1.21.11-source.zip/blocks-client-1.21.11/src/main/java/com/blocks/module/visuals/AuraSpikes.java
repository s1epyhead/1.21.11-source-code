package com.blocks.module.visuals;

import com.blocks.BlocksClient;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.ModeSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.Theme;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** A crown of glowing spikes bursting out of your target, slowly turning. Blatant; off by default. */
public class AuraSpikes extends Module {
    private final ModeSetting targets = add(new ModeSetting("Targets", "Target", "Target", "Nearby Players"));
    private final NumSetting count = add(new NumSetting("Spikes", 34, 8, 80, 1));
    private final NumSetting length = add(new NumSetting("Length", 1.1, 0.4, 2.5, 0.05));
    private final BoolSetting upperOnly = add(new BoolSetting("Upper Half", true));

    public AuraSpikes() {
        super("Aura Spikes", "A crown of glowing spikes around your target (blatant)", Category.VISUALS);
    }

    @Override
    public void onWorldRender() {
        if (targets.is("Target")) {
            Player t = BlocksClient.getTarget();
            if (t != null && t.isAlive()) spikes(t);
        } else {
            for (Player p : mc.level.players()) if (p != mc.player && p.isAlive() && p.distanceToSqr(mc.player) < 24 * 24) spikes(p);
        }
    }

    private void spikes(Player p) {
        Theme.Palette pal = Theme.current();
        Vec3 c = World3D.lerpPos(p).add(0, p.getBbHeight() * 0.62, 0);
        int n = count.getInt();
        double time = System.currentTimeMillis() / 1000.0;
        double spin = time * 0.6, golden = Math.PI * (3 - Math.sqrt(5));
        for (int i = 0; i < n; i++) {
            // Even spread over the sphere (Fibonacci), upper half by default like a crown.
            double yv = upperOnly.get() ? 1 - (i + 0.5) / n * 0.95 : 1 - 2 * (i + 0.5) / n;
            double r = Math.sqrt(Math.max(0, 1 - yv * yv));
            double th = golden * i + spin;
            Vec3 dir = new Vec3(Math.cos(th) * r, yv, Math.sin(th) * r);
            double len = length.get() * (0.75 + 0.25 * Math.sin(time * 3 + i * 1.7));
            Vec3 tip = c.add(dir.scale(len));
            Vec3 side = dir.cross(new Vec3(0, 1, 0));
            if (side.lengthSqr() < 1e-4) side = new Vec3(1, 0, 0);
            side = side.normalize().scale(0.05);
            Vec3 b0 = c.add(dir.scale(0.25)).add(side), b1 = c.add(dir.scale(0.25)).subtract(side);
            int base = Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.45), 190);
            int end = Theme.withAlpha(pal.accent(), 10);
            World3D.quad(b0, b1, tip, tip, base, base, end, end);
            World3D.quad(tip, tip, b1, b0, end, end, base, base);
        }
    }
}
