package com.blocks.module.combat;

import com.blocks.BlocksClient;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.render.Gfx;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.CombatUtil;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Smoothly pulls your aim toward the nearest player inside your FOV. */
public class AimAssist extends Module {
    private final NumSetting range = add(new NumSetting("Range", 4.5, 1, 8, 0.1));
    private final NumSetting fov = add(new NumSetting("FOV", 60, 10, 180, 1));
    private final NumSetting speed = add(new NumSetting("Speed", 4, 0.5, 15, 0.5));
    private final BoolSetting vertical = add(new BoolSetting("Vertical", false));
    private final BoolSetting whileClicking = add(new BoolSetting("Only While Clicking", true));

    private long lastFrame;

    public AimAssist() {
        super("Aim Assist", "Helps your crosshair onto targets", Category.COMBAT);
    }

    @Override
    public void onFrame(Gfx g) {
        long now = System.nanoTime();
        double dt = lastFrame == 0 ? 0 : Math.min(0.1, (now - lastFrame) / 1e9);
        lastFrame = now;
        if (com.blocks.compat.Compat.screen() != null) return;
        if (whileClicking.get() && !mc.options.keyAttack.isDown()) return;

        Player target = null;
        double best = fov.get() / 2;
        for (Player p : mc.level.players()) {
            if (p == mc.player || !p.isAlive() || mc.player.distanceTo(p) > range.get()) continue;
            double angle = CombatUtil.angleTo(aimPoint(p));
            if (angle < best) {
                best = angle;
                target = p;
            }
        }
        if (target == null) return;
        BlocksClient.setTarget(target);

        float[] rot = CombatUtil.rotationsTo(aimPoint(target));
        double step = Math.min(1, speed.get() * dt * 3);
        float yawDiff = Mth.wrapDegrees(rot[0] - mc.player.getYRot());
        mc.player.setYRot(mc.player.getYRot() + (float) (yawDiff * step));
        if (vertical.get()) {
            float pitchDiff = rot[1] - mc.player.getXRot();
            mc.player.setXRot(Mth.clamp(mc.player.getXRot() + (float) (pitchDiff * step), -90, 90));
        }
    }

    private static Vec3 aimPoint(Player p) {
        return p.position().add(0, p.getBbHeight() * 0.6, 0);
    }
}
