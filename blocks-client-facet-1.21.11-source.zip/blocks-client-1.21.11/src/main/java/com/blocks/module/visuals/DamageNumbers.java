package com.blocks.module.visuals;

import com.blocks.BlocksClient;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.module.client.ClickGui;
import com.blocks.render.Gfx;
import com.blocks.render.Projection;
import com.blocks.render.Shapes;
import com.blocks.setting.BoolSetting;
import com.blocks.util.Theme;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/** Floating numbers pop out of anything that takes damage (and heals, if you like). */
public class DamageNumbers extends Module {
    private final BoolSetting heals = add(new BoolSetting("Show Heals", false));
    private final BoolSetting self = add(new BoolSetting("Your Own", false));

    private record Pop(Vec3 pos, float amount, long start, double drift) {}

    private final Map<Integer, Float> health = new HashMap<>();
    private final List<Pop> pops = new ArrayList<>();
    private final Random rand = new Random();

    public DamageNumbers() {
        super("Damage Numbers", "Floating numbers when things take damage", Category.VISUALS);
    }

    @Override
    protected void onEnable() {
        health.clear();
    }

    @Override
    public void onTick() {
        Set<Integer> seen = new HashSet<>();
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity le) || e.distanceToSqr(mc.player) > 32 * 32) continue;
            if (e == mc.player && !self.get()) continue;
            seen.add(e.getId());
            float hp = le.getHealth() + le.getAbsorptionAmount();
            Float before = health.put(e.getId(), hp);
            if (before == null) continue;
            float diff = before - hp;
            if (diff > 0.05f || heals.get() && diff < -0.05f) {
                Vec3 at = e.position().add((rand.nextDouble() - 0.5) * 0.6, e.getBbHeight() * 0.8, (rand.nextDouble() - 0.5) * 0.6);
                pops.add(new Pop(at, diff, System.currentTimeMillis(), (rand.nextDouble() - 0.5) * 16));
            }
        }
        health.keySet().retainAll(seen);
        if (pops.size() > 40) pops.subList(0, pops.size() - 40).clear();
    }

    @Override
    public void onFrame(Gfx g) {
        long now = System.currentTimeMillis();
        pops.removeIf(p -> now - p.start > 1100);
        if (pops.isEmpty()) return;
        ClickGui gui = BlocksClient.modules.get(ClickGui.class);
        float k = Hud.scaleFactor();
        g.pose().pushMatrix();
        g.pose().scale(k, k);
        Shapes.begin(g, gui.uiScale());
        Theme.Palette pal = Theme.current();
        for (Pop p : pops) {
            double t = (now - p.start) / 1100.0;
            double[] s = Projection.toGui(p.pos.add(0, t * 0.9, 0), g.guiWidth(), g.guiHeight());
            if (s == null) continue;
            double x = s[0] / k + p.drift * t, y = s[1] / k;
            float scale = (float) (Math.min(1, t * 6) * (1.25 - 0.35 * t) * Math.max(0.6, 1.2 - s[2] / 40));
            int a = (int) (255 * Math.min(1, (1 - t) * 2.2));
            boolean heal = p.amount < 0;
            String txt = (heal ? "+" : "") + (Math.abs(p.amount) >= 10 ? String.valueOf(Math.round(Math.abs(p.amount))) : String.format("%.1f", Math.abs(p.amount)));
            int col = heal ? 0xFF6BE08E : p.amount >= 6 ? pal.accent() : p.amount >= 3 ? pal.accent2() : Theme.TEXT;
            g.pose().pushMatrix();
            g.pose().translate((float) x, (float) y);
            g.pose().scale(scale * 1.3f, scale * 1.3f);
            double w = g.widthBold(txt);
            g.textBold(txt, (int) (-w / 2) + 1, 1, Theme.withAlpha(0xFF000000, a / 2), false);
            g.textBold(txt, (int) (-w / 2), 0, Theme.withAlpha(col, a), false);
            g.pose().popMatrix();
        }
        g.pose().popMatrix();
    }
}
