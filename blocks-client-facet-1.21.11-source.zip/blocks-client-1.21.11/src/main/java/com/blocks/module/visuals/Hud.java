package com.blocks.module.visuals;

import com.google.gson.JsonObject;
import com.blocks.BlocksClient;
import com.blocks.compat.Compat;
import com.blocks.mixin.MusicAccessor;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.module.client.ClickGui;
import com.blocks.render.Gfx;
import com.blocks.render.Shapes;
import com.blocks.setting.BoolSetting;
import com.blocks.util.Config;
import com.blocks.util.InvUtil;
import com.blocks.util.Theme;
import com.blocks.world.Finds;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;

import java.time.LocalTime;
import java.util.*;

public class Hud extends Module {
    public final BoolSetting watermark = add(new BoolSetting("Watermark", true));
    public final BoolSetting arraylist = add(new BoolSetting("Arraylist", true));
    public final BoolSetting nowPlaying = add(new BoolSetting("Now Playing", true));
    public final BoolSetting speed = add(new BoolSetting("Speed Graph", false));
    public final BoolSetting keybinds = add(new BoolSetting("Keybinds", false));
    public final BoolSetting info = add(new BoolSetting("Coordinates", false));
    public final BoolSetting counters = add(new BoolSetting("Item Counters", false));
    public final BoolSetting armorHud = add(new BoolSetting("Armor", false));
    public final BoolSetting potions = add(new BoolSetting("Potions", false));
    public final BoolSetting backgrounds = add(new BoolSetting("Backgrounds", true));
    public final com.blocks.setting.ModeSetting arrayStyle = add(new com.blocks.setting.ModeSetting("Arraylist Style", "Clean", "Clean", "Boxed"));
    public final BoolSetting watermarkXyz = add(new BoolSetting("Top Bar XYZ", false));

    public final List<HudElement> elements = new ArrayList<>();
    /** True while the GUI's Edit HUD Layout mode is drawing the elements itself. */
    public static boolean editing;

    private final Map<Module, Double> slide = new HashMap<>();
    private final double[] speeds = new double[90];
    private int speedIndex;
    private long lastFrame = System.nanoTime();
    private double frameDt;

    public Hud() {
        super("HUD", "Watermark, arraylist, target, music and more", Category.VISUALS);
        setEnabledSilently(true);
        elements.add(new Watermark());
        elements.add(new ArrayListEl());
        elements.add(new NowPlaying());
        elements.add(new Speed());
        elements.add(new Keybinds());
        elements.add(new Info());
        elements.add(new Counters());
        elements.add(new ArmorEl());
        elements.add(new PotionsEl());
        elements.add(new Target());
    }

    @Override
    public boolean hiddenInArraylist() {
        return true;
    }

    @Override
    public void onTick() {
        double v = Math.hypot(mc.player.getX() - mc.player.xo, mc.player.getZ() - mc.player.zo) * 20;
        speeds[speedIndex++ % speeds.length] = v;
    }

    @Override
    public void onFrame(Gfx g) {
        if (editing || Compat.hudHidden()) return;
        renderAll(g, false);
    }

    /** Right edge (UI units) of the open side panel; HUD bits left of it are hidden. -1 when closed. */
    public static double coveredRight = -1;

    /** Off while the menu redraws the HUD, so finder labels don't float over it. */
    public static boolean worldLabels = true;

    /** Top edge of the HUD stack in the bottom-right corner (toasts sit above it). */
    public static double bottomRightTop = Double.MAX_VALUE;

    /** Draws every visible element at Blocks's UI scale (independent of Minecraft's GUI scale). */
    public void renderAll(Gfx g, boolean preview) {
        long now = System.nanoTime();
        frameDt = Math.min(0.1, (now - lastFrame) / 1e9);
        lastFrame = now;
        float k = scaleFactor();
        g.pose().pushMatrix();
        g.pose().scale(k, k);
        Shapes.begin(g, gui().uiScale());
        double sw = g.guiWidth() / k, sh = g.guiHeight() / k;
        if (!preview && worldLabels && coveredRight < 0) Finds.renderLabels(g, sw, sh, k);
        List<double[]> placed = new ArrayList<>();
        double brTop = sh;
        for (HudElement e : elements) {
            if (!e.visible()) continue;
            // Never overlap: push an element past anything already drawn where it would land.
            e.nudge = 0;
            for (int pass = 0; pass < 8; pass++) {
                double ex = e.x(sw), ey = e.y(sh);
                double[] hitRect = null;
                for (double[] r : placed) {
                    if (ex < r[0] + r[2] && ex + e.w > r[0] && ey < r[1] + r[3] && ey + e.h > r[1]) {
                        hitRect = r;
                        break;
                    }
                }
                if (hitRect == null) break;
                e.nudge += e.bottom ? (hitRect[1] - 4) - (ey + e.h) : (hitRect[1] + hitRect[3] + 4) - ey;
            }
            // Don't draw through the side panel while it's open.
            if (!preview && coveredRight > 0 && e.x(sw) < coveredRight) continue;
            e.draw(g, sw, sh, preview);
            placed.add(new double[]{e.x(sw), e.y(sh), e.w, e.h});
            if (e.right && e.bottom) brTop = Math.min(brTop, e.y(sh));
        }
        bottomRightTop = brTop;
        g.pose().popMatrix();
    }

    private static ClickGui gui() {
        return BlocksClient.modules.get(ClickGui.class);
    }

    /** UI units -> GUI units. */
    public static float scaleFactor() {
        return gui().uiScale() / (float) mc.getWindow().getGuiScale();
    }

    public JsonObject savePositions() {
        JsonObject o = new JsonObject();
        for (HudElement e : elements) {
            JsonObject p = new JsonObject();
            p.addProperty("x", e.px);
            p.addProperty("y", e.py);
            p.addProperty("right", e.right);
            p.addProperty("bottom", e.bottom);
            o.add(e.name, p);
        }
        return o;
    }

    public void loadPositions(JsonObject o) {
        for (HudElement e : elements) {
            if (!o.has(e.name)) continue;
            JsonObject p = o.getAsJsonObject(e.name);
            e.px = p.get("x").getAsDouble();
            e.py = p.get("y").getAsDouble();
            e.right = p.get("right").getAsBoolean();
            e.bottom = p.has("bottom") && p.get("bottom").getAsBoolean();
        }
    }

    private int bg(int alpha) {
        return backgrounds.get() ? Theme.withAlpha(0xFF0E0E14, alpha) : 0;
    }

    private void card(double x, double y, double w, double h, double r) {
        if (!backgrounds.get()) return;
        Shapes.roundRect(x, y, w, h, r, bg(190));
        Shapes.roundOutline(x, y, w, h, r, 0.8, Theme.withAlpha(0xFFFFFF, 22));
    }

    private static boolean glowOn() {
        return gui().glow.get();
    }

    private int ping() {
        if (mc.getConnection() == null) return 0;
        PlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        return info == null ? 0 : info.getLatency();
    }

    // ------------------------------------------------------------------ elements

    private class Watermark extends HudElement {
        Watermark() { super("Watermark", 8, 8, false, false); }

        @Override public boolean visible() { return watermark.get(); }

        @Override
        protected void render(Gfx g, double x, double y, boolean preview) {
            // Just the numbers: fps, ping, time. Each value is bright, its unit is dim.
            LocalTime t = LocalTime.now();
            int fps = mc.getFps(), ms = ping();
            String[][] parts = watermarkXyz.get()
                    ? new String[][]{{String.valueOf(fps), "FPS"}, {String.valueOf(ms), "MS"},
                            {mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ(), "XYZ"},
                            {String.format("%02d:%02d", t.getHour(), t.getMinute()), ""}}
                    : new String[][]{{String.valueOf(fps), "FPS"}, {String.valueOf(ms), "MS"},
                            {String.format("%02d:%02d", t.getHour(), t.getMinute()), ""}};
            double total = 0;
            for (String[] p : parts) total += g.widthMono(p[0], 0.82f) + (p[1].isEmpty() ? 0 : 3 + g.widthMono(p[1], 0.62f)) + 14;
            w = 10 + total - 6;
            h = 16;
            if (backgrounds.get()) {
                Shapes.roundRect(x, y, w, h, 8, bg(175));
                Shapes.roundOutline(x, y, w, h, 8, 0.7, Theme.withAlpha(0xFFFFFF, 20));
            }
            Theme.Palette pal = Theme.current();
            double tx = x + 8;
            for (int i = 0; i < parts.length; i++) {
                String[] p = parts[i];
                if (i > 0) Shapes.circle(tx - 7, y + h / 2, 1, Theme.withAlpha(0xFFFFFF, 60));
                int col = i == 0 ? (fps < 30 ? 0xFFFF6B6B : Theme.TEXT) : i == 1 ? (ms > 150 ? 0xFFFFB04D : Theme.TEXT) : i == parts.length - 1 ? Theme.TEXT_DIM : Theme.TEXT;
                g.textMono(p[0], tx, y + 4.8, col, 0.82f);
                tx += g.widthMono(p[0], 0.82f);
                if (!p[1].isEmpty()) {
                    g.textMono(p[1], tx + 3, y + 5.8, Theme.withAlpha(pal.accent2(), 200), 0.62f);
                    tx += 3 + g.widthMono(p[1], 0.62f);
                }
                tx += 14;
            }
        }
    }

    private class ArrayListEl extends HudElement {
        ArrayListEl() { super("Arraylist", 8, 8, true, false); }

        @Override public boolean visible() { return arraylist.get(); }

        @Override
        protected void render(Gfx g, double x, double y, boolean preview) {
            boolean anim = gui().animations.get();
            List<Module> list = new ArrayList<>();
            for (Module m : BlocksClient.modules.all()) {
                if (m.hiddenInArraylist()) continue;
                double s = slide.getOrDefault(m, 0.0);
                double target = m.isEnabled() ? 1 : 0;
                s = anim ? s + (target - s) * (1 - Math.exp(-frameDt * 14)) : target;
                if (Math.abs(s - target) < 0.01) s = target;
                slide.put(m, s);
                if (s > 0.01) list.add(m);
            }
            list.sort(Comparator.comparingDouble(m -> -rowWidth(g, m)));
            double maxW = 40;
            for (Module m : list) maxW = Math.max(maxW, rowWidth(g, m));
            w = maxW;
            double rowH = arrayStyle.is("Boxed") ? 13 : 11;
            h = Math.max(rowH, list.size() * rowH);
            if (preview && list.isEmpty()) g.text("Arraylist", (int) x, (int) y + 2, Theme.TEXT_DIM, true);
            double ry = y;
            int i = 0;
            for (Module m : list) {
                double s = slide.get(m);
                double rw = rowWidth(g, m);
                double rx = right ? x + w - rw * s : x - rw * (1 - s);
                int alpha = (int) (255 * s);
                int c = Theme.withAlpha(Theme.accentAt(i * 0.35), alpha);
                if (arrayStyle.is("Boxed")) {
                    // Each module in its own outlined box, text in the accent colour.
                    Shapes.rect(rx, ry + 0.5, rw, rowH * s - 1, Theme.withAlpha(0xFF0E0E14, (int) (120 * s)));
                    Shapes.rect(rx, ry + 0.5, rw, 0.7, c);
                    Shapes.rect(rx, ry + rowH * s - 1.2, rw, 0.7, c);
                    Shapes.rect(rx, ry + 0.5, 0.7, rowH * s - 1, c);
                    Shapes.rect(rx + rw - 0.7, ry + 0.5, 0.7, rowH * s - 1, c);
                    g.text(m.getName(), (int) (rx + 5), (int) ry + 2, c, true);
                } else {
                    if (backgrounds.get()) Shapes.rect(rx, ry, rw, rowH * s, Theme.withAlpha(0xFF0E0E14, (int) (150 * s)));
                    Shapes.rect(right ? rx + rw - 1.4 : rx, ry, 1.4, rowH * s, c);
                    g.text(m.getName(), (int) (rx + 5), (int) ry + 2, Theme.withAlpha(Theme.TEXT, Math.max(alpha, 6)), true);
                }
                String suffix = m.getSuffix();
                if (suffix != null) g.textMono(suffix, rx + 5 + g.width(m.getName()) + 4, ry + 2.6, Theme.withAlpha(Theme.TEXT_FAINT, Math.max(alpha, 6)), 0.75f);
                ry += rowH * s;
                i++;
            }
        }

        private double rowWidth(Gfx g, Module m) {
            String suffix = m.getSuffix();
            return g.width(m.getName()) + (suffix == null ? 0 : g.widthMono(suffix, 0.75f) + 4) + 10;
        }
    }

    private class NowPlaying extends HudElement {
        NowPlaying() { super("Now Playing", 8, 30, false, false); }

        @Override public boolean visible() { return nowPlaying.get(); }

        private String track(boolean preview) {
            SoundInstance s = ((MusicAccessor) mc.getMusicManager()).blocks$current();
            if (s == null || s.getSound() == null) return preview ? "Sweden" : null;
            String path = s.getSound().getLocation().getPath();
            String file = path.substring(path.lastIndexOf('/') + 1);
            StringBuilder out = new StringBuilder();
            for (String word : file.split("_")) {
                if (word.isEmpty()) continue;
                if (!out.isEmpty()) out.append(' ');
                out.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
            }
            return out.toString();
        }

        @Override
        protected void render(Gfx g, double x, double y, boolean preview) {
            String track = track(preview);
            w = 120;
            h = 26;
            if (track == null) {
                if (preview) g.text("Now Playing", (int) x, (int) y, Theme.TEXT_DIM, true);
                return;
            }
            w = Math.max(110, g.width(track) + 40);
            card(x, y, w, h, 8);
            double t = System.currentTimeMillis() / 1000.0;
            for (int i = 0; i < 4; i++) {
                double bh = 3 + 7 * (0.5 + 0.5 * Math.sin(t * (5 + i * 1.7) + i * 2.1));
                Shapes.roundRect(x + 9 + i * 3.6, y + 18 - bh, 2.2, bh, 1.1, Theme.accentAt(i * 0.4));
            }
            g.textScaled("NOW PLAYING", x + 28, y + 5, Theme.TEXT_FAINT, 0.66f);
            g.text(track, (int) x + 28, (int) y + 13, Theme.TEXT, false);
        }
    }

    private class Speed extends HudElement {
        Speed() { super("Speed", 8, 52, true, true); }

        @Override public boolean visible() { return speed.get(); }

        @Override
        protected void render(Gfx g, double x, double y, boolean preview) {
            w = 120;
            h = 38;
            card(x, y, w, h, 8);
            double max = 4;
            for (double v : speeds) max = Math.max(max, v);
            double cur = speeds[Math.floorMod(speedIndex - 1, speeds.length)];
            g.textScaled("BPS", x + 8, y + 6, Theme.TEXT_FAINT, 0.7f);
            g.textMono(String.format("%.2f", cur), x + 25, y + 5, Theme.TEXT, 0.85f);
            String mx = String.format("max %.1f", max);
            g.textMono(mx, x + w - 8 - g.widthMono(mx, 0.65f), y + 6, Theme.TEXT_FAINT, 0.65f);
            double gx = x + 7, gy = y + 15, gw = w - 14, gh = 18;
            int n = speeds.length;
            double step = gw / (n - 1);
            for (int i = 0; i < n; i++) {
                double v = speeds[(speedIndex + i) % n];
                double bh = Math.max(0.6, v / max * gh);
                Shapes.rect(gx + i * step, gy + gh - bh, step + 0.1, bh, Theme.withAlpha(Theme.accent(), 40));
                Shapes.rect(gx + i * step, gy + gh - bh, step + 0.1, 0.8, Theme.withAlpha(Theme.accentAt(i * 0.02), 230));
            }
        }
    }

    private class Keybinds extends HudElement {
        Keybinds() { super("Keybinds", 8, 60, false, false); }

        @Override public boolean visible() { return keybinds.get(); }

        @Override
        protected void render(Gfx g, double x, double y, boolean preview) {
            List<Module> bound = new ArrayList<>();
            for (Module m : BlocksClient.modules.all()) if (m.getKey() > 0 && !(m instanceof ClickGui)) bound.add(m);
            w = 110;
            for (Module m : bound) w = Math.max(w, g.width(m.getName()) + g.widthMono(Compat.keyName(m.getKey()), 0.75f) + 32);
            h = 18 + Math.max(1, bound.size()) * 11 + 3;
            card(x, y, w, h, 8);
            g.textBold("Keybinds", (int) x + 8, (int) y + 5, Theme.TEXT, false);
            double rowY = y + 19;
            if (bound.isEmpty()) g.textScaled("Nothing bound", x + 8, rowY, Theme.TEXT_FAINT, 0.84f);
            for (Module m : bound) {
                Shapes.circle(x + 10, rowY + 3.5, 2, m.isEnabled() ? Theme.accent() : 0xFF55505A);
                g.text(m.getName(), (int) x + 16, (int) rowY, m.isEnabled() ? Theme.TEXT : Theme.TEXT_DIM, false);
                String key = Compat.keyName(m.getKey());
                g.textMono(key, x + w - 8 - g.widthMono(key, 0.75f), rowY + 0.8, Theme.TEXT_FAINT, 0.75f);
                rowY += 11;
            }
        }
    }

    private class Info extends HudElement {
        Info() { super("Coordinates", 8, 8, false, true); }

        @Override public boolean visible() { return info.get(); }

        @Override
        protected void render(Gfx g, double x, double y, boolean preview) {
            var p = mc.player;
            String xyz = String.format("%.0f  %.0f  %.0f", p.getX(), p.getY(), p.getZ());
            boolean nether = mc.level.dimension() == net.minecraft.world.level.Level.NETHER;
            String other = nether ? String.format("%.0f  %.0f overworld", p.getX() * 8, p.getZ() * 8) : String.format("%.0f  %.0f nether", p.getX() / 8, p.getZ() / 8);
            w = Math.max(g.widthMono(xyz, 0.8f), g.widthMono(other, 0.7f)) + 34;
            h = 26;
            card(x, y, w, h, 8);
            g.textScaled("XYZ", x + 8, y + 6, Theme.TEXT_FAINT, 0.7f);
            g.textMono(xyz, x + 26, y + 5, Theme.TEXT, 0.8f);
            g.textMono(other, x + 26, y + 15, Theme.TEXT_FAINT, 0.7f);
        }
    }

    private class Counters extends HudElement {
        private final Item[] items = {Items.TOTEM_OF_UNDYING, Items.END_CRYSTAL, Items.OBSIDIAN, Items.RESPAWN_ANCHOR,
                Items.GLOWSTONE, Items.ENDER_PEARL, Items.EXPERIENCE_BOTTLE};
        private final ItemStack[] stacks = new ItemStack[items.length];

        Counters() { super("Counters", 8, 8, true, true); }

        @Override public boolean visible() { return counters.get(); }

        @Override
        protected void render(Gfx g, double x, double y, boolean preview) {
            w = items.length * 20 + 6;
            h = 24;
            card(x, y, w, h, 8);
            for (int i = 0; i < items.length; i++) {
                if (stacks[i] == null) stacks[i] = new ItemStack(items[i]);
                Item item = items[i];
                int count = InvUtil.count(s -> s.is(item));
                double ix = x + 13 + i * 20, iy = y + 11;
                g.itemIcon(stacks[i], ix, iy, 14, Shapes.scale());
                String c = String.valueOf(count);
                g.textMono(c, ix + 8 - g.widthMono(c, 0.7f), iy + 4, count == 0 ? 0xFFFF6B6B : Theme.TEXT, 0.7f);
            }
        }
    }

    private class ArmorEl extends HudElement {
        private final net.minecraft.world.entity.EquipmentSlot[] slots = {net.minecraft.world.entity.EquipmentSlot.HEAD,
                net.minecraft.world.entity.EquipmentSlot.CHEST, net.minecraft.world.entity.EquipmentSlot.LEGS, net.minecraft.world.entity.EquipmentSlot.FEET};

        ArmorEl() { super("Armor", 8, 40, true, true); }

        @Override public boolean visible() { return armorHud.get(); }

        @Override
        protected void render(Gfx g, double x, double y, boolean preview) {
            w = slots.length * 24 + 4;
            h = 30;
            card(x, y, w, h, 8);
            for (int i = 0; i < slots.length; i++) {
                ItemStack st = mc.player.getItemBySlot(slots[i]);
                double ix = x + 14 + i * 24;
                if (st.isEmpty()) {
                    Shapes.roundRect(ix - 7, y + 5, 14, 14, 4, Theme.withAlpha(0xFFFFFF, 12));
                    continue;
                }
                g.itemIcon(st, ix, y + 12, 14, Shapes.scale());
                if (st.isDamageableItem()) {
                    double d = 1 - st.getDamageValue() / (double) st.getMaxDamage();
                    String pct = (int) Math.round(d * 100) + "";
                    g.textMono(pct, ix - g.widthMono(pct, 0.62f) / 2, y + 21.5, Theme.health((float) d), 0.62f);
                }
            }
        }
    }

    private class PotionsEl extends HudElement {
        PotionsEl() { super("Potions", 8, 120, true, false); }

        @Override public boolean visible() { return potions.get(); }

        @Override
        protected void render(Gfx g, double x, double y, boolean preview) {
            var effects = new ArrayList<>(mc.player.getActiveEffects());
            List<String[]> rows = new ArrayList<>();
            for (var e : effects) {
                String name = e.getEffect().value().getDisplayName().getString();
                int amp = e.getAmplifier();
                if (amp > 0) name += " " + (amp + 1);
                int secs = e.getDuration() / 20;
                String time = e.isInfiniteDuration() ? "**" : String.format("%d:%02d", secs / 60, secs % 60);
                rows.add(new String[]{name, time, String.valueOf(e.getEffect().value().getColor())});
            }
            if (rows.isEmpty() && preview) rows.add(new String[]{"Strength 2", "1:30", String.valueOf(0xFFC33E3E)});
            double maxW = 60;
            for (String[] r : rows) maxW = Math.max(maxW, g.width(r[0]) * 0.86 + g.widthMono(r[1], 0.74f) + 30);
            w = maxW;
            h = Math.max(12, rows.size() * 13 + 4);
            card(x, y, w, h, 7);
            double ry = y + 3;
            for (String[] r : rows) {
                int col = 0xFF000000 | Integer.parseInt(r[2]);
                Shapes.circle(x + 8, ry + 5, 2.5, col);
                g.textScaled(r[0], x + 15, ry + 1.5, Theme.TEXT, 0.86f);
                g.textMono(r[1], x + w - 6 - g.widthMono(r[1], 0.74f), ry + 2.5, Theme.TEXT_DIM, 0.74f);
                ry += 13;
            }
        }
    }

    private class Target extends HudElement {
        private double shownHealth = -1;
        private Player last;

        Target() { super("Target", 0, 0, false, false); }

        @Override public boolean visible() {
            return BlocksClient.modules.get(TargetHud.class).isEnabled();
        }

        @Override
        public void draw(Gfx g, double sw, double sh, boolean preview) {
            if (px == 0 && py == 0) {
                px = sw / 2 + 24;
                py = sh / 2 + 16;
            }
            super.draw(g, sw, sh, preview);
        }

        @Override
        protected void render(Gfx g, double x, double y, boolean preview) {
            w = 150;
            h = 46;
            Player t = BlocksClient.getTarget();
            if (t == null && BlocksClient.modules.get(TargetHud.class).crosshairTargets.get()
                    && mc.hitResult instanceof EntityHitResult ehr && ehr.getEntity() instanceof Player p) t = p;
            if (t == null && preview) t = mc.player;
            if (t == null) {
                last = null;
                return;
            }
            float hp = t.getHealth() + t.getAbsorptionAmount();
            if (t != last || shownHealth < 0) shownHealth = hp;
            last = t;
            shownHealth += (hp - shownHealth) * (1 - Math.exp(-frameDt * 10));
            if (glowOn()) Shapes.glow(x, y, w, h, 10, 8, Theme.withAlpha(Theme.accent(), 50));
            Shapes.roundRect(x, y, w, h, 10, Theme.withAlpha(0xFF0E0E14, 225));
            Shapes.roundOutline(x, y, w, h, 10, 0.8, Theme.withAlpha(Theme.accent(), 110));
            Shapes.roundRect(x + 6, y + 6, 34, 34, 7, Theme.withAlpha(0xFFFFFF, 14));
            if (t instanceof net.minecraft.client.player.AbstractClientPlayer acp) g.head(acp.getSkin(), (int) x + 9, (int) y + 9, 28);
            g.textBold(t.getName().getString(), (int) x + 46, (int) y + 7, Theme.TEXT, false);
            String dist = String.format("%.1fm", mc.player.distanceTo(t));
            g.textMono(dist, x + w - 8 - g.widthMono(dist, 0.72f), y + 8, Theme.TEXT_FAINT, 0.72f);
            // Armour, small, under the name.
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND};
            double ax = x + 50;
            for (EquipmentSlot s : slots) {
                ItemStack st = t.getItemBySlot(s);
                if (!st.isEmpty()) g.itemIcon(st, ax, y + 23, 10, Shapes.scale());
                ax += 12;
            }
            double pct = Math.min(1, shownHealth / t.getMaxHealth());
            double bx = x + 46, bw = w - 54, by = y + 34;
            Shapes.roundRect(bx, by, bw, 4, 2, Theme.withAlpha(0xFFFFFF, 26));
            Shapes.roundRect(bx, by, Math.max(4, bw * pct), 4, 2, Theme.health((float) pct));
            String hpText = String.format("%.1f", hp);
            g.textMono(hpText, x + w - 8 - g.widthMono(hpText, 0.72f), y + 22, Theme.TEXT_DIM, 0.72f);
        }
    }
}
