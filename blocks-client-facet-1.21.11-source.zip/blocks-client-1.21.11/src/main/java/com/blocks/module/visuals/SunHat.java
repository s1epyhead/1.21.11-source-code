package com.blocks.module.visuals;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.Theme;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** A striped beach-umbrella hat floating over your head (and other players', if you like). */
public class SunHat extends Module {
    private final NumSetting size = add(new NumSetting("Size", 1.0, 0.5, 2, 0.05));
    private final com.blocks.setting.ModeSetting style = add(new com.blocks.setting.ModeSetting("Style", "Beach", "Beach", "China"));
    private final com.blocks.setting.ModeSetting wearers = add(new com.blocks.setting.ModeSetting("Wearers", "You", "You", "You + Target", "Everyone"));
    private final BoolSetting spin = add(new BoolSetting("Spin", true));

    public SunHat() {
        super("Sun Hat", "A striped beach umbrella hat over your head", Category.VISUALS);
    }

    @Override
    public void onWorldRender() {
        boolean thirdPerson = !mc.options.getCameraType().isFirstPerson() || com.blocks.BlocksClient.modules.get(Freecam.class).active();
        if (thirdPerson) hat(mc.player);
        if (wearers.is("Everyone")) {
            for (Player p : mc.level.players()) if (p != mc.player && p.distanceToSqr(mc.player) < 64 * 64) hat(p);
        } else if (wearers.is("You + Target")) {
            Player t = com.blocks.BlocksClient.getTarget();
            if (t != null && t != mc.player) hat(t);
        }
    }

    private void hat(Player p) {
        Theme.Palette pal = Theme.current();
        Vec3 base = World3D.lerpPos(p);
        double s = size.get();
        double top = base.y + p.getBbHeight() + 0.08;
        Vec3 apex = new Vec3(base.x, top + 0.32 * s, base.z);
        double r = 0.62 * s, rimY = top + 0.02;
        int segs = 24;
        double rot = spin.get() ? (System.currentTimeMillis() % 12000) / 12000.0 * Math.PI * 2 : Math.toRadians(-p.getYRot());
        for (int i = 0; i < segs; i++) {
            double a0 = rot + Math.PI * 2 * i / segs, a1 = rot + Math.PI * 2 * (i + 1) / segs;
            Vec3 b0 = new Vec3(base.x + Math.cos(a0) * r, rimY, base.z + Math.sin(a0) * r);
            Vec3 b1 = new Vec3(base.x + Math.cos(a1) * r, rimY, base.z + Math.sin(a1) * r);
            boolean china = style.is("China");
            int c = china ? Theme.withAlpha(Theme.blend(pal.accent(), 0xFF8FD8FF, 0.35), 130)
                    : Theme.withAlpha((i / 3) % 2 == 0 ? pal.accent() : 0xFFFFF4E6, 175);
            int tip = china ? Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.5), 170) : c;
            World3D.quad(apex, apex, b1, b0, tip, tip, c, c);
            World3D.quad(b0, b1, apex, apex, c, c, tip, tip);
            int rim = china ? Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.6), 240) : Theme.withAlpha(pal.accent2(), 230);
            World3D.line(b0, b1, rim, rim, china ? 2.2f : 1.6f);
        }
    }
}
