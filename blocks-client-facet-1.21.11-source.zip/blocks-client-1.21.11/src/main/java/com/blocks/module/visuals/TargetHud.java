package com.blocks.module.visuals;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;

/** Shows the player you are fighting. Drawn by the HUD (so it can be dragged in Edit HUD Layout). */
public class TargetHud extends Module {
    public final BoolSetting crosshairTargets = add(new BoolSetting("Crosshair Targets", true));

    public TargetHud() {
        super("Target HUD", "Health and info of your target", Category.VISUALS);
        setEnabledSilently(true);
    }

    @Override
    public boolean hiddenInArraylist() {
        return true;
    }
}
