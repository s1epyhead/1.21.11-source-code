package com.blocks.module.world;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.world.ChunkScanner;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Predicate;

/** Base for modules that scan loaded chunks and keep per-chunk results. */
public abstract class FinderModule extends Module implements ChunkScanner.Scanner {
    protected final Map<Long, List<BlockPos>> hits = new HashMap<>();

    protected FinderModule(String name, String description) {
        super(name, description, Category.WORLD);
        ChunkScanner.register(this);
    }

    @Override
    public boolean active() {
        return isEnabled();
    }

    @Override
    protected void onEnable() {
        clear();
        ChunkScanner.rescan();
    }

    @Override
    protected void onDisable() {
        clear();
    }

    @Override
    public void forget(ChunkPos pos) {
        hits.remove(com.blocks.compat.Compat.chunkKey(pos));
    }

    @Override
    public void clear() {
        hits.clear();
    }

    protected int totalHits() {
        int n = 0;
        for (List<BlockPos> l : hits.values()) n += l.size();
        return n;
    }

    /**
     * Visits every block in [minY, maxY] matching {@code match}. Sections that
     * cannot contain a match (per their palette) are skipped without reading blocks.
     */
    protected static void forEachBlock(LevelChunk chunk, int minY, int maxY, Predicate<BlockState> match,
                                       BiConsumer<BlockPos.MutableBlockPos, BlockState> out) {
        LevelChunkSection[] sections = chunk.getSections();
        int baseY = chunk.getMinY();
        int bx = com.blocks.compat.Compat.chunkX(chunk.getPos()) << 4, bz = com.blocks.compat.Compat.chunkZ(chunk.getPos()) << 4;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int i = 0; i < sections.length; i++) {
            LevelChunkSection s = sections[i];
            int sy = baseY + i * 16;
            if (s == null || s.hasOnlyAir() || sy + 15 < minY || sy > maxY || !s.maybeHas(match)) continue;
            for (int y = 0; y < 16; y++) {
                int wy = sy + y;
                if (wy < minY || wy > maxY) continue;
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        BlockState st = s.getBlockState(x, y, z);
                        if (match.test(st)) {
                            m.set(bx + x, wy, bz + z);
                            out.accept(m, st);
                        }
                    }
                }
            }
        }
    }

    /**
     * Iterates the positions within range that still hold what we found, dropping
     * the ones that changed (mined, broken), so highlights and tracers vanish at once.
     */
    protected void forEachLive(double range, java.util.function.Predicate<BlockPos> stillThere,
                               java.util.function.Consumer<BlockPos> draw, int limit) {
        if (mc.player == null) return;
        int drawn = 0;
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ(), r2 = range * range;
        Iterator<Map.Entry<Long, List<BlockPos>>> chunks = hits.entrySet().iterator();
        while (chunks.hasNext()) {
            List<BlockPos> list = chunks.next().getValue();
            Iterator<BlockPos> it = list.iterator();
            while (it.hasNext()) {
                BlockPos p = it.next();
                if (drawn >= limit || sqrDist(p, px, py, pz) > r2) continue;
                if (!stillThere.test(p)) {
                    it.remove();
                    continue;
                }
                draw.accept(p);
                drawn++;
            }
            if (list.isEmpty()) chunks.remove();
        }
    }

    protected boolean inRange(BlockPos pos, double range) {
        return mc.player != null && mc.player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= range * range;
    }

    protected static double sqrDist(BlockPos a, double x, double y, double z) {
        double dx = a.getX() + 0.5 - x, dy = a.getY() + 0.5 - y, dz = a.getZ() + 0.5 - z;
        return dx * dx + dy * dy + dz * dz;
    }
}
