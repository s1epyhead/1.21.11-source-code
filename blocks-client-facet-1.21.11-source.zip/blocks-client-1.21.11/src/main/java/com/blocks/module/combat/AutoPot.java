package com.blocks.module.combat;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.CombatUtil;
import com.blocks.util.InvUtil;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;

/** Throws a splash healing potion at your feet when your health is low. */
public class AutoPot extends Module {
    private final NumSetting health = add(new NumSetting("Health", 8, 1, 20, 0.5));
    private final NumSetting delay = add(new NumSetting("Delay", 10, 2, 40, 1));
    private final BoolSetting switchBack = add(new BoolSetting("Switch Back", true));

    private int timer;

    public AutoPot() {
        super("Auto Pot", "Splashes healing potions when low", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (timer++ < delay.getInt()) return;
        if (CombatUtil.health(mc.player) > health.get()) return;
        int slot = InvUtil.findHotbar(AutoPot::isHealing);
        if (slot == -1) return;

        int prevSlot = InvUtil.selected();
        float prevPitch = mc.player.getXRot();
        InvUtil.select(slot);
        mc.player.setXRot(90);
        InvUtil.useItem(InteractionHand.MAIN_HAND);
        mc.player.setXRot(prevPitch);
        if (switchBack.get()) InvUtil.select(prevSlot);
        timer = 0;
    }

    private static boolean isHealing(ItemStack s) {
        if (!s.is(Items.SPLASH_POTION)) return false;
        PotionContents contents = s.get(DataComponents.POTION_CONTENTS);
        return contents != null && (contents.is(Potions.HEALING) || contents.is(Potions.STRONG_HEALING));
    }
}
