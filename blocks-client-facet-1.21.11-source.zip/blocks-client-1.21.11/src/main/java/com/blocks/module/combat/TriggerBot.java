package com.blocks.module.combat;

import com.blocks.BlocksClient;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.InvUtil;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.EntityHitResult;

/** Attacks whatever is under your crosshair once your swing has recharged. */
public class TriggerBot extends Module {
    private final NumSetting cooldown = add(new NumSetting("Cooldown", 0.92, 0.5, 1.0, 0.01));
    private final BoolSetting playersOnly = add(new BoolSetting("Players Only", true));
    private final BoolSetting weaponOnly = add(new BoolSetting("Weapon Only", true));
    private final BoolSetting critsOnly = add(new BoolSetting("Only Crits When Falling", false));

    public TriggerBot() {
        super("TriggerBot", "Hits targets under your crosshair", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player.isUsingItem()) return;
        if (!(mc.hitResult instanceof EntityHitResult ehr)) return;
        Entity e = ehr.getEntity();
        if (!(e instanceof LivingEntity living) || !living.isAlive()) return;
        if (playersOnly.get() && !(e instanceof Player)) return;
        if (weaponOnly.get() && !isWeapon(mc.player.getMainHandItem())) return;
        if (mc.player.getAttackStrengthScale(0.5f) < cooldown.getFloat()) return;
        if (critsOnly.get() && !mc.player.onGround() && mc.player.getDeltaMovement().y >= 0) return;
        if (e instanceof Player p) BlocksClient.setTarget(p);
        InvUtil.attack(e);
    }

    static boolean isWeapon(ItemStack s) {
        return s.is(ItemTags.SWORDS) || s.is(ItemTags.AXES) || s.is(net.minecraft.world.item.Items.MACE)
                || s.is(net.minecraft.world.item.Items.TRIDENT);
    }
}
