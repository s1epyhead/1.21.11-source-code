package com.blocks.module.visuals;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.render.World3D;
import com.blocks.util.Theme;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** A little glass block with eyes that floats by your shoulder, bobbing and blinking. Off by default. */
public class Companion extends Module {
    private Vec3 pos;

    public Companion() {
        super("Companion", "A floating glass-block buddy by your shoulder", Category.VISUALS);
    }

    @Override
    protected void onEnable() {
        pos = null;
    }

    @Override
    public void onWorldRender() {
        Vec3 me = World3D.lerpPos(mc.player);
        double yaw = Math.toRadians(mc.player.yBodyRot);
        double time = System.currentTimeMillis() / 1000.0;
        // Just behind and to the right of you, bobbing.
        // forward = (-sin, cos), right = (-cos, -sin): 0.8 to the right, 0.5 behind.
        Vec3 want = me.add(-Math.cos(yaw) * 0.8 + Math.sin(yaw) * 0.5, 1.85 + Math.sin(time * 2) * 0.08, -Math.sin(yaw) * 0.8 - Math.cos(yaw) * 0.5);
        pos = pos == null ? want : pos.add(want.subtract(pos).scale(0.12));
        double s = 0.17;
        AABB body = new AABB(pos.x - s, pos.y - s, pos.z - s, pos.x + s, pos.y + s, pos.z + s);
        Theme.Palette pal = Theme.current();
        World3D.boxFill(body, Theme.withAlpha(Theme.blend(pal.accent(), 0xFFFFFFFF, 0.35), 150));
        World3D.boxLines(body, Theme.withAlpha(0xFFFFFFFF, 230), 1.6f);
        World3D.boxFill(body.deflate(0.05), Theme.withAlpha(pal.accent(), 90));
        // Eyes on the face that points at the camera.
        Vec3 cam = World3D.camera();
        double dx = cam.x - pos.x, dz = cam.z - pos.z;
        boolean blink = (time % 4.0) > 3.86;
        double eh = blink ? 0.012 : 0.05, ew = 0.03;
        for (int side = -1; side <= 1; side += 2) {
            AABB eye;
            if (Math.abs(dx) > Math.abs(dz)) {
                double fx = pos.x + Math.signum(dx) * (s + 0.003);
                eye = new AABB(fx - 0.004, pos.y + 0.02 - eh, pos.z + side * 0.07 - ew, fx + 0.004, pos.y + 0.02 + eh, pos.z + side * 0.07 + ew);
            } else {
                double fz = pos.z + Math.signum(dz) * (s + 0.003);
                eye = new AABB(pos.x + side * 0.07 - ew, pos.y + 0.02 - eh, fz - 0.004, pos.x + side * 0.07 + ew, pos.y + 0.02 + eh, fz + 0.004);
            }
            World3D.boxFill(eye, 0xF0101018);
        }
        World3D.ring(new Vec3(pos.x, pos.y - 0.32, pos.z), 0.14 + 0.02 * Math.sin(time * 2), 0.0, Theme.withAlpha(pal.accent(), 120), 20);
    }
}
