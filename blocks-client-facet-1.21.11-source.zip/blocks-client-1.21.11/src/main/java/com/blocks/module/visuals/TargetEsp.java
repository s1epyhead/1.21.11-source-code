package com.blocks.module.visuals;

import com.blocks.BlocksClient;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.ModeSetting;
import com.blocks.util.Theme;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/** A glowing ring that slides up and down your target, with an optional halo. */
public class TargetEsp extends Module {
    private final ModeSetting targets = add(new ModeSetting("Targets", "Players", "Players", "All"));
    private final ModeSetting style = add(new ModeSetting("Style", "Ring", "Ring", "Rune", "Both"));
    private final BoolSetting halo = add(new BoolSetting("Halo", true));
    private final BoolSetting hitbox = add(new BoolSetting("Hitbox", false));
    private final BoolSetting orbitArc = add(new BoolSetting("Orbit Arc", false));
    private final BoolSetting crosshairTargets = add(new BoolSetting("Crosshair Targets", true));

    private LivingEntity last;
    private long lastSeen;

    public TargetEsp() {
        super("Target ESP", "Animated ring around the player you're fighting", Category.VISUALS);
    }

    private LivingEntity target() {
        LivingEntity t = BlocksClient.getTarget();
        if (t == null && crosshairTargets.get() && mc.hitResult instanceof EntityHitResult ehr && ehr.getEntity() instanceof LivingEntity le) {
            if (targets.is("All") || le instanceof Player) t = le;
        }
        if (t != null) {
            last = t;
            lastSeen = System.currentTimeMillis();
        } else if (last != null && System.currentTimeMillis() - lastSeen < 1500 && last.isAlive()) {
            t = last;
        }
        return t;
    }

    @Override
    public void onWorldRender() {
        LivingEntity t = target();
        if (t == null) return;
        Vec3 pos = World3D.lerpPos(t);
        double h = t.getBbHeight(), r = t.getBbWidth() * 0.85 + 0.1;
        double phase = (Math.sin(System.currentTimeMillis() / 520.0) + 1) / 2;
        int c = Theme.current().accent(), c2 = Theme.current().accent2();
        if (!style.is("Rune")) World3D.ring(pos.add(0, h * phase, 0), r, 0.35, Theme.withAlpha(Theme.blend(c, c2, phase), 220), 40);
        if (!style.is("Ring")) rune(pos.add(0, 0.03, 0), Math.max(1.1, r * 2.1));
        if (halo.get()) World3D.ring(pos.add(0, h + 0.22, 0), r * 0.55, 0.04, Theme.withAlpha(0xFFFFFFFF, 210), 32);
        if (orbitArc.get()) orbitArc(pos.add(0, 0.04, 0), Math.max(1.35, r * 2.6));
        if (hitbox.get()) {
            double w = t.getBbWidth() / 2;
            var box = new net.minecraft.world.phys.AABB(pos.x - w, pos.y, pos.z - w, pos.x + w, pos.y + h, pos.z + w);
            World3D.boxFill(box, Theme.withAlpha(Theme.blend(c, 0xFFFFFFFF, 0.5), 28));
            World3D.boxLines(box, Theme.withAlpha(Theme.blend(c, 0xFFFFFFFF, 0.5), 220), 1.6f);
        }
    }

    /** A bright ring segment sweeping around the target, with rungs like a track. */
    private void orbitArc(Vec3 c, double R) {
        double rot = System.currentTimeMillis() / 700.0;
        double span = Math.toRadians(150), w = 0.22;
        int segs = 28;
        int bright = Theme.withAlpha(0xFFFFFFFF, 230);
        for (int i = 0; i < segs; i++) {
            double a0 = rot + span * i / segs, a1 = rot + span * (i + 1) / segs;
            double fade = Math.sin(Math.PI * (i + 0.5) / segs); // brightest in the middle of the arc
            int col = Theme.withAlpha(Theme.blend(0xFFFFFFFF, Theme.current().accent(), 0.25), (int) (150 * fade));
            Vec3 i0 = c.add(Math.cos(a0) * (R - w), 0, Math.sin(a0) * (R - w)), i1 = c.add(Math.cos(a1) * (R - w), 0, Math.sin(a1) * (R - w));
            Vec3 o0 = c.add(Math.cos(a0) * (R + w), 0, Math.sin(a0) * (R + w)), o1 = c.add(Math.cos(a1) * (R + w), 0, Math.sin(a1) * (R + w));
            World3D.quad(i0, i1, o1, o0, col, col, col, col);
            World3D.line(o0, o1, Theme.withAlpha(bright, (int) (230 * fade)), Theme.withAlpha(bright, (int) (230 * fade)), 1.6f);
            World3D.line(i0, i1, Theme.withAlpha(bright, (int) (230 * fade)), Theme.withAlpha(bright, (int) (230 * fade)), 1.6f);
            if (i % 2 == 0) World3D.line(i0, o0, Theme.withAlpha(bright, (int) (200 * fade)), Theme.withAlpha(bright, (int) (200 * fade)), 1.4f);
        }
    }

    /** A turning magic circle on the ground: two rings, a hexagram and rune ticks. */
    private void rune(Vec3 c, double R) {
        double rot = System.currentTimeMillis() / 2600.0;
        int bright = Theme.withAlpha(Theme.blend(Theme.current().accent(), 0xFFFFFFFF, 0.55), 235);
        int soft = Theme.withAlpha(Theme.current().accent(), 60);
        World3D.ring(c, R, 0.0, bright, 64);
        World3D.ring(c, R * 0.84, 0.0, bright, 64);
        // Faint glow disc.
        int segs = 48;
        for (int i = 0; i < segs; i++) {
            double a0 = Math.PI * 2 * i / segs, a1 = Math.PI * 2 * (i + 1) / segs;
            Vec3 p0 = c.add(Math.cos(a0) * R, 0, Math.sin(a0) * R), p1 = c.add(Math.cos(a1) * R, 0, Math.sin(a1) * R);
            World3D.quad(c, c, p1, p0, Theme.withAlpha(soft, 70), Theme.withAlpha(soft, 70), Theme.withAlpha(soft, 0), Theme.withAlpha(soft, 0));
        }
        // Hexagram: two triangles, turning.
        for (int tri = 0; tri < 2; tri++) {
            for (int k = 0; k < 3; k++) {
                double a = rot + tri * Math.PI / 3 + k * Math.PI * 2 / 3, b = rot + tri * Math.PI / 3 + (k + 1) * Math.PI * 2 / 3;
                World3D.line(c.add(Math.cos(a) * R * 0.84, 0, Math.sin(a) * R * 0.84), c.add(Math.cos(b) * R * 0.84, 0, Math.sin(b) * R * 0.84), bright, bright, 1.8f);
            }
        }
        // Rune ticks between the rings, turning the other way.
        for (int i = 0; i < 24; i++) {
            double a = -rot * 1.5 + Math.PI * 2 * i / 24;
            double r0 = R * 0.87, r1 = R * (i % 3 == 0 ? 0.98 : 0.94);
            World3D.line(c.add(Math.cos(a) * r0, 0, Math.sin(a) * r0), c.add(Math.cos(a) * r1, 0, Math.sin(a) * r1), bright, bright, 1.4f);
        }
    }
}
