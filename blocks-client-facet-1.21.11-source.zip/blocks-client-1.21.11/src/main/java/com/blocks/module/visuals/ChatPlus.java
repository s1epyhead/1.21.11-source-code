package com.blocks.module.visuals;

import com.blocks.BlocksClient;
import com.blocks.compat.Compat;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.module.client.ClickGui;
import com.blocks.render.Gfx;
import com.blocks.render.Shapes;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.Theme;

import java.util.List;

/**
 * Replaces the idle chat with glass bubbles that slide in and fade out. Opening
 * chat (T) still shows vanilla's full, scrollable history.
 */
public class ChatPlus extends Module {
    private final NumSetting lines = add(new NumSetting("Max Lines", 10, 3, 20, 1));
    private final NumSetting seconds = add(new NumSetting("Visible For", 10, 3, 30, 1));
    private final BoolSetting slide = add(new BoolSetting("Slide In", true));
    private final BoolSetting bubbles = add(new BoolSetting("Bubbles", true));

    public ChatPlus() {
        super("Chat", "Animated glass chat bubbles", Category.VISUALS);
    }

    /** @return true when drawn (vanilla chat is skipped). */
    public boolean draw(Gfx g) {
        if (!isEnabled() || mc.player == null || mc.gui == null) return false;
        if (Compat.screen() instanceof net.minecraft.client.gui.screens.ChatScreen) return false;
        ClickGui gui = BlocksClient.modules.get(ClickGui.class);
        float k = Hud.scaleFactor();
        g.pose().pushMatrix();
        g.pose().scale(k, k);
        Shapes.begin(g, gui.uiScale());
        double sh = g.guiHeight() / k;
        int now = Compat.guiTicks();
        List<Compat.ChatLine> list = Compat.chatLines();
        double y = sh - 52;
        int shown = 0;
        double life = seconds.get() * 20;
        for (Compat.ChatLine l : list) {
            if (shown >= lines.getInt()) break;
            double age = now - l.addedTime();
            if (age > life) break;
            double alpha = Math.min(1, (life - age) / 20.0);
            double in = slide.get() && gui.animations.get() ? Math.min(1, age / 5.0) : 1;
            in = 1 - Math.pow(1 - in, 3);
            int w = g.widthSeq(l.content());
            double x = 6 - (1 - in) * 30;
            int a = (int) (alpha * in * 255);
            y -= 11;
            if (bubbles.get()) {
                Shapes.roundRect(x - 3, y - 1.5, w + 8, 11, 4, Theme.withAlpha(0xFF0C0C12, (int) (a * 0.62)));
                if (l.endOfEntry()) Shapes.roundRect(x - 3, y + 1, 1.5, 6, 0.75, Theme.withAlpha(Theme.accent(), a));
            }
            g.textSeqPublic(l.content(), (int) (x + 1.5), (int) y, Theme.withAlpha(0xFFFFFFFF, Math.max(a, 6)), true);
            shown++;
        }
        g.pose().popMatrix();
        return true;
    }
}
