package com.blocks.module.world;

import com.blocks.BlocksClient;
import com.blocks.compat.Compat;
import com.blocks.mixin.MinecraftAccessor;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.module.client.ClickGui;
import com.blocks.render.Gfx;
import com.blocks.render.Shapes;
import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.ModeSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.InvUtil;
import com.blocks.util.Notifications;
import com.blocks.util.Theme;
import com.blocks.world.Schematic;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Stream;

/**
 * Builds schematics (.litematic, .schem, .nbt) from config/blocks/schematics.
 *
 * The schematic becomes a world-space plan once you anchor it (origin + rotation).
 * Every pass re-checks the world, so a half-built or partly griefed build resumes
 * without fighting itself. Placement goes bottom-up and nearest-first; blocks that need
 * support wait for it. For each block it finds a face to click within reach, then the
 * look direction and hit point (upper/lower half) that make the block's own placement
 * logic produce exactly the wanted state, so stairs, slabs, logs and observers come out
 * right. Placements are verified; a failure is retried once, then queued for a second
 * pass that re-validates first. Tall builds get a scaffold pillar, removed at the end.
 */
public class AutoBuilder extends Module {
    private final ModeSetting mode = add(new ModeSetting("Mode", "Replaceable", "Air Only", "Replaceable", "Overwrite"));
    private final NumSetting perTick = add(new NumSetting("Blocks Per Tick", 2, 1, 6, 1));
    private final NumSetting reach = add(new NumSetting("Reach", 4.5, 3, 5.5, 0.1));
    private final BoolSetting walk = add(new BoolSetting("Walk To Blocks", true));
    private final BoolSetting scaffold = add(new BoolSetting("Scaffold Up", true));
    private final BoolSetting cleanUp = add(new BoolSetting("Remove Scaffold", true));
    private final BoolSetting fetchFromInventory = add(new BoolSetting("Pull From Inventory", true));
    private final BoolSetting ghost = add(new BoolSetting("Ghost Preview", true));

    public Schematic schematic;
    public BlockPos origin;
    public Rotation rotation = Rotation.NONE;
    public boolean building;
    private int placed, done, wrong, total, failed;
    private long startedAt;
    private BlockPos lastTarget, miningPos;
    private final Map<Item, Integer> missing = new LinkedHashMap<>();

    // Plan for the current schematic/origin/rotation, bottom-up.
    private List<BlockPos> planPos = new ArrayList<>();
    private Map<BlockPos, BlockState> plan = new HashMap<>();
    private Object planKey;
    private final Map<BlockPos, Integer> pending = new HashMap<>();   // placed at tick
    private final Map<BlockPos, Integer> attempts = new HashMap<>();
    private final Set<BlockPos> secondPass = new HashSet<>();
    private boolean inSecondPass;
    private final LinkedHashSet<BlockPos> scaffoldBlocks = new LinkedHashSet<>();
    private boolean cleaning, mining;
    private int ticks;
    private String status = "";

    public AutoBuilder() {
        super("Auto Builder", "Builds .litematic / .schem / .nbt schematics for you", Category.WORLD);
    }

    public static Path folder() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("blocks").resolve("schematics");
        try {
            Files.createDirectories(p);
        } catch (IOException ignored) {
        }
        return p;
    }

    public List<Path> files() {
        List<Path> list = new ArrayList<>();
        try (Stream<Path> s = Files.list(folder())) {
            s.filter(f -> {
                String n = f.getFileName().toString().toLowerCase(Locale.ROOT);
                return n.endsWith(".litematic") || n.endsWith(".schem") || n.endsWith(".schematic") || n.endsWith(".nbt");
            }).sorted().forEach(list::add);
        } catch (IOException ignored) {
        }
        return list;
    }

    public void load(Path file) {
        try {
            schematic = Schematic.load(file);
            origin = null;
            building = false;
            placed = 0;
            resetRun();
            Notifications.push("Schematic loaded", schematic.name + "  " + schematic.blocks.size() + " blocks", true);
        } catch (Exception e) {
            Notifications.push("Couldn't load schematic", file.getFileName().toString(), false);
            BlocksClient.LOG.error("Failed to load schematic {}", file, e);
        }
    }

    /** Anchors the schematic two blocks in front of you, at your feet level. */
    public void placeHere() {
        if (mc.player == null || schematic == null) return;
        origin = mc.player.blockPosition().relative(mc.player.getDirection(), 2);
        resetRun();
    }

    public void rotate() {
        rotation = rotation.getRotated(Rotation.CLOCKWISE_90);
        resetRun();
    }

    public void toggleBuilding() {
        if (schematic == null) return;
        if (origin == null) placeHere();
        building = !building;
        if (building) {
            startedAt = System.currentTimeMillis();
            placed = 0;
            if (!isEnabled()) setEnabled(true);
        } else {
            stopMoving();
        }
    }

    private void resetRun() {
        gaveUp.clear();
        idle = 0;
        pending.clear();
        attempts.clear();
        secondPass.clear();
        inSecondPass = false;
        cleaning = false;
        failed = 0;
    }

    public int progressDone() {
        return done;
    }

    public int progressTotal() {
        return total;
    }

    public Map<Item, Integer> missing() {
        return missing;
    }

    public boolean isMining() {
        return isEnabled() && mining;
    }

    public Map<Item, int[]> materialStatus() {
        Map<Item, int[]> out = new LinkedHashMap<>();
        if (schematic == null || mc.player == null) return out;
        for (var e : schematic.materials().entrySet()) {
            int have = InvUtil.count(s -> s.is(e.getKey()));
            out.put(e.getKey(), new int[]{have, e.getValue()});
        }
        return out;
    }

    @Override
    public String getSuffix() {
        return schematic == null ? null : total == 0 ? "0%" : (100 * done / total) + "%";
    }

    @Override
    protected void onDisable() {
        building = false;
        stopMoving();
    }

    private void stopMoving() {
        if (mc.options == null) return;
        mc.options.keyUp.setDown(false);
        mc.options.keyJump.setDown(false);
        mining = false;
    }

    // ------------------------------------------------------------------ plan

    private void ensurePlan() {
        Object key = Arrays.asList(schematic, origin, rotation);
        if (key.equals(planKey)) return;
        planKey = key;
        plan = new HashMap<>();
        planPos = new ArrayList<>();
        for (var e : schematic.blocks.entrySet()) {
            BlockPos pos = schematic.place(e.getKey(), origin, rotation).immutable();
            plan.put(pos, e.getValue().rotate(rotation));
            planPos.add(pos);
        }
        planPos.sort(Comparator.comparingInt(BlockPos::getY));
        total = planPos.size();
    }

    /** Properties that placement decides; everything else (connections, waterlogging, power) settles itself. */
    private static boolean placementProp(Property<?> p) {
        Class<?> t = p.getValueClass();
        String n = p.getName();
        return t == Direction.class || t == Direction.Axis.class || n.equals("half") || n.equals("type") || n.equals("face")
                || n.equals("hinge") || n.equals("rotation") || n.equals("hanging") || n.equals("attachment") || n.equals("orientation");
    }

    static boolean matches(BlockState have, BlockState want) {
        if (have.getBlock() != want.getBlock()) return false;
        for (Property<?> p : want.getProperties()) {
            if (placementProp(p) && have.hasProperty(p) && !have.getValue(p).equals(want.getValue(p))) return false;
        }
        return true;
    }

    private boolean canPlaceInto(BlockState have) {
        return switch (mode.get()) {
            case "Air Only" -> have.isAir();
            default -> have.canBeReplaced();
        };
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void onTick() {
        mining = false;
        if (schematic == null || origin == null) return;
        ensurePlan();
        ticks++;
        Vec3 eye = mc.player.getEyePosition();
        double r = reach.get(), r2 = r * r;
        if (cleaning) {
            cleanScaffold();
            if (!cleaning) finish();
            return;
        }

        // Verify what we placed a few ticks ago (gives the server time to answer).
        Iterator<Map.Entry<BlockPos, Integer>> pit = pending.entrySet().iterator();
        while (pit.hasNext()) {
            var e = pit.next();
            if (ticks - e.getValue() < 4) continue;
            pit.remove();
            fail(e.getKey(), matches(mc.level.getBlockState(e.getKey()), plan.get(e.getKey())));
        }

        // Re-validate every position against the world: done, blocked, or still to do.
        done = 0;
        wrong = 0;
        missing.clear();
        Map<Item, Boolean> have = new HashMap<>();
        List<BlockPos> farOpen = new ArrayList<>();
        List<BlockPos> ready = new ArrayList<>();
        List<BlockPos> waitingHere = new ArrayList<>();
        BlockPos toMine = null;
        double toMineD = Double.MAX_VALUE;
        int remaining = 0;
        for (BlockPos pos : planPos) {
            BlockState want = plan.get(pos);
            BlockState here = mc.level.getBlockState(pos);
            if (matches(here, want)) {
                done++;
                continue;
            }
            if (gaveUp.contains(pos)) continue;
            double d = eye.distanceToSqr(Vec3.atCenterOf(pos));
            if (!canPlaceInto(here) && here.getBlock() != want.getBlock()) {
                if (!mode.is("Overwrite") || here.getDestroySpeed(mc.level, pos) < 0) {
                    wrong++;
                    continue;
                }
                remaining++;
                if (d <= r2 && d < toMineD) {
                    toMineD = d;
                    toMine = pos;
                } else if (d > r2) {
                    farOpen.add(pos);
                }
                continue;
            }
            if (pending.containsKey(pos)) {
                remaining++;
                continue;
            }
            if (secondPass.contains(pos) && !inSecondPass) continue;
            Item item = want.getBlock().asItem();
            if (!have.computeIfAbsent(item, it -> InvUtil.count(st -> st.is(it)) > 0)) {
                missing.merge(item, 1, Integer::sum);
                continue;
            }
            remaining++;
            if (d > (r + 0.5) * (r + 0.5)) {
                farOpen.add(pos);
                continue;
            }
            // Dependency pass: things that need support wait for it.
            if (!want.canSurvive(mc.level, pos) || want.getBlock() instanceof FallingBlock && mc.level.getBlockState(pos.below()).canBeReplaced()) {
                waitingHere.add(pos);
                continue;
            }
            ready.add(pos);
        }

        if (!building) return;

        // Overwrite: clear a wrong block first, one at a time.
        if (toMine != null && ready.isEmpty()) {
            mine(toMine);
            return;
        }

        // Place: bottom-up, then nearest.
        ready.sort(Comparator.<BlockPos>comparingInt(BlockPos::getY).thenComparingDouble(p -> eye.distanceToSqr(Vec3.atCenterOf(p))));
        int budget = perTick.getInt();
        boolean placedAny = false;
        for (BlockPos pos : ready) {
            if (budget <= 0) break;
            BlockState want = plan.get(pos);
            if (!mc.level.getEntitiesOfClass(net.minecraft.world.entity.LivingEntity.class, new AABB(pos)).isEmpty()) {
                waitingHere.add(pos);
                continue;
            }
            int slot = slotFor(want.getBlock().asItem());
            if (slot == -1) continue;
            Placement pl = placement(pos, want, slot);
            if (pl == null) {
                waitingHere.add(pos); // no face or orientation works from here yet
                continue;
            }
            InvUtil.select(slot);
            if (pl.yaw != mc.player.getYRot() || pl.pitch != mc.player.getXRot()) {
                mc.getConnection().send(new ServerboundMovePlayerPacket.Rot(pl.yaw, pl.pitch, mc.player.onGround(), mc.player.horizontalCollision));
            }
            InvUtil.useOn(pl.hit, InteractionHand.MAIN_HAND);
            pending.put(pos, ticks);
            lastTarget = pos;
            placedAny = true;
            budget--;
        }
        if (placedAny) {
            idle = 0;
            stopMoving();
            status = missing.isEmpty() ? "Building" : "Building, short on " + firstMissing();
            ((MinecraftAccessor) mc).blocks$setRightClickDelay(2);
            return;
        }
        if (!pending.isEmpty()) return; // wait for the server to answer

        // Nothing placeable right here.
        if (remaining == 0) {
            if (!secondPass.isEmpty() && !inSecondPass) {
                inSecondPass = true;
                attempts.clear();
                status = "Second pass";
                return;
            }
            if (!missing.isEmpty()) {
                status = "Waiting for " + firstMissing();
                stopMoving();
                return;
            }
            finish();
            return;
        }
        if (farOpen.isEmpty()) {
            // Everything left is in reach but can't go in yet: give it a moment, then defer it.
            stopMoving();
            status = "Waiting for support";
            if (++idle > 60) {
                idle = 0;
                for (BlockPos p : waitingHere) fail(p, false);
                for (BlockPos p : ready) fail(p, false);
            }
            return;
        }
        BlockPos next = farOpen.get(0);
        for (BlockPos p : farOpen) if (p.getY() < next.getY() || p.getY() == next.getY() && eye.distanceToSqr(Vec3.atCenterOf(p)) < eye.distanceToSqr(Vec3.atCenterOf(next))) next = p;
        double horiz = Math.hypot(next.getX() + 0.5 - mc.player.getX(), next.getZ() + 0.5 - mc.player.getZ());
        if (scaffold.get() && next.getY() > mc.player.getY() + r - 1.5 && horiz < r) {
            pillarUp();
            return;
        }
        if (walk.get()) walkToward(next);
        else status = "Out of reach";
    }

    private final Set<BlockPos> gaveUp = new HashSet<>();
    private int idle;

    /** A placement that didn't land: retry once, then the second pass, then give up on it. */
    private void fail(BlockPos pos, boolean ok) {
        if (ok) {
            placed++;
            attempts.remove(pos);
            return;
        }
        if (attempts.merge(pos, 1, Integer::sum) < 2) return;
        if (inSecondPass) {
            gaveUp.add(pos);
            failed++;
        } else {
            secondPass.add(pos);
        }
        attempts.remove(pos);
    }

    private String firstMissing() {
        Item i = missing.keySet().iterator().next();
        return i.getName(new ItemStack(i)).getString();
    }

    private void finish() {
        if (cleanUp.get() && !scaffoldBlocks.isEmpty()) {
            cleaning = true;
            cleanScaffold();
            return;
        }
        building = false;
        stopMoving();
        String extra = (failed > 0 ? "  ·  " + failed + " couldn't be placed" : "") + (wrong > 0 ? "  ·  " + wrong + " spots blocked" : "");
        Notifications.push("Build finished", schematic.name + extra, true);
    }

    // ------------------------------------------------------------------ placement

    private record Placement(BlockHitResult hit, float yaw, float pitch) {}

    private static final float[][] LOOKS = {{0, 0}, {90, 0}, {180, 0}, {270, 0}, {0, 80}, {0, -80}, {90, 80}, {90, -80}, {180, 80}, {270, 80}};

    /**
     * Find a face to click and a look direction/hit point whose placement result is
     * exactly the wanted state. Returns null if nothing within reach works (yet).
     */
    private Placement placement(BlockPos pos, BlockState want, int slot) {
        Vec3 eye = mc.player.getEyePosition();
        double r2 = reach.get() * reach.get();
        ItemStack stack = mc.player.getInventory().getItem(slot);
        if (!(stack.getItem() instanceof BlockItem)) return null;
        float yaw0 = mc.player.getYRot(), pitch0 = mc.player.getXRot();
        List<BlockHitResult> hits = new ArrayList<>();
        // Same block already there (slab -> double slab, candles, pickles): click it.
        BlockState have = mc.level.getBlockState(pos);
        if (have.getBlock() == want.getBlock()) {
            for (Direction f : Direction.values()) hits.add(new BlockHitResult(Vec3.atCenterOf(pos).add(f.getStepX() * 0.5, f.getStepY() * 0.5, f.getStepZ() * 0.5), f, pos, false));
        }
        for (Direction d : new Direction[]{Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP}) {
            BlockPos support = pos.relative(d);
            BlockState st = mc.level.getBlockState(support);
            if (st.canBeReplaced() || st.getShape(mc.level, support).isEmpty()) continue;
            Direction face = d.getOpposite();
            Vec3 c = Vec3.atCenterOf(support).add(face.getStepX() * 0.5, face.getStepY() * 0.5, face.getStepZ() * 0.5);
            if (face.getAxis().isHorizontal()) {
                // Upper and lower half of the face decide slab/stair halves.
                hits.add(new BlockHitResult(c.add(0, 0.25, 0), face, support, false));
                hits.add(new BlockHitResult(c.add(0, -0.25, 0), face, support, false));
            } else {
                hits.add(new BlockHitResult(c, face, support, false));
            }
        }
        Placement found = null;
        outer:
        for (BlockHitResult hit : hits) {
            if (eye.distanceToSqr(hit.getLocation()) > r2) continue;
            // Prefer the current look (no rotation packet), then the fixed set.
            float[][] looks = new float[LOOKS.length + 1][];
            looks[0] = new float[]{yaw0, pitch0};
            System.arraycopy(LOOKS, 0, looks, 1, LOOKS.length);
            for (float[] l : looks) {
                mc.player.setYRot(l[0]);
                mc.player.setXRot(l[1]);
                BlockState result;
                try {
                    BlockPlaceContext ctx = new BlockPlaceContext(mc.player, InteractionHand.MAIN_HAND, stack, hit);
                    if (!ctx.getClickedPos().equals(pos) || !ctx.canPlace()) continue outer;
                    result = want.getBlock().getStateForPlacement(ctx);
                } catch (Exception ex) {
                    result = null;
                }
                if (result != null && matches(result, want)) {
                    found = new Placement(hit, l[0], l[1]);
                    break outer;
                }
            }
        }
        mc.player.setYRot(yaw0);
        mc.player.setXRot(pitch0);
        return found;
    }

    /** Hotbar first, then pulled from the inventory into a free (or the last) hotbar slot. */
    private int slotFor(Item item) {
        int hb = InvUtil.findHotbar(s -> s.is(item));
        if (hb != -1 || !fetchFromInventory.get()) return hb;
        int inv = InvUtil.findMain(s -> s.is(item));
        if (inv == -1) return -1;
        int target = 8;
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getItem(i).isEmpty()) { target = i; break; }
        InvUtil.moveToHotbar(inv, target);
        return target;
    }

    // ------------------------------------------------------------------ movement, scaffold, mining

    private void lookAt(Vec3 point, float speed) {
        Vec3 eye = mc.player.getEyePosition();
        double dx = point.x - eye.x, dy = point.y - eye.y, dz = point.z - eye.z;
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        mc.player.setYRot(mc.player.getYRot() + Mth.wrapDegrees(yaw - mc.player.getYRot()) * speed);
        mc.player.setXRot(Mth.clamp(mc.player.getXRot() + (pitch - mc.player.getXRot()) * speed, -90, 90));
    }

    private void walkToward(BlockPos p) {
        // Never walk off our own scaffold pillar.
        if (scaffoldBlocks.contains(mc.player.blockPosition().below())) {
            status = "On scaffold";
            stopMoving();
            return;
        }
        Vec3 to = Vec3.atCenterOf(p);
        lookAt(new Vec3(to.x, mc.player.getEyeY(), to.z), 0.35f);
        mc.options.keyUp.setDown(true);
        mc.options.keyJump.setDown(mc.player.horizontalCollision && mc.player.onGround());
        status = "Walking";
    }

    private static boolean scaffoldItem(ItemStack s) {
        return s.is(Items.COBBLESTONE) || s.is(Items.DIRT) || s.is(Items.NETHERRACK) || s.is(Items.COBBLED_DEEPSLATE) || s.is(Items.STONE);
    }

    /** Jump, and at the top of the jump put a block where your feet were. */
    private void pillarUp() {
        mc.options.keyUp.setDown(false);
        int slot = InvUtil.findHotbar(AutoBuilder::scaffoldItem);
        if (slot == -1) {
            int inv = InvUtil.findMain(AutoBuilder::scaffoldItem);
            if (inv == -1) {
                status = "Need cobblestone or dirt to scaffold";
                return;
            }
            InvUtil.moveToHotbar(inv, 8);
            slot = 8;
        }
        mc.player.setXRot(90);
        status = "Scaffolding up";
        BlockPos feet = mc.player.blockPosition();
        if (mc.player.onGround()) {
            mc.options.keyJump.setDown(true);
            return;
        }
        mc.options.keyJump.setDown(false);
        BlockPos below = feet.below();
        if (mc.level.getBlockState(below).canBeReplaced() && !mc.level.getBlockState(below.below()).canBeReplaced()
                && mc.player.getY() >= below.getY() + 1.05) {
            InvUtil.select(slot);
            BlockPos support = below.below();
            BlockHitResult hit = new BlockHitResult(Vec3.atCenterOf(support).add(0, 0.5, 0), Direction.UP, support, false);
            InvUtil.useOn(hit, InteractionHand.MAIN_HAND);
            if (!plan.containsKey(below)) scaffoldBlocks.add(below.immutable());
        }
    }

    /** Mine the scaffold back down, top first (standing on it, we just sink one block at a time). */
    private void cleanScaffold() {
        BlockPos top = null;
        for (BlockPos p : scaffoldBlocks) if (top == null || p.getY() > top.getY()) top = p;
        if (top == null) {
            cleaning = false;
            return;
        }
        if (mc.level.getBlockState(top).canBeReplaced()) {
            scaffoldBlocks.remove(top);
            return;
        }
        status = "Removing scaffold";
        if (mc.player.getEyePosition().distanceToSqr(Vec3.atCenterOf(top)) > reach.get() * reach.get()) {
            walkToward(top);
            return;
        }
        mine(top);
    }

    private void mine(BlockPos pos) {
        mining = true;
        stopMoving();
        mining = true;
        Vec3 eye = mc.player.getEyePosition(), c = Vec3.atCenterOf(pos);
        Direction face = Direction.getApproximateNearest(eye.x - c.x, eye.y - c.y, eye.z - c.z);
        lookAt(c.add(face.getStepX() * 0.5, face.getStepY() * 0.5, face.getStepZ() * 0.5), 0.6f);
        BlockState st = mc.level.getBlockState(pos);
        int best = InvUtil.selected();
        float speed = mc.player.getInventory().getItem(best).getDestroySpeed(st);
        for (int i = 0; i < 9; i++) {
            float sp = mc.player.getInventory().getItem(i).getDestroySpeed(st);
            if (sp > speed) { speed = sp; best = i; }
        }
        InvUtil.select(best);
        if (!pos.equals(miningPos) || !mc.gameMode.isDestroying()) {
            miningPos = pos;
            mc.gameMode.startDestroyBlock(pos, face);
        } else {
            mc.gameMode.continueDestroyBlock(pos, face);
        }
        Compat.swing(InteractionHand.MAIN_HAND, true);
        status = cleaning ? "Removing scaffold" : "Clearing " + st.getBlock().getName().getString();
    }

    @Override
    public void onWorldRender() {
        if (schematic == null || origin == null || !ghost.get()) return;
        int drawn = 0;
        double r2 = 40 * 40;
        int c = Theme.accent();
        // Footprint outline.
        boolean rotated = rotation == Rotation.CLOCKWISE_90 || rotation == Rotation.COUNTERCLOCKWISE_90;
        int fx = rotated ? schematic.sizeZ : schematic.sizeX, fz = rotated ? schematic.sizeX : schematic.sizeZ;
        World3D.boxLines(new AABB(origin.getX(), origin.getY(), origin.getZ(), origin.getX() + fx, origin.getY() + schematic.sizeY, origin.getZ() + fz),
                Theme.withAlpha(c, 120), 1.5f);
        for (var e : schematic.blocks.entrySet()) {
            BlockPos pos = schematic.place(e.getKey(), origin, rotation);
            if (pos.distToCenterSqr(mc.player.position()) > r2) continue;
            BlockState have = mc.level.getBlockState(pos);
            if (matches(have, e.getValue().rotate(rotation))) continue;
            if (drawn++ > 900) break;
            AABB box = new AABB(pos).deflate(0.08);
            if (!have.canBeReplaced()) World3D.boxLines(box, 0xD0FF4D4D, 1.5f);
            else World3D.boxLines(box, Theme.withAlpha(0xFFFFFFFF, 70), 1f);
        }
        if (lastTarget != null) {
            AABB t = new AABB(lastTarget).inflate(0.01);
            World3D.boxFill(t, Theme.withAlpha(c, 70));
            World3D.boxLines(t, Theme.withAlpha(c, 255), 2.5f);
        }
    }

    @Override
    public void onFrame(Gfx g) {
        if (schematic == null || origin == null) return;
        ClickGui gui = BlocksClient.modules.get(ClickGui.class);
        float k = com.blocks.module.visuals.Hud.scaleFactor();
        g.pose().pushMatrix();
        g.pose().scale(k, k);
        Shapes.begin(g, gui.uiScale());
        double sw = g.guiWidth() / k;
        int pct = total == 0 ? 0 : 100 * done / total;
        double mins = Math.max(1 / 60.0, (System.currentTimeMillis() - startedAt) / 60000.0);
        int rate = building ? (int) (placed / mins) : 0;
        int left = total - done;
        String eta = rate > 0 ? fmt(left / (double) rate * 60) : "--";
        String title = "Auto Builder  ·  " + schematic.name;
        String line = (building ? status : "Paused") + "  ·  " + done + "/" + total + "  ·  " + rate + "/min  ·  ETA " + eta;
        double w = Math.max(Math.max(g.widthBold(title) + 40, g.width(line) * 0.84 + 24), 170), h = 32;
        double x = sw / 2 - w / 2, y = 22;
        Shapes.roundRect(x, y, w, h, 9, Theme.withAlpha(0xFF101015, 220));
        Shapes.roundOutline(x, y, w, h, 9, 0.8, Theme.withAlpha(Theme.accent(), 160));
        g.textBold(title, (int) x + 12, (int) y + 6, Theme.TEXT, false);
        String p = pct + "%";
        g.textMono(p, x + w - 12 - g.widthMono(p, 0.8f), y + 7, Theme.accent(), 0.8f);
        g.textScaled(line, x + 12, y + 18, Theme.TEXT_DIM, 0.84f);
        Shapes.roundRect(x + 10, y + h - 3.5, w - 20, 1.4, 0.7, Theme.withAlpha(0xFFFFFF, 30));
        Shapes.roundRect(x + 10, y + h - 3.5, (w - 20) * pct / 100.0, 1.4, 0.7, Theme.accent());
        g.pose().popMatrix();
    }

    static String fmt(double seconds) {
        int s = (int) seconds;
        return s >= 60 ? (s / 60) + "m " + (s % 60) + "s" : s + "s";
    }
}
