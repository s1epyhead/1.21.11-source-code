package com.blocks.module.utility;

import com.blocks.mixin.MinecraftAccessor;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.InvUtil;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Throws XP bottles quickly while you hold right click with one. With Auto Mend on,
 * looking straight down and holding right click with any item throws XP until your
 * armour is repaired.
 */
public class XpManager extends Module {
    private final NumSetting delay = add(new NumSetting("Delay", 0, 0, 4, 1));
    private final BoolSetting autoMend = add(new BoolSetting("Auto Mend", true));
    private final NumSetting pitch = add(new NumSetting("Min Pitch", 70, 30, 90, 1)).visibleWhen(autoMend::get);

    private int timer;

    public XpManager() {
        super("XP Manager", "Fast XP throwing and armour mending", Category.UTILITY);
    }

    @Override
    public void onTick() {
        if (!mc.options.keyUse.isDown() || timer++ < delay.getInt()) return;
        if (mc.player.getMainHandItem().is(Items.EXPERIENCE_BOTTLE)) {
            ((MinecraftAccessor) mc).blocks$setRightClickDelay(delay.getInt());
            return;
        }
        if (!autoMend.get() || mc.player.getXRot() < pitch.get() || !armorDamaged()) return;
        int xp = InvUtil.findHotbar(s -> s.is(Items.EXPERIENCE_BOTTLE));
        if (xp == -1) return;
        int prev = InvUtil.selected();
        InvUtil.select(xp);
        InvUtil.useItem(InteractionHand.MAIN_HAND);
        InvUtil.select(prev);
        timer = 0;
    }

    private boolean armorDamaged() {
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack s = mc.player.getItemBySlot(slot);
            if (!s.isEmpty() && s.isDamaged()) return true;
        }
        return false;
    }
}
