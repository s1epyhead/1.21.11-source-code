package com.blocks.module.combat;

import com.blocks.compat.Compat;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.NumSetting;
import com.blocks.util.InvUtil;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.item.Items;

/** Always keeps a totem in your offhand. */
public class TotemOffhand extends Module {
    private final NumSetting delay = add(new NumSetting("Delay", 0, 0, 10, 1));

    private int timer;

    public TotemOffhand() {
        super("Totem Offhand", "Keeps a totem in your offhand", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING) || mc.player.isCreative()) {
            timer = 0;
            return;
        }
        var screen = Compat.screen();
        if (screen != null && !(screen instanceof InventoryScreen) && !Compat.isUi(screen)) return;
        if (timer++ < delay.getInt()) return;
        int slot = InvUtil.findInventory(s -> s.is(Items.TOTEM_OF_UNDYING));
        if (slot != -1) InvUtil.moveToOffhand(slot);
        timer = 0;
    }
}
