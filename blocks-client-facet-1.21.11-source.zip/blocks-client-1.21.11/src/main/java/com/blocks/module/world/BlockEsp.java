package com.blocks.module.world;

import com.blocks.render.World3D;
import com.blocks.setting.BlockListSetting;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.Theme;
import com.blocks.world.ChunkScanner;
import com.blocks.world.Finds;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * Boxes any blocks you pick (through walls). Highlights vanish the moment a block
 * is mined. Note: servers running anti-xray only send ores once they're exposed,
 * so buried ores there simply aren't in your client's world to find.
 */
public class BlockEsp extends FinderModule {
    public final BlockListSetting blocks = add(new BlockListSetting("Blocks", Blocks.ANCIENT_DEBRIS, Blocks.SPAWNER));
    private final NumSetting range = add(new NumSetting("Range", 128, 16, 256, 8));
    private final BoolSetting fill = add(new BoolSetting("Fill", true));
    private final BoolSetting tracers = add(new BoolSetting("Tracers", true));
    private final BoolSetting labels = add(new BoolSetting("Labels", true));
    private final BoolSetting notify = add(new BoolSetting("Notify", true));

    private int seenVersion = -1;
    private final Map<BlockPos, Block> what = new HashMap<>();
    private final Map<Long, Set<String>> tags = new HashMap<>();

    public BlockEsp() {
        super("Block ESP", "Boxes any blocks you pick, through walls");
    }

    protected BlockEsp(String name, String description) {
        super(name, description);
    }

    protected BlockListSetting list() {
        return blocks;
    }

    protected int color(Block b) {
        if (b == Blocks.ANCIENT_DEBRIS) return 0xFFFFB020;
        if (b == Blocks.SPAWNER) return 0xFFFF5D7E;
        if (b == Blocks.DIAMOND_ORE || b == Blocks.DEEPSLATE_DIAMOND_ORE) return 0xFF4FE3E0;
        return Theme.accent();
    }

    @Override
    public void clear() {
        super.clear();
        what.clear();
        tags.clear();
    }

    @Override
    public void forget(net.minecraft.world.level.ChunkPos pos) {
        super.forget(pos);
        tags.remove(com.blocks.compat.Compat.chunkKey(pos));
    }

    @Override
    protected void onEnable() {
        // Remember the current block list so the first tick doesn't throw away the fresh scan.
        seenVersion = list().version();
        super.onEnable();
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        Finds.clearKind(Finds.Kind.ORE);
        Finds.setLabels(Finds.Kind.ORE, false);
    }

    @Override
    public void onTick() {
        if (list().version() != seenVersion) {
            seenVersion = list().version();
            clear();
            Finds.clearKind(Finds.Kind.ORE);
            ChunkScanner.rescan();
        }
        Finds.setLabels(Finds.Kind.ORE, labels.get());
    }

    @Override
    public void scan(LevelChunk chunk) {
        Set<Block> wanted = list().get();
        if (wanted.isEmpty()) return;
        List<BlockPos> found = new ArrayList<>();
        Map<Block, List<BlockPos>> byType = new LinkedHashMap<>();
        forEachBlock(chunk, chunk.getMinY(), chunk.getMinY() + chunk.getHeight() - 1,
                st -> wanted.contains(st.getBlock()), (pos, st) -> {
                    if (found.size() >= 512) return;
                    BlockPos p = pos.immutable();
                    found.add(p);
                    what.put(p, st.getBlock());
                    byType.computeIfAbsent(st.getBlock(), k -> new ArrayList<>()).add(p);
                });
        long key = com.blocks.compat.Compat.chunkKey(chunk.getPos());
        Set<String> now = new HashSet<>();
        for (Block b : byType.keySet()) now.add(b.getName().getString());
        Set<String> before = tags.getOrDefault(key, Set.of());
        for (String t : before) if (!now.contains(t)) Finds.removeTagged(Finds.Kind.ORE, chunk.getPos(), t);
        if (found.isEmpty()) {
            hits.remove(key);
            tags.remove(key);
            return;
        }
        hits.put(key, found);
        tags.put(key, now);
        // One find (and toast) per block type, named and iconed after that block.
        // Rescans of the same chunk update the find quietly (no repeat toast).
        for (var e : byType.entrySet()) {
            Block b = e.getKey();
            String name = b.getName().getString();
            int n = e.getValue().size();
            Finds.report(Finds.Kind.ORE, name, chunk.getPos(), e.getValue().get(0), n, new ItemStack(b),
                    name, n + (n == 1 ? " block" : " blocks"), notify.get());
        }
    }

    @Override
    public void onWorldRender() {
        Set<Block> wanted = list().get();
        forEachLive(range.get(), p -> wanted.contains(mc.level.getBlockState(p).getBlock()), p -> {
            int c = color(what.getOrDefault(p, mc.level.getBlockState(p).getBlock()));
            AABB box = new AABB(p).deflate(0.02);
            if (fill.get()) World3D.boxFill(box, Theme.withAlpha(c, 50));
            World3D.boxLines(box, Theme.withAlpha(c, 235), 2f);
            if (tracers.get()) World3D.tracer(Vec3.atCenterOf(p), Theme.withAlpha(c, 150), 1.5f);
        }, 600);
    }

    @Override
    public String getSuffix() {
        return String.valueOf(totalHits());
    }
}
