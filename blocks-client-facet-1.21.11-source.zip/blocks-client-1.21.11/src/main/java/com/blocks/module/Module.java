package com.blocks.module;

import com.blocks.setting.Setting;
import com.blocks.util.Notifications;
import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final Minecraft mc = Minecraft.getInstance();

    private final String name;
    private final String description;
    private final Category category;
    private final List<Setting> settings = new ArrayList<>();
    private boolean enabled;
    private boolean favorite;
    private int key;

    protected Module(String name, String description, Category category) {
        this(name, description, category, -1);
    }

    protected Module(String name, String description, Category category, int defaultKey) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.key = defaultKey;
    }

    protected <T extends Setting> T add(T setting) {
        settings.add(setting);
        return setting;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (mc.player != null) {
            if (value) onEnable();
            else onDisable();
        }
        if (showsToggleNotification()) Notifications.toggled(this);
    }

    /** Used by the config loader: does not fire onEnable/onDisable. */
    public void setEnabledSilently(boolean value) {
        enabled = value;
    }

    protected boolean showsToggleNotification() {
        return true;
    }

    /** Hidden modules are not listed in the arraylist. */
    public boolean hiddenInArraylist() {
        return false;
    }

    protected void onEnable() {}

    protected void onDisable() {}

    /** Called at the end of every client tick while enabled and in a world. */
    public void onTick() {}

    /** Called every frame while enabled and in a world. */
    public void onFrame(com.blocks.render.Gfx g) {}

    /** Called while the world renders; draw with World3D. */
    public void onWorldRender() {}

    /** Extra text shown after the name in the arraylist (e.g. the mode). */
    public String getSuffix() {
        return null;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public List<Setting> getSettings() { return settings; }
    public boolean isEnabled() { return enabled; }
    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }
    public boolean isFavorite() { return favorite; }
    public void setFavorite(boolean favorite) { this.favorite = favorite; }
}
