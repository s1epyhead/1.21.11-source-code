package com.blocks.module.combat;

import com.blocks.BlocksClient;
import com.blocks.mixin.MinecraftAccessor;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.NumSetting;
import com.blocks.util.InvUtil;
import com.blocks.util.Notifications;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Bind it to a key. Press while looking at a block: place an anchor, charge, blow it,
 * then place, charge and blow a second one on the same spot. Turns itself off.
 */
public class DoubleAnchor extends Module {
    private final NumSetting delay = add(new NumSetting("Delay", 50, 0, 300, 25));
    private final NumSetting explodeSlot = add(new NumSetting("Explode Slot", 0, 0, 9, 1));

    private enum Step { PLACE, WAIT_PLACED, CHARGE, SHIELD, EXPLODE, WAIT_GONE, DONE }

    private BlockPos anchorPos;
    private Step step;
    private int round, waitTicks, prevSlot;
    private long last;

    public DoubleAnchor() {
        super("Double Anchor", "One press: two anchor blasts on the block you look at", Category.COMBAT);
    }

    @Override
    protected boolean showsToggleNotification() {
        return false;
    }

    @Override
    protected void onEnable() {
        if (!(mc.hitResult instanceof BlockHitResult bhr) || bhr.getType() != HitResult.Type.BLOCK) {
            setEnabled(false);
            return;
        }
        if (InvUtil.count(s -> s.is(Items.RESPAWN_ANCHOR)) < 1 || InvUtil.findHotbar(s -> s.is(Items.GLOWSTONE)) == -1) {
            Notifications.push("Double Anchor", "Needs anchors and glowstone in your hotbar", false);
            setEnabled(false);
            return;
        }
        BlockPos clicked = bhr.getBlockPos();
        anchorPos = mc.level.getBlockState(clicked).is(Blocks.RESPAWN_ANCHOR) ? clicked : clicked.relative(bhr.getDirection());
        step = mc.level.getBlockState(anchorPos).is(Blocks.RESPAWN_ANCHOR) ? Step.CHARGE : Step.PLACE;
        round = 0;
        waitTicks = 0;
        last = 0;
        prevSlot = InvUtil.selected();
    }

    @Override
    protected void onDisable() {
        if (anchorPos != null) InvUtil.select(prevSlot);
        anchorPos = null;
    }

    @Override
    public void onTick() {
        if (anchorPos == null) {
            setEnabled(false);
            return;
        }
        ((MinecraftAccessor) mc).blocks$setRightClickDelay(4);
        boolean isAnchor = mc.level.getBlockState(anchorPos).is(Blocks.RESPAWN_ANCHOR);
        switch (step) {
            case WAIT_PLACED -> {
                if (isAnchor) step = Step.CHARGE;
                else if (++waitTicks > 10) setEnabled(false);
                return;
            }
            case WAIT_GONE -> {
                if (!isAnchor) {
                    step = ++round >= 2 ? Step.DONE : Step.PLACE;
                } else if (++waitTicks > 10) {
                    setEnabled(false);
                }
                return;
            }
            case DONE -> {
                setEnabled(false);
                return;
            }
            default -> {
            }
        }
        long now = System.currentTimeMillis();
        if (now - last < delay.get()) return;
        last = now;

        switch (step) {
            case PLACE -> {
                int slot = InvUtil.findHotbar(s -> s.is(Items.RESPAWN_ANCHOR));
                BlockHitResult hit = placeAgainst(anchorPos);
                if (slot == -1 || hit == null || !mc.level.getBlockState(anchorPos).canBeReplaced()) {
                    setEnabled(false);
                    return;
                }
                InvUtil.select(slot);
                InvUtil.useOn(hit, InteractionHand.MAIN_HAND);
                step = Step.WAIT_PLACED;
                waitTicks = 0;
            }
            case CHARGE -> {
                if (!isAnchor) {
                    step = Step.PLACE;
                    return;
                }
                if (mc.level.getBlockState(anchorPos).getValue(net.minecraft.world.level.block.RespawnAnchorBlock.CHARGE) > 0) {
                    step = Step.SHIELD;
                    return;
                }
                int slot = InvUtil.findHotbar(s -> s.is(Items.GLOWSTONE));
                if (slot == -1) {
                    setEnabled(false);
                    return;
                }
                InvUtil.select(slot);
                InvUtil.useOn(AnchorMacro.topHit(anchorPos), InteractionHand.MAIN_HAND);
                step = Step.SHIELD;
            }
            case SHIELD -> {
                SafeAnchor safe = BlocksClient.modules.get(SafeAnchor.class);
                step = Step.EXPLODE;
                if (safe.isEnabled() && safe.tryShield(anchorPos)) return;
                explode();
            }
            case EXPLODE -> explode();
            default -> {
            }
        }
    }

    private void explode() {
        int slot = AnchorMacro.explodeSlot(explodeSlot.getInt());
        if (slot == -1) {
            setEnabled(false);
            return;
        }
        InvUtil.select(slot);
        InvUtil.useOn(AnchorMacro.topHit(anchorPos), InteractionHand.MAIN_HAND);
        step = Step.WAIT_GONE;
        waitTicks = 0;
    }

    /** Click a solid neighbour (floor first) so the block lands at target. */
    private static BlockHitResult placeAgainst(BlockPos target) {
        Direction[] order = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP};
        for (Direction d : order) {
            BlockPos support = target.relative(d);
            var state = mc.level.getBlockState(support);
            if (state.isAir() || state.canBeReplaced()) continue;
            Direction face = d.getOpposite();
            Vec3 hitVec = Vec3.atCenterOf(support).add(face.getStepX() * 0.5, face.getStepY() * 0.5, face.getStepZ() * 0.5);
            return new BlockHitResult(hitVec, face, support, false);
        }
        return null;
    }
}
