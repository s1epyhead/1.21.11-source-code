package com.blocks.module.combat;

import com.blocks.BlocksClient;
import com.blocks.compat.Compat;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.module.client.ClickGui;
import com.blocks.module.visuals.Hud;
import com.blocks.render.Gfx;
import com.blocks.render.Projection;
import com.blocks.render.Shapes;
import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.ModeSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.CombatUtil;
import com.blocks.util.InvUtil;
import com.blocks.util.Theme;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Plays crystal PvP for you: picks the closest enemy, finds the obsidian or bedrock spot
 * whose crystal hurts them most while staying safe for you, places there and pops the
 * crystal the moment it appears. Face-places when they're low, can put down obsidian
 * when there's nowhere to place, and never kills you (Anti Suicide).
 */
public class CrystalAura extends Module {
    // Targeting
    private final ModeSetting targets = add(new ModeSetting("Targets", "Players", "Players", "All Living"));
    private final NumSetting targetRange = add(new NumSetting("Target Range", 10, 4, 16, 0.5));
    // Place / break
    private final BoolSetting place = add(new BoolSetting("Place", true));
    private final BoolSetting breakCrystals = add(new BoolSetting("Break", true));
    private final NumSetting placeRange = add(new NumSetting("Place Range", 4.5, 2, 6, 0.1));
    private final NumSetting breakRange = add(new NumSetting("Break Range", 4.5, 2, 6, 0.1));
    private final NumSetting wallRange = add(new NumSetting("Wall Range", 3.5, 0, 6, 0.1));
    private final NumSetting placeDelay = add(new NumSetting("Place Delay (ms)", 50, 0, 500, 10));
    private final NumSetting breakDelay = add(new NumSetting("Break Delay (ms)", 50, 0, 500, 10));
    // Damage
    private final NumSetting minDamage = add(new NumSetting("Min Damage", 5, 0, 20, 0.5));
    private final NumSetting maxSelf = add(new NumSetting("Max Self Damage", 7, 0, 20, 0.5));
    private final BoolSetting antiSuicide = add(new BoolSetting("Anti Suicide", true));
    private final NumSetting facePlace = add(new NumSetting("Face Place At", 8, 0, 36, 1));
    // Behaviour
    private final ModeSetting swap = add(new ModeSetting("Switch", "Silent", "Silent", "Normal", "Off"));
    private final BoolSetting rotate = add(new BoolSetting("Rotate", true));
    private final BoolSetting support = add(new BoolSetting("Support Obsidian", false));
    private final BoolSetting pauseEating = add(new BoolSetting("Pause While Eating", true));
    // Visuals
    private final BoolSetting render = add(new BoolSetting("Render", true));
    private final BoolSetting damageText = add(new BoolSetting("Damage Text", true)).visibleWhen(render::get);
    private final BoolSetting targetOutline = add(new BoolSetting("Target Outline", true)).visibleWhen(render::get);
    private final BoolSetting sparkles = add(new BoolSetting("Pop Sparkles", true)).visibleWhen(render::get);

    private LivingEntity target;
    private BlockPos placePos;
    private float placeDamage;
    private long lastPlace, lastBreak, lastSupport, placeShownAt;
    private AABB shownBox;
    private final Map<Integer, Long> hitCrystals = new HashMap<>();
    private final Random rand = new Random();

    public CrystalAura() {
        super("Crystal Aura", "Plays crystal PvP for you: places and pops crystals on the closest enemy", Category.COMBAT);
    }

    @Override
    protected void onDisable() {
        target = null;
        placePos = null;
        shownBox = null;
        hitCrystals.clear();
    }

    @Override
    public String getSuffix() {
        if (target == null) return null;
        return target.getName().getString() + (placePos != null ? String.format(" %.1f", placeDamage) : "");
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void onTick() {
        target = findTarget();
        if (target == null) {
            placePos = null;
            return;
        }
        if (pauseEating.get() && mc.player.isUsingItem() && mc.player.getUseItem().has(net.minecraft.core.component.DataComponents.FOOD)) return;
        long now = System.currentTimeMillis();
        if (breakCrystals.get() && now - lastBreak >= breakDelay.get()) breakBest(now);
        if (place.get()) {
            placePos = bestPlacement();
            if (placePos == null && support.get() && now - lastSupport > 400) placeSupport(now);
            if (placePos != null && now - lastPlace >= placeDelay.get()) doPlace(placePos, now);
        }
        hitCrystals.values().removeIf(t -> now - t > 1000);
    }

    private LivingEntity findTarget() {
        LivingEntity best = null;
        double bestD = targetRange.get() * targetRange.get();
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity le) || e == mc.player || !le.isAlive()) continue;
            if (targets.is("Players")) {
                if (!(e instanceof Player p) || p.isCreative() || p.isSpectator()) continue;
            } else if (e instanceof net.minecraft.world.entity.decoration.ArmorStand) continue;
            double d = mc.player.distanceToSqr(e);
            if (d < bestD) {
                bestD = d;
                best = le;
            }
        }
        if (best instanceof Player p) BlocksClient.setTarget(p);
        return best;
    }

    private boolean safeFor(float self) {
        if (self > maxSelf.get()) return false;
        return !antiSuicide.get() || self < CombatUtil.health(mc.player) - 2;
    }

    private double minFor(LivingEntity t) {
        return CombatUtil.health(t) <= facePlace.get() ? 1.5 : minDamage.get();
    }

    /** In reach, and either visible or close enough to place through a wall. */
    private boolean reachable(Vec3 point, double range) {
        Vec3 eye = mc.player.getEyePosition();
        double d2 = eye.distanceToSqr(point);
        if (d2 > range * range) return false;
        if (d2 <= wallRange.get() * wallRange.get()) return true;
        var hit = mc.level.clip(new ClipContext(eye, point, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mc.player));
        return hit.getType() == HitResult.Type.MISS || hit.getLocation().distanceToSqr(point) < 0.6;
    }

    // ------------------------------------------------------------------ breaking

    private void breakBest(long now) {
        EndCrystal best = null;
        float bestDmg = 0;
        double r = breakRange.get();
        for (Entity e : mc.level.getEntities(mc.player, mc.player.getBoundingBox().inflate(r + 1), e -> e instanceof EndCrystal)) {
            if (!e.isAlive() || hitCrystals.containsKey(e.getId())) continue;
            if (!reachable(e.position().add(0, 0.5, 0), r)) continue;
            float dmg = CombatUtil.crystalDamage(e.position(), target);
            float self = CombatUtil.crystalDamage(e.position(), mc.player);
            if (!safeFor(self) || dmg < Math.min(minFor(target), 2.0) && dmg < self) continue;
            if (dmg > bestDmg) {
                bestDmg = dmg;
                best = (EndCrystal) e;
            }
        }
        if (best == null) return;
        if (rotate.get()) face(best.position().add(0, 0.5, 0));
        mc.gameMode.attack(mc.player, best);
        Compat.swing(InteractionHand.MAIN_HAND, false);
        hitCrystals.put(best.getId(), now);
        lastBreak = now;
        if (render.get() && sparkles.get()) {
            Vec3 p = best.position();
            for (int i = 0; i < 18; i++) {
                double a = rand.nextDouble() * Math.PI * 2, sp = 0.08 + rand.nextDouble() * 0.18;
                mc.level.addParticle(ParticleTypes.END_ROD, p.x, p.y + 0.8, p.z, Math.cos(a) * sp, 0.05 + rand.nextDouble() * 0.15, Math.sin(a) * sp);
            }
        }
    }

    // ------------------------------------------------------------------ placing

    private BlockPos bestPlacement() {
        BlockPos best = null;
        double bestScore = -1;
        float bestDmg = 0;
        double r = placeRange.get();
        BlockPos me = mc.player.blockPosition();
        int ri = (int) Math.ceil(r);
        double min = minFor(target);
        for (int dx = -ri; dx <= ri; dx++) for (int dy = -ri; dy <= ri; dy++) for (int dz = -ri; dz <= ri; dz++) {
            BlockPos base = me.offset(dx, dy, dz);
            // Cheap filters first: near the target, crystal-able block, free space.
            if (base.distToCenterSqr(target.position()) > 7 * 7) continue;
            if (!CombatUtil.canPlaceCrystal(base)) continue;
            Vec3 hit = new Vec3(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
            if (!reachable(hit, r)) continue;
            Vec3 boom = CombatUtil.crystalPos(base);
            float dmg = CombatUtil.crystalDamage(boom, target);
            if (dmg < min) continue;
            float self = CombatUtil.crystalDamage(boom, mc.player);
            if (!safeFor(self)) continue;
            double score = dmg - self * 0.35;
            if (score > bestScore) {
                bestScore = score;
                best = base;
                bestDmg = dmg;
            }
        }
        placeDamage = bestDmg;
        return best;
    }

    private void doPlace(BlockPos base, long now) {
        int slot = InvUtil.findHotbar(s -> s.is(Items.END_CRYSTAL));
        boolean offhand = mc.player.getOffhandItem().is(Items.END_CRYSTAL);
        if (slot == -1 && !offhand) return;
        Vec3 hitVec = new Vec3(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
        if (rotate.get()) face(hitVec);
        BlockHitResult hit = new BlockHitResult(hitVec, Direction.UP, base, false);
        if (offhand) {
            InvUtil.useOn(hit, InteractionHand.OFF_HAND);
        } else {
            if (swap.is("Off") && InvUtil.selected() != slot) return;
            int prev = InvUtil.selected();
            InvUtil.select(slot);
            InvUtil.useOn(hit, InteractionHand.MAIN_HAND);
            if (swap.is("Silent")) InvUtil.select(prev);
        }
        lastPlace = now;
        placeShownAt = now;
    }

    /** Nowhere to place: put obsidian next to the target's feet where a crystal would hit hard. */
    private void placeSupport(long now) {
        int slot = InvUtil.findHotbar(s -> s.is(Items.OBSIDIAN));
        if (slot == -1) return;
        BlockPos feet = target.blockPosition();
        BlockPos best = null;
        float bestDmg = 0;
        for (Direction d : Direction.Plane.HORIZONTAL) {
            for (int out = 1; out <= 2; out++) {
                BlockPos base = feet.relative(d, out).below();
                if (!mc.level.getBlockState(base).canBeReplaced() || !mc.level.getBlockState(base.above()).isAir()) continue;
                if (mc.level.getBlockState(base.below()).canBeReplaced()) continue; // needs something under it
                if (!mc.level.getEntities((Entity) null, new AABB(base), e -> !(e instanceof EndCrystal)).isEmpty()) continue;
                Vec3 face = new Vec3(base.getX() + 0.5, base.getY(), base.getZ() + 0.5);
                if (!reachable(face, placeRange.get())) continue;
                float dmg = CombatUtil.crystalDamage(CombatUtil.crystalPos(base), target);
                float self = CombatUtil.crystalDamage(CombatUtil.crystalPos(base), mc.player);
                if (dmg > bestDmg && safeFor(self)) {
                    bestDmg = dmg;
                    best = base;
                }
            }
        }
        if (best == null || bestDmg < minFor(target)) return;
        BlockPos under = best.below();
        Vec3 hitVec = new Vec3(under.getX() + 0.5, under.getY() + 1.0, under.getZ() + 0.5);
        if (rotate.get()) face(hitVec);
        int prev = InvUtil.selected();
        InvUtil.select(slot);
        InvUtil.useOn(new BlockHitResult(hitVec, Direction.UP, under, false), InteractionHand.MAIN_HAND);
        InvUtil.select(prev);
        lastSupport = now;
    }

    private void face(Vec3 point) {
        float[] r = CombatUtil.rotationsTo(point);
        mc.getConnection().send(new ServerboundMovePlayerPacket.Rot(r[0], r[1], mc.player.onGround(), mc.player.horizontalCollision));
    }

    // ------------------------------------------------------------------ visuals

    @Override
    public void onWorldRender() {
        if (!render.get() || target == null) return;
        Theme.Palette pal = Theme.current();
        long now = System.currentTimeMillis();
        if (placePos != null) {
            // Glass box gliding to the current spot.
            AABB want = new AABB(placePos).inflate(0.002);
            if (shownBox == null) shownBox = want;
            else {
                double k = 0.3;
                shownBox = new AABB(shownBox.minX + (want.minX - shownBox.minX) * k, shownBox.minY + (want.minY - shownBox.minY) * k, shownBox.minZ + (want.minZ - shownBox.minZ) * k,
                        shownBox.maxX + (want.maxX - shownBox.maxX) * k, shownBox.maxY + (want.maxY - shownBox.maxY) * k, shownBox.maxZ + (want.maxZ - shownBox.maxZ) * k);
            }
            double pulse = Math.max(0, 1 - (now - placeShownAt) / 300.0);
            int glass = Theme.blend(0xFF8FE9FF, pal.accent(), 0.25);
            World3D.boxFill(shownBox, Theme.withAlpha(glass, (int) (55 + 60 * pulse)));
            World3D.boxLines(shownBox, Theme.withAlpha(Theme.blend(glass, 0xFFFFFFFF, 0.5), 240), 2.2f);
            World3D.boxLines(shownBox.deflate(0.18), Theme.withAlpha(glass, (int) (80 + 100 * pulse)), 1.2f);
        } else {
            shownBox = null;
        }
        if (targetOutline.get()) {
            Vec3 p = World3D.lerpPos(target);
            double w = target.getBbWidth() / 2 + 0.05;
            World3D.boxLines(new AABB(p.x - w, p.y, p.z - w, p.x + w, p.y + target.getBbHeight() + 0.05, p.z + w), Theme.withAlpha(0xFFFFFFFF, 210), 1.6f);
        }
    }

    @Override
    public void onFrame(Gfx g) {
        if (!render.get() || !damageText.get() || placePos == null || target == null) return;
        double[] s = Projection.toGui(Vec3.atCenterOf(placePos).add(0, 0.6, 0), g.guiWidth(), g.guiHeight());
        if (s == null) return;
        ClickGui gui = BlocksClient.modules.get(ClickGui.class);
        float k = Hud.scaleFactor();
        g.pose().pushMatrix();
        g.pose().scale(k, k);
        Shapes.begin(g, gui.uiScale());
        String txt = String.format("%.1f", placeDamage);
        double x = s[0] / k, y = s[1] / k, w = g.widthMono(txt, 0.9f) + 10;
        Shapes.roundRect(x - w / 2, y - 7, w, 13, 6.5, Theme.withAlpha(0xFF0E0E14, 190));
        Shapes.roundOutline(x - w / 2, y - 7, w, 13, 6.5, 0.8, Theme.withAlpha(0xFF8FE9FF, 200));
        g.textMono(txt, x - g.widthMono(txt, 0.9f) / 2, y - 3, 0xFFE6FBFF, 0.9f);
        g.pose().popMatrix();
    }
}
