package com.blocks.module.visuals;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.ModeSetting;
import com.blocks.util.Theme;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;

/** Glowing outlines through walls, tinted with your theme. */
public class Esp extends Module {
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting crystals = add(new BoolSetting("Crystals", false));
    private final BoolSetting items = add(new BoolSetting("Items", false));
    private final ModeSetting color = add(new ModeSetting("Colour", "Theme", "Theme", "Health", "Team"));

    public Esp() {
        super("ESP", "Glowing outlines through walls", Category.VISUALS);
    }

    public boolean shouldGlow(Entity e) {
        if (!isEnabled() || e == mc.player) return false;
        if (e instanceof Player) return players.get();
        if (e instanceof EndCrystal) return crystals.get();
        if (e instanceof ItemEntity) return items.get();
        return false;
    }

    /** RGB glow colour for an entity, or -1 to keep vanilla's. */
    public int glowColor(Entity e) {
        boolean ours = shouldGlow(e) || e instanceof EndCrystal && com.blocks.BlocksClient.modules.get(CrystalRender.class).glowCrystals();
        if (!ours || color.is("Team")) return -1;
        if (color.is("Health") && e instanceof Player p) {
            return Theme.health(p.getHealth() / p.getMaxHealth()) & 0xFFFFFF;
        }
        return (e instanceof EndCrystal ? Theme.current().accent2() : Theme.accent()) & 0xFFFFFF;
    }
}
