package com.blocks.module.visuals;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.Theme;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** A ripple spreads out under you when you jump and when you land, like stepping into a pool. */
public class JumpCircles extends Module {
    private final BoolSetting onJump = add(new BoolSetting("On Jump", true));
    private final BoolSetting onLand = add(new BoolSetting("On Land", true));
    private final NumSetting size = add(new NumSetting("Size", 1.4, 0.5, 3, 0.1));

    private record Ripple(Vec3 pos, long start) {}

    private final List<Ripple> ripples = new ArrayList<>();
    private boolean wasOnGround = true;

    public JumpCircles() {
        super("Jump Circles", "Ripples under your feet when you jump and land", Category.VISUALS);
    }

    @Override
    public void onTick() {
        boolean ground = mc.player.onGround();
        if (wasOnGround && !ground && mc.player.getDeltaMovement().y > 0.2 && onJump.get()) spawn();
        if (!wasOnGround && ground && onLand.get()) spawn();
        wasOnGround = ground;
    }

    private void spawn() {
        ripples.add(new Ripple(mc.player.position().add(0, 0.02, 0), System.currentTimeMillis()));
        if (ripples.size() > 12) ripples.remove(0);
    }

    @Override
    public void onWorldRender() {
        long now = System.currentTimeMillis();
        ripples.removeIf(r -> now - r.start > 900);
        Theme.Palette pal = Theme.current();
        for (Ripple r : ripples) {
            double t = (now - r.start) / 900.0;
            double e = 1 - Math.pow(1 - t, 3);
            int a = (int) (220 * (1 - t));
            World3D.ring(r.pos, 0.2 + e * size.get(), 0.18 * (1 - t), Theme.withAlpha(Theme.blend(pal.accent(), pal.accent2(), t), a), 48);
            if (t < 0.7) World3D.ring(r.pos, 0.1 + e * size.get() * 0.55, 0.0, Theme.withAlpha(pal.accent2(), (int) (a * 0.6)), 36);
        }
    }
}
