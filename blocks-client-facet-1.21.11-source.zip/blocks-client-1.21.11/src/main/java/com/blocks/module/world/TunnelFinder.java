package com.blocks.module.world;

import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.Theme;
import com.blocks.world.Finds;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;

import java.util.*;

/**
 * Dug tunnels: straight corridors 1-3 wide and 2-3 tall with solid floor, walls and
 * ceiling, at least a few blocks long. Natural caves are rarely that regular.
 */
public class TunnelFinder extends FinderModule {
    private final NumSetting minLength = add(new NumSetting("Min Length", 8, 4, 32, 1));
    private final NumSetting maxY = add(new NumSetting("Max Y", 60, -40, 120, 4));
    private final NumSetting range = add(new NumSetting("Render Range", 128, 32, 256, 8));
    private final BoolSetting notify = add(new BoolSetting("Notify", true));

    private final Map<Long, List<AABB>> tunnels = new HashMap<>();

    public TunnelFinder() {
        super("Tunnel Finder", "Highlights player-dug 1x2, 2x2 and 3x3 tunnels");
    }

    @Override
    public void clear() {
        super.clear();
        tunnels.clear();
    }

    @Override
    public void forget(net.minecraft.world.level.ChunkPos pos) {
        super.forget(pos);
        tunnels.remove(com.blocks.compat.Compat.chunkKey(pos));
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        Finds.clearKind(Finds.Kind.TUNNEL);
    }

    private LevelChunk current;
    private final BlockPos.MutableBlockPos probe = new BlockPos.MutableBlockPos();

    /** Reads from the chunk being scanned directly when possible (much cheaper than level lookups). */
    private BlockState state(int x, int y, int z) {
        probe.set(x, y, z);
        if (current != null && (x >> 4) == com.blocks.compat.Compat.chunkX(current.getPos()) && (z >> 4) == com.blocks.compat.Compat.chunkZ(current.getPos())) return current.getBlockState(probe);
        return mc.level.getBlockState(probe);
    }

    private boolean solid(int x, int y, int z) {
        BlockState s = state(x, y, z);
        return !s.isAir() && s.getFluidState().isEmpty() && s.isSolidRender();
    }

    private boolean air(int x, int y, int z) {
        return state(x, y, z).isAir();
    }

    /** Height (2-3) of a tunnel cross-section at (x,y,z), or 0 if it doesn't look dug. */
    private int cellHeight(int x, int y, int z) {
        if (!air(x, y, z) || !air(x, y + 1, z) || !solid(x, y - 1, z)) return 0;
        if (solid(x, y + 2, z)) return 2;
        if (air(x, y + 2, z) && solid(x, y + 3, z)) return 3;
        return 0;
    }

    /** Width of the corridor across the axis (1-3), bounded by solid walls; 0 if open. */
    private int crossWidth(int x, int y, int z, boolean alongX) {
        int dx = alongX ? 0 : 1, dz = alongX ? 1 : 0;
        int a = 1;
        while (a <= 3 && air(x + dx * a, y, z + dz * a) && air(x + dx * a, y + 1, z + dz * a)) a++;
        if (a > 3 || !solid(x + dx * a, y, z + dz * a)) return 0;
        int b = 1;
        while (b <= 3 && air(x - dx * b, y, z - dz * b) && air(x - dx * b, y + 1, z - dz * b)) b++;
        if (b > 3 || !solid(x - dx * b, y, z - dz * b)) return 0;
        int w = (a - 1) + (b - 1) + 1;
        return w <= 3 ? w : 0;
    }

    @Override
    public void scan(LevelChunk chunk) {
        int bx = com.blocks.compat.Compat.chunkX(chunk.getPos()) << 4, bz = com.blocks.compat.Compat.chunkZ(chunk.getPos()) << 4;
        int minY = chunk.getMinY() + 1, top = Math.min(maxY.getInt(), chunk.getMinY() + chunk.getHeight() - 4);
        List<AABB> found = new ArrayList<>();
        current = chunk;
        // Collect candidate floor cells: air with a solid block under it, in sections that contain air.
        for (int y = minY; y <= top; y++) {
            for (int axis = 0; axis < 2; axis++) {
                boolean alongX = axis == 0;
                for (int lane = 0; lane < 16; lane++) {
                    int run = 0, runH = 0, runW = 0, start = 0;
                    for (int i = 0; i <= 16; i++) {
                        boolean ok = false;
                        int h = 0, w = 0;
                        if (i < 16) {
                            int x = alongX ? bx + i : bx + lane, z = alongX ? bz + lane : bz + i;
                            h = cellHeight(x, y, z);
                            if (h > 0) w = crossWidth(x, y, z, alongX);
                            ok = h > 0 && w > 0 && (run == 0 || h == runH && w == runW);
                        }
                        if (ok) {
                            if (run == 0) {
                                start = i;
                                runH = h;
                                runW = w;
                            }
                            run++;
                        } else {
                            if (run >= minLength.get()) {
                                double x0 = alongX ? bx + start : bx + lane, z0 = alongX ? bz + lane : bz + start;
                                double x1 = alongX ? bx + start + run : x0 + 1, z1 = alongX ? z0 + 1 : bz + start + run;
                                found.add(new AABB(x0, y, z0, x1, y + runH, z1));
                            }
                            run = 0;
                        }
                    }
                }
            }
        }
        current = null;
        long key = com.blocks.compat.Compat.chunkKey(chunk.getPos());
        if (found.isEmpty()) {
            tunnels.remove(key);
            Finds.remove(Finds.Kind.TUNNEL, chunk.getPos());
            return;
        }
        tunnels.put(key, found);
        AABB first = found.get(0);
        BlockPos at = BlockPos.containing(first.getCenter());
        int len = 0;
        for (AABB b : found) len += (int) Math.max(b.getXsize(), b.getZsize());
        Finds.report(Finds.Kind.TUNNEL, chunk.getPos(), at, len, "Tunnel", len + " blocks of tunnel", notify.get());
    }

    @Override
    public void onWorldRender() {
        int c = Finds.Kind.TUNNEL.color;
        double r2 = range.get() * range.get();
        int drawn = 0;
        for (List<AABB> list : tunnels.values()) {
            for (AABB b : list) {
                if (b.getCenter().distanceToSqr(mc.player.position()) > r2 || drawn++ > 300) continue;
                World3D.boxFill(b, Theme.withAlpha(c, 50));
                World3D.boxLines(b, Theme.withAlpha(c, 220), 2f);
            }
        }
    }

    @Override
    public String getSuffix() {
        return String.valueOf(tunnels.size());
    }
}
