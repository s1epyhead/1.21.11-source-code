package com.blocks.module.combat;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.InvUtil;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Hits a shielding player with an axe to disable the shield. Waits until they have
 * actually been blocking toward you for a moment, swaps one tick, hits the next,
 * and swaps back after a pause, so it plays like a quick hand rather than a snap.
 */
public class ShieldDisabler extends Module {
    private final NumSetting reaction = add(new NumSetting("Reaction", 180, 0, 600, 20));
    private final NumSetting swapBackDelay = add(new NumSetting("Swap Back", 200, 50, 800, 25));
    private final BoolSetting requireCharge = add(new BoolSetting("Wait For Cooldown", true));
    private final BoolSetting swordOnly = add(new BoolSetting("Only From Sword", true));

    private Player blocker;
    private long blockingSince, swappedAt;
    private int prevSlot = -1;
    private boolean pendingHit;

    public ShieldDisabler() {
        super("Shield Disabler", "Axe-hits players who hold their shield up at you", Category.COMBAT);
    }

    @Override
    public void onTick() {
        long now = System.currentTimeMillis();
        if (prevSlot != -1 && !pendingHit && now - swappedAt >= swapBackDelay.get()) {
            InvUtil.select(prevSlot);
            prevSlot = -1;
        }

        Player target = mc.hitResult instanceof EntityHitResult ehr && ehr.getEntity() instanceof Player p ? p : null;
        boolean blockingUs = target != null && target.isBlocking() && facingUs(target);
        if (!blockingUs) {
            blocker = null;
            pendingHit = false;
            return;
        }
        if (target != blocker) {
            blocker = target;
            blockingSince = now;
        }

        if (pendingHit) {
            // Second tick: we already hold the axe, now swing.
            if (!requireCharge.get() || mc.player.getAttackStrengthScale(0.5f) >= 0.9f) {
                InvUtil.attack(target);
                pendingHit = false;
                swappedAt = now;
            }
            return;
        }
        if (now - blockingSince < reaction.get() || prevSlot != -1) return;
        if (swordOnly.get() && !mc.player.getMainHandItem().is(ItemTags.SWORDS)) return;
        int axe = InvUtil.findHotbar(s -> s.is(ItemTags.AXES));
        if (axe == -1) return;
        prevSlot = InvUtil.selected();
        InvUtil.select(axe);
        swappedAt = now;
        pendingHit = true;
    }

    /** Shields only stop hits from the front, so only bother when they face us. */
    private boolean facingUs(Player target) {
        Vec3 look = target.getViewVector(1f).multiply(1, 0, 1).normalize();
        Vec3 toUs = mc.player.position().subtract(target.position()).multiply(1, 0, 1).normalize();
        return look.dot(toUs) > 0.2;
    }
}
