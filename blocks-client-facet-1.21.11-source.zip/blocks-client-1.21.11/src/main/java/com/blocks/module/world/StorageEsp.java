package com.blocks.module.world;

import com.blocks.render.World3D;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.Theme;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/** Boxes every container in loaded chunks: chests, shulkers, ender chests, barrels and more. */
public class StorageEsp extends FinderModule {
    private final NumSetting range = add(new NumSetting("Range", 96, 16, 256, 8));
    private final BoolSetting chests = add(new BoolSetting("Chests", true));
    private final BoolSetting shulkers = add(new BoolSetting("Shulkers", true));
    private final BoolSetting enderChests = add(new BoolSetting("Ender Chests", true));
    private final BoolSetting barrels = add(new BoolSetting("Barrels", true));
    private final BoolSetting other = add(new BoolSetting("Hoppers & Furnaces", false));
    private final BoolSetting fill = add(new BoolSetting("Fill", true));
    private final BoolSetting tracers = add(new BoolSetting("Tracers", false));

    private final Map<BlockPos, Integer> colors = new HashMap<>();

    public StorageEsp() {
        super("Storage ESP", "Boxes chests, shulkers, ender chests and barrels");
    }

    @Override
    public void clear() {
        super.clear();
        colors.clear();
    }

    /** Colour for a container, or 0 when this type is switched off. */
    int colorFor(BlockEntity be) {
        if (be instanceof ShulkerBoxBlockEntity) return shulkers.get() ? 0xFFC77DFF : 0;
        if (be instanceof EnderChestBlockEntity) return enderChests.get() ? 0xFF4FD8C8 : 0;
        if (be instanceof ChestBlockEntity) return chests.get() ? 0xFFFFB347 : 0; // includes trapped chests
        if (be instanceof BarrelBlockEntity) return barrels.get() ? 0xFFD9A066 : 0;
        if (be instanceof HopperBlockEntity || be instanceof AbstractFurnaceBlockEntity || be instanceof DispenserBlockEntity) {
            return other.get() ? 0xFFB8B8C0 : 0;
        }
        return 0;
    }

    @Override
    public void scan(LevelChunk chunk) {
        List<BlockPos> list = new ArrayList<>();
        for (BlockEntity be : chunk.getBlockEntities().values()) {
            int c = colorFor(be);
            if (c == 0) continue;
            BlockPos p = be.getBlockPos().immutable();
            list.add(p);
            colors.put(p, c);
        }
        if (list.isEmpty()) hits.remove(com.blocks.compat.Compat.chunkKey(chunk.getPos()));
        else hits.put(com.blocks.compat.Compat.chunkKey(chunk.getPos()), list);
    }

    @Override
    public void onWorldRender() {
        forEachLive(range.get(), p -> mc.level.getBlockEntity(p) != null && colorFor(mc.level.getBlockEntity(p)) != 0, p -> {
            int c = colors.getOrDefault(p, Theme.accent());
            AABB box = new AABB(p).deflate(0.06);
            if (fill.get()) World3D.boxFill(box, Theme.withAlpha(c, 46));
            World3D.boxLines(box, Theme.withAlpha(c, 220), 2f);
            if (tracers.get()) World3D.tracer(Vec3.atCenterOf(p), Theme.withAlpha(c, 150), 1.5f);
        }, 600);
    }

    @Override
    public String getSuffix() {
        return String.valueOf(totalHits());
    }
}
