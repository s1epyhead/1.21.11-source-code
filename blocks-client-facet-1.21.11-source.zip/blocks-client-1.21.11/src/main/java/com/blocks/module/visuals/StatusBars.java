package com.blocks.module.visuals;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.render.Gfx;
import com.blocks.render.Shapes;
import com.blocks.setting.BoolSetting;
import com.blocks.util.Theme;

/** Replaces the vanilla hearts and hunger with two sleek bars and numbers. Off by default. */
public class StatusBars extends Module {
    private final BoolSetting numbers = add(new BoolSetting("Numbers", true));
    private final BoolSetting hotbar = add(new BoolSetting("Sleek Hotbar", true));

    private double shownHp = -1, shownFood = -1;

    public StatusBars() {
        super("Status Bars", "Sleek health and hunger bars instead of hearts", Category.VISUALS);
    }

    private void begin(Gfx g) {
        Shapes.begin(g, (float) mc.getWindow().getGuiScale());
    }

    /** @return true when drawn (vanilla hearts are skipped). */
    public boolean drawHealth(Gfx g) {
        if (!isEnabled() || mc.player == null) return false;
        if (mc.gameMode != null && !mc.gameMode.canHurtPlayer()) return true;
        begin(g);
        float max = mc.player.getMaxHealth(), hp = mc.player.getHealth(), abs = mc.player.getAbsorptionAmount();
        shownHp = shownHp < 0 ? hp : shownHp + (hp - shownHp) * 0.2;
        double x = g.guiWidth() / 2.0 - 91, y = g.guiHeight() - 36, w = 81, h = 5;
        Shapes.roundRect(x, y, w, h, 2.5, Theme.withAlpha(0xFF0B0B10, 170));
        double pct = Math.min(1, shownHp / max);
        Shapes.gradientRoundRect(x, y, Math.max(h, w * pct), h, 2.5, 0xFFFF4D6A, Theme.blend(0xFFFF4D6A, 0xFFFFB0C0, pct));
        if (abs > 0) Shapes.roundRect(x, y - 2.5, Math.min(w, w * abs / max), 1.6, 0.8, 0xFFFFD34D);
        if (numbers.get()) {
            String t = String.format(hp >= 10 ? "%.0f" : "%.1f", hp + abs);
            Shapes.circle(x + 2, y - 5.5, 1.8, 0xFFFF5470);
            g.textMono(t, x + 6, y - 8.5, 0xFFFF8FA3, 0.8f);
            int armor = mc.player.getArmorValue();
            if (armor > 0) {
                double ax = x + 10 + g.widthMono(t, 0.8f);
                Shapes.circle(ax + 2, y - 5.5, 1.8, 0xFF7FB8FF);
                g.textMono(String.valueOf(armor), ax + 6, y - 8.5, 0xFFA9CCFF, 0.8f);
            }
        }
        return true;
    }

    /** A sleek dark hotbar with an accent ring on the selected slot. */
    public boolean drawHotbar(Gfx g) {
        if (!isEnabled() || !hotbar.get() || mc.player == null) return false;
        if (mc.player.isSpectator()) return false;
        begin(g);
        double w = 182, h = 22, x = Math.round(g.guiWidth() / 2.0 - w / 2), y = g.guiHeight() - h - 1;
        Shapes.roundRect(x, y, w, h, 6, Theme.withAlpha(0xFF0B0B10, 185));
        Shapes.roundOutline(x, y, w, h, 6, 0.6, Theme.withAlpha(0xFFFFFFFF, 26));
        int sel = mc.player.getInventory().getSelectedSlot();
        double sx = x + 1 + sel * 20;
        Shapes.roundRect(sx, y + 1, 20, 20, 5, Theme.withAlpha(Theme.accent(), 60));
        Shapes.roundOutline(sx, y + 1, 20, 20, 5, 0.9, Theme.withAlpha(Theme.blend(Theme.accent(), 0xFFFFFFFF, 0.3), 235));
        for (int i = 0; i < 9; i++) slot(g, mc.player.getInventory().getItem(i), (int) (x + 3 + i * 20), (int) (y + 3));
        net.minecraft.world.item.ItemStack off = mc.player.getOffhandItem();
        if (!off.isEmpty()) {
            double ox = x - 26;
            Shapes.roundRect(ox, y, 22, 22, 6, Theme.withAlpha(0xFF0B0B10, 185));
            Shapes.roundOutline(ox, y, 22, 22, 6, 0.6, Theme.withAlpha(0xFFFFFFFF, 26));
            slot(g, off, (int) (ox + 3), (int) (y + 3));
        }
        return true;
    }

    private void slot(Gfx g, net.minecraft.world.item.ItemStack st, int x, int y) {
        if (st.isEmpty()) return;
        g.item(st, x, y);
        if (st.isDamageableItem() && st.getDamageValue() > 0) {
            double d = 1 - st.getDamageValue() / (double) st.getMaxDamage();
            Shapes.rect(x + 2, y + 14, 12, 1.2, 0xFF000000);
            Shapes.rect(x + 2, y + 14, 12 * d, 1.2, Theme.health((float) d));
        }
        if (st.getCount() > 1) {
            String c = String.valueOf(st.getCount());
            g.textMono(c, x + 17 - g.widthMono(c, 0.7f), y + 10.5, 0xFFFFFFFF, 0.7f);
        }
    }

    public boolean drawFood(Gfx g) {
        if (!isEnabled() || mc.player == null) return false;
        if (mc.gameMode != null && !mc.gameMode.canHurtPlayer()) return true;
        begin(g);
        int food = mc.player.getFoodData().getFoodLevel();
        shownFood = shownFood < 0 ? food : shownFood + (food - shownFood) * 0.2;
        double w = 81, h = 5, x = g.guiWidth() / 2.0 + 91 - w, y = g.guiHeight() - 36;
        Shapes.roundRect(x, y, w, h, 2.5, Theme.withAlpha(0xFF0B0B10, 170));
        double pct = Math.min(1, shownFood / 20.0);
        // Fills from the right, like vanilla's hunger row.
        double fw = Math.max(h, w * pct);
        Shapes.gradientRoundRect(x + w - fw, y, fw, h, 2.5, 0xFFFFC24D, 0xFFFF8A3D);
        if (numbers.get()) {
            String t = String.valueOf(food);
            g.textMono(t, x + w - 6 - g.widthMono(t, 0.8f), y - 8.5, 0xFFFFC27A, 0.8f);
            Shapes.circle(x + w - 2, y - 5.5, 1.8, 0xFFFFA94D);
        }
        return true;
    }

    public boolean hideArmorRow() {
        return isEnabled();
    }
}
