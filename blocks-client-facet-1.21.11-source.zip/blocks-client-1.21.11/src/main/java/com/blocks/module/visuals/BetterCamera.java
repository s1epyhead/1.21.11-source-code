package com.blocks.module.visuals;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;

/** Third person (F5) camera: farther back, smooth zoom, and optionally through walls. */
public class BetterCamera extends Module {
    private final NumSetting distance = add(new NumSetting("Distance", 6, 2, 20, 0.5));
    private final BoolSetting noClip = add(new BoolSetting("Through Walls", true));
    private final BoolSetting smooth = add(new BoolSetting("Smooth Zoom", true));

    private double current = 4;
    private long lastCall;
    private float lastResult = 4;

    public BetterCamera() {
        super("Better Camera", "Further, smoother F5 that can see through walls", Category.VISUALS);
    }

    /** Called from the camera mixin with vanilla's wanted distance. */
    public float distance(float vanilla) {
        long now = System.nanoTime();
        if (now - lastCall < 1_000_000L) return lastResult; // same frame, same answer
        double dt = Math.min(0.1, (now - lastCall) / 1e9);
        lastCall = now;
        double want = isEnabled() ? distance.get() * (vanilla / 4f) : vanilla;
        if (smooth.get() && isEnabled()) current += (want - current) * (1 - Math.exp(-dt * 12));
        else current = want;
        lastResult = (float) current;
        return lastResult;
    }

    public boolean noClip() {
        return isEnabled() && noClip.get();
    }
}
