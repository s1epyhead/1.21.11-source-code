package com.blocks.module.combat;

import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.CombatUtil;
import com.blocks.util.InvUtil;
import net.minecraft.world.item.Items;

/** Switches to a hotbar totem when you are low or just popped, so you hold two. */
public class AutoDoubleHand extends Module {
    private final NumSetting health = add(new NumSetting("Health", 6, 1, 20, 0.5));
    private final BoolSetting onPop = add(new BoolSetting("On Pop", true));

    private boolean hadOffhandTotem;

    public AutoDoubleHand() {
        super("Auto Double Hand", "Holds a second totem when in danger", Category.COMBAT);
    }

    @Override
    public void onTick() {
        boolean offhandTotem = mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING);
        boolean popped = onPop.get() && hadOffhandTotem && !offhandTotem;
        hadOffhandTotem = offhandTotem;

        if (CombatUtil.health(mc.player) > health.get() && !popped) return;
        if (mc.player.getMainHandItem().is(Items.TOTEM_OF_UNDYING)) return;
        int slot = InvUtil.findHotbar(s -> s.is(Items.TOTEM_OF_UNDYING));
        if (slot != -1) InvUtil.select(slot);
    }
}
