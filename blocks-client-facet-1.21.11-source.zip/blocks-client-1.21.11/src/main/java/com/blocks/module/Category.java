package com.blocks.module;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.function.Supplier;

public enum Category {
    COMBAT("Combat", () -> Items.END_CRYSTAL),
    VISUALS("Visuals", () -> Items.SPYGLASS),
    WORLD("World", () -> Items.RECOVERY_COMPASS),
    UTILITY("Utility", () -> Items.ENDER_PEARL),
    CLIENT("Client", () -> Items.SUNFLOWER);

    public final String title;
    private final Supplier<Item> iconItem;
    private ItemStack icon;

    Category(String title, Supplier<Item> iconItem) {
        this.title = title;
        this.iconItem = iconItem;
    }

    /** A real Minecraft item used as this category's icon. */
    public ItemStack icon() {
        if (icon == null) icon = new ItemStack(iconItem.get());
        return icon;
    }
}
