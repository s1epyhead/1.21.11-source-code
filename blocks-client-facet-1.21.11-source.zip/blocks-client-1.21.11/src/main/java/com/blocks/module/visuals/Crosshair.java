package com.blocks.module.visuals;

import com.blocks.BlocksClient;
import com.blocks.module.Category;
import com.blocks.module.Module;
import com.blocks.module.client.ClickGui;
import com.blocks.render.Gfx;
import com.blocks.render.Shapes;
import com.blocks.setting.BoolSetting;
import com.blocks.setting.NumSetting;
import com.blocks.util.Theme;

/** A clean crosshair whose arms spread with your attack cooldown. */
public class Crosshair extends Module {
    private final NumSetting gap = add(new NumSetting("Gap", 3, 0, 10, 0.5));
    private final NumSetting length = add(new NumSetting("Length", 4, 1, 12, 0.5));
    private final BoolSetting dynamic = add(new BoolSetting("Cooldown Spread", true));
    private final BoolSetting dot = add(new BoolSetting("Dot", true));

    public Crosshair() {
        super("Crosshair", "Custom crosshair that shows your attack cooldown", Category.VISUALS);
    }

    /** @return true when drawn (vanilla's crosshair is skipped). */
    public boolean draw(Gfx g) {
        if (!isEnabled() || mc.player == null || !mc.options.getCameraType().isFirstPerson()) return false;
        float k = Hud.scaleFactor();
        g.pose().pushMatrix();
        g.pose().scale(k, k);
        Shapes.begin(g, BlocksClient.modules.get(ClickGui.class).uiScale());
        double cx = g.guiWidth() / k / 2.0, cy = g.guiHeight() / k / 2.0;
        double cd = dynamic.get() ? 1 - mc.player.getAttackStrengthScale(0) : 0;
        double gp = gap.get() + cd * 4, len = length.get(), t = 1;
        int c = Theme.withAlpha(Theme.blend(0xFFFFFFFF, Theme.accent(), cd), 235), shadow = 0x70000000;
        double[][] arms = {{-gp - len, -t / 2, len, t}, {gp, -t / 2, len, t}, {-t / 2, -gp - len, t, len}, {-t / 2, gp, t, len}};
        for (double[] a : arms) Shapes.roundRect(cx + a[0] - 0.5, cy + a[1] - 0.5, a[2] + 1, a[3] + 1, 0.8, shadow);
        for (double[] a : arms) Shapes.roundRect(cx + a[0], cy + a[1], a[2], a[3], 0.5, c);
        if (dot.get()) Shapes.circle(cx, cy, 0.9, Theme.accent());
        g.pose().popMatrix();
        return true;
    }
}
