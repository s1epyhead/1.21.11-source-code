package com.blocks.module.visuals;

import com.blocks.render.Gfx;

/**
 * A draggable HUD widget. Positions are in UI units measured from the nearest
 * screen edges, so widgets stay in their corner when the window is resized.
 */
public abstract class HudElement {
    public final String name;
    /** Distance from the left (or right, if {@link #right}) edge. */
    public double px;
    /** Distance from the top (or bottom, if {@link #bottom}) edge. */
    public double py;
    public boolean right, bottom;
    public double w = 40, h = 12;

    protected HudElement(String name, double px, double py, boolean right, boolean bottom) {
        this.name = name;
        this.px = px;
        this.py = py;
        this.right = right;
        this.bottom = bottom;
    }

    public abstract boolean visible();

    /** Draws at (x, y) and must update {@link #w}/{@link #h}. */
    protected abstract void render(Gfx g, double x, double y, boolean preview);

    public double x(double screenW) {
        return right ? screenW - px - w : px;
    }

    /** Extra vertical shift applied this frame so elements never sit on top of each other. */
    public double nudge;

    public double y(double screenH) {
        return (bottom ? screenH - py - h : py) + nudge;
    }

    public void draw(Gfx g, double screenW, double screenH, boolean preview) {
        render(g, x(screenW), y(screenH), preview);
    }

    public void moveTo(double nx, double ny, double screenW, double screenH) {
        nudge = 0;
        nx = Math.max(0, Math.min(screenW - w, nx));
        ny = Math.max(0, Math.min(screenH - h, ny));
        right = nx + w / 2 > screenW / 2;
        bottom = ny + h / 2 > screenH / 2;
        px = right ? screenW - nx - w : nx;
        py = bottom ? screenH - ny - h : ny;
    }

    public boolean contains(double mx, double my, double screenW, double screenH) {
        double x = x(screenW), y = y(screenH);
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }
}
