package com.blocks.compat;

import com.blocks.render.UiScreen;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public class ScreenWrapper extends Screen {
    private final UiScreen ui;

    public ScreenWrapper(UiScreen ui) {
        super(Component.literal("Blocks"));
        this.ui = ui;
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        ui.renderBackground(new GfxImpl(g));
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        ui.render(new GfxImpl(g), mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean doubleClick) {
        return ui.mouseClicked(e.x(), e.y(), e.button());
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        return ui.mouseReleased(e.x(), e.y(), e.button());
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        return ui.mouseDragged(e.x(), e.y(), e.button());
    }

    @Override
    public boolean mouseScrolled(double x, double y, double h, double v) {
        return ui.mouseScrolled(x, y, v);
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        if (ui.keyPressed(e.key(), e.modifiers())) return true;
        return super.keyPressed(e);
    }

    @Override
    public boolean charTyped(CharacterEvent e) {
        return ui.charTyped(e.codepointAsString());
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void removed() {
        ui.onClose();
    }
}
